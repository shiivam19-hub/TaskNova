import React, { createContext, useContext, useState, useEffect } from 'react';
import { apiClient } from '../services/apiClient';
import {
  Project,
  Task,
  ToDoItem,
  TeamMember,
  ProjectComment,
  ActivityItem,
  NotificationItem,
  CalendarEvent,
  StudyResource,
  StudyPlan,
  AuditLogItem,
  ProjectFile,
  UserProfile,
  TaskStatus,
  Priority,
  RoleType
} from '../types';
import {
  initialUserProfile,
  initialProjects,
  initialTasks,
  initialToDos,
  initialTeamMembers,
  initialComments,
  initialActivities,
  initialNotifications,
  initialEvents,
  initialStudyPlan,
  initialStudyResources,
  initialFiles,
  initialAuditLogs
} from '../data/mockData';

export type NavigationTab =
  | 'dashboard'
  | 'tasks'
  | 'todos'
  | 'projects'
  | 'project-details'
  | 'team'
  | 'comments'
  | 'calendar'
  | 'timer'
  | 'study-hub'
  | 'study-planner'
  | 'ai-assistant'
  | 'analytics'
  | 'notifications'
  | 'teams-integration'
  | 'files'
  | 'privacy'
  | 'settings';

interface AppContextType {
  activeTab: NavigationTab;
  setActiveTab: (tab: NavigationTab) => void;
  selectedProjectId: string;
  setSelectedProjectId: (id: string) => void;
  openProjectDetails: (id: string, tab?: string) => void;
  projectDetailsSubTab: string;
  setProjectDetailsSubTab: (tab: string) => void;

  userProfile: UserProfile;
  updateUserProfile: (updates: Partial<UserProfile>) => void;
  updatePrivacySetting: (key: keyof UserProfile['privacy'], value: any) => void;
  toggle2FA: () => void;

  projects: Project[];
  addProject: (project: Omit<Project, 'id' | 'completedTaskCount'>) => void;
  updateProject: (id: string, updates: Partial<Project>) => void;
  deleteProject: (id: string) => void;

  tasks: Task[];
  addTask: (task: Omit<Task, 'id' | 'commentsCount' | 'attachmentIndicator'>) => void;
  updateTask: (id: string, updates: Partial<Task>) => void;
  deleteTask: (id: string) => void;
  moveTaskStatus: (taskId: string, newStatus: TaskStatus) => void;
  toggleTaskCompletion: (taskId: string) => void;

  todos: ToDoItem[];
  addToDo: (todo: Omit<ToDoItem, 'id' | 'completed'>) => void;
  toggleToDo: (id: string) => void;
  updateToDo: (id: string, updates: Partial<ToDoItem>) => void;
  deleteToDo: (id: string) => void;

  teamMembers: TeamMember[];
  updateMemberRole: (memberId: string, newRole: RoleType) => void;
  addTeamMember: (member: Omit<TeamMember, 'id'>) => void;

  comments: ProjectComment[];
  addComment: (projectId: string, content: string, attachments?: string[]) => void;
  addReply: (commentId: string, content: string) => void;
  addReaction: (commentId: string, emoji: string) => void;
  togglePinComment: (commentId: string) => void;
  deleteComment: (commentId: string) => void;

  activities: ActivityItem[];
  addActivity: (activity: Omit<ActivityItem, 'id' | 'timestamp'>) => void;

  notifications: NotificationItem[];
  markNotificationAsRead: (id: string) => void;
  markAllNotificationsAsRead: () => void;
  addNotification: (item: Omit<NotificationItem, 'id' | 'timestamp' | 'read'>) => void;

  events: CalendarEvent[];
  addEvent: (event: Omit<CalendarEvent, 'id'>) => void;
  deleteEvent: (id: string) => void;

  studyPlan: StudyPlan;
  toggleStudyDayCompleted: (dayNumber: number) => void;
  generateNewPlan: (subject: string, examDate: string, hours: number, difficulty: StudyPlan['difficulty']) => void;

  studyResources: StudyResource[];
  toggleSaveResource: (id: string) => void;
  addStudyResource: (resource: Omit<StudyResource, 'id' | 'saved'>) => void;

  files: ProjectFile[];
  uploadFile: (file: Omit<ProjectFile, 'id' | 'uploadedAt'>) => void;
  deleteFile: (id: string) => void;

  auditLogs: AuditLogItem[];
  addAuditLog: (log: Omit<AuditLogItem, 'id' | 'timestamp'>) => void;

  // Search & Global state
  searchQuery: string;
  setSearchQuery: (query: string) => void;

  // Modal Dialogs
  isQuickCreateOpen: boolean;
  setIsQuickCreateOpen: (open: boolean) => void;
  quickCreateInitialType: 'project' | 'task' | 'todo' | 'meeting' | 'goal' | 'file';
  openQuickCreate: (type?: 'project' | 'task' | 'todo' | 'meeting' | 'goal' | 'file') => void;

  isSuspiciousLoginOpen: boolean;
  setIsSuspiciousLoginOpen: (open: boolean) => void;
  resolveSuspiciousLogin: (action: 'confirm' | 'secure') => void;

  isHelpModalOpen: boolean;
  setIsHelpModalOpen: (open: boolean) => void;

  isDailyBriefingOpen: boolean;
  setIsDailyBriefingOpen: (open: boolean) => void;
  openDailyBriefing: () => void;

  resetAllData: () => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

const STORAGE_KEY_PREFIX = 'tasknova_data_v1_';

function loadFromStorage<T>(key: string, fallback: T): T {
  try {
    const saved = localStorage.getItem(STORAGE_KEY_PREFIX + key);
    if (saved) return JSON.parse(saved);
  } catch (e) {
    console.error(`Failed to load ${key} from storage`, e);
  }
  return fallback;
}

function saveToStorage<T>(key: string, value: T): void {
  try {
    localStorage.setItem(STORAGE_KEY_PREFIX + key, JSON.stringify(value));
  } catch (e) {
    console.error(`Failed to save ${key} to storage`, e);
  }
}

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [activeTab, setActiveTabState] = useState<NavigationTab>(() => 
    loadFromStorage('activeTab', 'dashboard')
  );
  const [selectedProjectId, setSelectedProjectId] = useState<string>('p1');
  const [projectDetailsSubTab, setProjectDetailsSubTab] = useState<string>('Overview');

  const [userProfile, setUserProfile] = useState<UserProfile>(() =>
    loadFromStorage('userProfile', initialUserProfile)
  );

  const [projects, setProjects] = useState<Project[]>(() =>
    loadFromStorage('projects', initialProjects)
  );

  const [tasks, setTasks] = useState<Task[]>(() =>
    loadFromStorage('tasks', initialTasks)
  );

  const [todos, setTodos] = useState<ToDoItem[]>(() =>
    loadFromStorage('todos', initialToDos)
  );

  const [teamMembers, setTeamMembers] = useState<TeamMember[]>(() =>
    loadFromStorage('teamMembers', initialTeamMembers)
  );

  const [comments, setComments] = useState<ProjectComment[]>(() =>
    loadFromStorage('comments', initialComments)
  );

  const [activities, setActivities] = useState<ActivityItem[]>(() =>
    loadFromStorage('activities', initialActivities)
  );

  const [notifications, setNotifications] = useState<NotificationItem[]>(() =>
    loadFromStorage('notifications', initialNotifications)
  );

  const [events, setEvents] = useState<CalendarEvent[]>(() =>
    loadFromStorage('events', initialEvents)
  );

  const [studyPlan, setStudyPlan] = useState<StudyPlan>(() =>
    loadFromStorage('studyPlan', initialStudyPlan)
  );

  const [studyResources, setStudyResources] = useState<StudyResource[]>(() =>
    loadFromStorage('studyResources', initialStudyResources)
  );

  const [files, setFiles] = useState<ProjectFile[]>(() =>
    loadFromStorage('files', initialFiles)
  );

  const [auditLogs, setAuditLogs] = useState<AuditLogItem[]>(() =>
    loadFromStorage('auditLogs', initialAuditLogs)
  );

  const [searchQuery, setSearchQuery] = useState('');

  // Modals
  const [isQuickCreateOpen, setIsQuickCreateOpen] = useState(false);
  const [quickCreateInitialType, setQuickCreateInitialType] = useState<'project' | 'task' | 'todo' | 'meeting' | 'goal' | 'file'>('project');
  const [isSuspiciousLoginOpen, setIsSuspiciousLoginOpen] = useState(false);
  const [isHelpModalOpen, setIsHelpModalOpen] = useState(false);
  const [isDailyBriefingOpen, setIsDailyBriefingOpen] = useState(false);

  const openDailyBriefing = () => setIsDailyBriefingOpen(true);

  // Background Backend Live Sync
  useEffect(() => {
    let isMounted = true;
    async function syncBackendData() {
      try {
        let token = apiClient.getToken();
        if (!token) {
          try {
            const authRes = await apiClient.auth.login('shivam.singh@tasknova.app', 'Password@123');
            if (authRes.token) token = authRes.token;
          } catch {
            // Offline / fallback to local storage
          }
        }

        if (token) {
          // Sync projects
          const backendProjects = await apiClient.projects.list();
          if (isMounted && Array.isArray(backendProjects) && backendProjects.length > 0) {
            setProjects(backendProjects.map((p: any) => ({
              id: p.id,
              name: p.name,
              description: p.description,
              category: p.category,
              status: p.status,
              priority: p.priority,
              progress: p.progress,
              deadline: p.deadline,
              owner: p.ownerName,
              team: p.members ? p.members.map((m: any) => m.memberName) : ['Shivam Singh'],
              tags: [p.category],
              taskCount: p.tasks ? p.tasks.length : 0,
              completedTaskCount: p.tasks ? p.tasks.filter((t: any) => t.status === 'COMPLETED').length : 0,
              milestones: p.milestones || [],
              visibility: p.visibility
            })));
          }

          // Sync tasks
          const backendTasks = await apiClient.tasks.list();
          if (isMounted && Array.isArray(backendTasks) && backendTasks.length > 0) {
            setTasks(backendTasks.map((t: any) => ({
              id: t.id,
              projectId: t.projectId,
              projectName: t.projectName || t.project?.name || 'Distributed Neural Cloud Engine',
              title: t.title,
              description: t.description || '',
              priority: t.priority as any,
              status: t.status as any,
              assignee: {
                name: t.assigneeName || 'Shivam Singh',
                avatarColor: 'bg-indigo-600'
              },
              dueDate: t.dueDate,
              commentsCount: 2,
              attachmentIndicator: t.attachmentIndicator || false,
              tags: t.tags || ['Sprint']
            })));
          }

          // Sync todos
          const backendTodos = await apiClient.todos.list();
          if (isMounted && Array.isArray(backendTodos) && backendTodos.length > 0) {
            setTodos(backendTodos.map((td: any) => ({
              id: td.id,
              title: td.title,
              completed: td.completed,
              priority: td.priority as any,
              dueDate: td.dueDate,
              category: td.category as any,
              tags: td.tags || [td.category],
              notes: td.notes
            })));
          }
        }
      } catch (e) {
        console.warn('Backend sync error, utilizing local storage cache:', e);
      }
    }

    syncBackendData();
    return () => { isMounted = false; };
  }, []);

  // Sync to localStorage
  useEffect(() => saveToStorage('userProfile', userProfile), [userProfile]);
  useEffect(() => saveToStorage('projects', projects), [projects]);
  useEffect(() => saveToStorage('tasks', tasks), [tasks]);
  useEffect(() => saveToStorage('todos', todos), [todos]);
  useEffect(() => saveToStorage('teamMembers', teamMembers), [teamMembers]);
  useEffect(() => saveToStorage('comments', comments), [comments]);
  useEffect(() => saveToStorage('activities', activities), [activities]);
  useEffect(() => saveToStorage('notifications', notifications), [notifications]);
  useEffect(() => saveToStorage('events', events), [events]);
  useEffect(() => saveToStorage('studyPlan', studyPlan), [studyPlan]);
  useEffect(() => saveToStorage('studyResources', studyResources), [studyResources]);
  useEffect(() => saveToStorage('files', files), [files]);
  useEffect(() => saveToStorage('auditLogs', auditLogs), [auditLogs]);
  useEffect(() => saveToStorage('activeTab', activeTab), [activeTab]);

  // Apply dark/light class to root
  useEffect(() => {
    const root = document.documentElement;
    if (userProfile.appearance === 'light') {
      root.classList.remove('dark');
      root.classList.add('light');
    } else {
      root.classList.remove('light');
      root.classList.add('dark');
    }
  }, [userProfile.appearance]);

  const setActiveTab = (tab: NavigationTab) => {
    setActiveTabState(tab);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const openProjectDetails = (projectId: string, subTab: string = 'Overview') => {
    setSelectedProjectId(projectId);
    setProjectDetailsSubTab(subTab);
    setActiveTab('project-details');
  };

  const openQuickCreate = (type: 'project' | 'task' | 'todo' | 'meeting' | 'goal' | 'file' = 'project') => {
    setQuickCreateInitialType(type);
    setIsQuickCreateOpen(true);
  };

  const updateUserProfile = (updates: Partial<UserProfile>) => {
    setUserProfile(prev => ({ ...prev, ...updates }));
  };

  const updatePrivacySetting = (key: keyof UserProfile['privacy'], value: any) => {
    setUserProfile(prev => ({
      ...prev,
      privacy: { ...prev.privacy, [key]: value }
    }));
  };

  const toggle2FA = () => {
    setUserProfile(prev => {
      const nextState = !prev.security.twoFactorEnabled;
      return {
        ...prev,
        security: { ...prev.security, twoFactorEnabled: nextState }
      };
    });
    addAuditLog({
      title: userProfile.security.twoFactorEnabled ? 'Two-Factor Authentication Disabled' : 'Two-Factor Authentication Enabled',
      description: `User toggled 2FA to ${!userProfile.security.twoFactorEnabled ? 'ACTIVE' : 'INACTIVE'}`,
      user: userProfile.name,
      severity: userProfile.security.twoFactorEnabled ? 'warning' : 'info'
    });
  };

  const addProject = (proj: Omit<Project, 'id' | 'completedTaskCount'>) => {
    const id = `p${Date.now()}`;
    const newProject: Project = {
      ...proj,
      id,
      completedTaskCount: 0
    };
    setProjects(prev => [newProject, ...prev]);
    addActivity({
      authorName: userProfile.name,
      action: 'created',
      target: `Project "${proj.name}"`,
      type: 'create',
      projectId: id
    });
    // Persist to backend database
    apiClient.projects.create({
      name: proj.name,
      description: proj.description,
      category: proj.category,
      priority: proj.priority,
      deadline: proj.deadline,
      visibility: proj.visibility,
      ownerName: userProfile.name
    }).catch(e => console.warn('Backend project creation sync:', e));
  };

  const updateProject = (id: string, updates: Partial<Project>) => {
    setProjects(prev => prev.map(p => p.id === id ? { ...p, ...updates } : p));
    apiClient.projects.update(id, updates).catch(e => console.warn('Backend project update sync:', e));
  };

  const deleteProject = (id: string) => {
    const target = projects.find(p => p.id === id);
    setProjects(prev => prev.filter(p => p.id !== id));
    if (target) {
      addActivity({
        authorName: userProfile.name,
        action: 'deleted',
        target: `Project "${target.name}"`,
        type: 'complete'
      });
      apiClient.projects.delete(id).catch(e => console.warn('Backend project deletion sync:', e));
    }
  };

  const addTask = (taskData: Omit<Task, 'id' | 'commentsCount' | 'attachmentIndicator'>) => {
    const id = `t${Date.now()}`;
    const project = projects.find(p => p.id === taskData.projectId);
    const newTask: Task = {
      ...taskData,
      id,
      projectName: project ? project.name : taskData.projectName || 'Unassigned',
      commentsCount: 0,
      attachmentIndicator: false
    };
    setTasks(prev => [newTask, ...prev]);
    addActivity({
      authorName: userProfile.name,
      action: 'created',
      target: `Task "${newTask.title}"`,
      type: 'create',
      projectId: newTask.projectId
    });
    // Update taskCount on project
    if (taskData.projectId) {
      setProjects(prev => prev.map(p => p.id === taskData.projectId ? { ...p, taskCount: p.taskCount + 1 } : p));
    }
    // Persist to backend database
    apiClient.tasks.create({
      projectId: taskData.projectId,
      title: taskData.title,
      description: taskData.description,
      priority: taskData.priority,
      status: taskData.status,
      assigneeName: taskData.assignee?.name || userProfile.name,
      dueDate: taskData.dueDate,
      tags: taskData.tags
    }).catch(e => console.warn('Backend task creation sync:', e));
  };

  const updateTask = (id: string, updates: Partial<Task>) => {
    setTasks(prev => prev.map(t => t.id === id ? { ...t, ...updates } : t));
    apiClient.tasks.update(id, updates).catch(e => console.warn('Backend task update sync:', e));
  };

  const deleteTask = (id: string) => {
    const target = tasks.find(t => t.id === id);
    setTasks(prev => prev.filter(t => t.id !== id));
    if (target && target.projectId) {
      setProjects(prev => prev.map(p => p.id === target.projectId ? { ...p, taskCount: Math.max(0, p.taskCount - 1) } : p));
    }
    apiClient.tasks.delete(id).catch(e => console.warn('Backend task delete sync:', e));
  };

  const moveTaskStatus = (taskId: string, newStatus: TaskStatus) => {
    setTasks(prev => prev.map(t => {
      if (t.id === taskId) {
        return { ...t, status: newStatus };
      }
      return t;
    }));
    const t = tasks.find(task => task.id === taskId);
    if (t) {
      addActivity({
        authorName: userProfile.name,
        action: 'moved',
        target: `"${t.title}" to ${newStatus}`,
        type: 'status_change',
        projectId: t.projectId
      });
      // Persist Kanban move to backend
      apiClient.tasks.updateStatus(taskId, newStatus).catch(e => console.warn('Backend status move sync:', e));
    }
  };

  const toggleTaskCompletion = (taskId: string) => {
    setTasks(prev => prev.map(t => {
      if (t.id === taskId) {
        const isNowComplete = t.status !== 'COMPLETED';
        const newStatus: TaskStatus = isNowComplete ? 'COMPLETED' : 'IN PROGRESS';
        if (isNowComplete && t.projectId) {
          setProjects(pList => pList.map(p => p.id === t.projectId ? { ...p, completedTaskCount: p.completedTaskCount + 1 } : p));
        }
        apiClient.tasks.updateStatus(taskId, newStatus).catch(e => console.warn('Backend task status sync:', e));
        return { ...t, status: newStatus };
      }
      return t;
    }));
  };

  const addToDo = (todoData: Omit<ToDoItem, 'id' | 'completed'>) => {
    const id = `td${Date.now()}`;
    const newToDo: ToDoItem = {
      ...todoData,
      id,
      completed: false
    };
    setTodos(prev => [newToDo, ...prev]);
    apiClient.todos.create({
      title: todoData.title,
      priority: todoData.priority,
      dueDate: todoData.dueDate,
      category: todoData.category,
      tags: todoData.tags,
      notes: todoData.notes
    }).catch(e => console.warn('Backend todo create sync:', e));
  };

  const toggleToDo = (id: string) => {
    setTodos(prev => prev.map(td => td.id === id ? { ...td, completed: !td.completed } : td));
    apiClient.todos.toggle(id).catch(e => console.warn('Backend todo toggle sync:', e));
  };

  const updateToDo = (id: string, updates: Partial<ToDoItem>) => {
    setTodos(prev => prev.map(td => td.id === id ? { ...td, ...updates } : td));
  };

  const deleteToDo = (id: string) => {
    setTodos(prev => prev.filter(td => td.id !== id));
    apiClient.todos.delete(id).catch(e => console.warn('Backend todo delete sync:', e));
  };

  const updateMemberRole = (memberId: string, newRole: RoleType) => {
    setTeamMembers(prev => prev.map(m => m.id === memberId ? { ...m, roleType: newRole } : m));
    addAuditLog({
      title: 'Role Permissions Changed',
      description: `Updated member permissions to ${newRole}`,
      user: userProfile.name,
      severity: 'info'
    });
  };

  const addTeamMember = (memberData: Omit<TeamMember, 'id'>) => {
    const id = `m${Date.now()}`;
    const newMember: TeamMember = { ...memberData, id };
    setTeamMembers(prev => [...prev, newMember]);
    addActivity({
      authorName: userProfile.name,
      action: 'invited',
      target: `${newMember.name} (${newMember.role})`,
      type: 'create'
    });
  };

  const addComment = (projectId: string, content: string, attachments?: string[]) => {
    const id = `c${Date.now()}`;
    const project = projects.find(p => p.id === projectId);
    const newComment: ProjectComment = {
      id,
      projectId,
      projectName: project ? project.name : 'General',
      authorName: userProfile.name,
      authorRole: userProfile.role,
      content,
      timestamp: 'Just now',
      pinned: false,
      reactions: [],
      replies: [],
      attachments
    };
    setComments(prev => [newComment, ...prev]);
    addActivity({
      authorName: userProfile.name,
      action: 'commented on',
      target: project ? `Project "${project.name}"` : 'Team Board',
      type: 'comment',
      projectId
    });
  };

  const addReply = (commentId: string, content: string) => {
    const reply = {
      id: `r${Date.now()}`,
      authorName: userProfile.name,
      authorRole: userProfile.role,
      content,
      timestamp: 'Just now'
    };
    setComments(prev => prev.map(c => c.id === commentId ? { ...c, replies: [...c.replies, reply] } : c));
  };

  const addReaction = (commentId: string, emoji: string) => {
    setComments(prev => prev.map(c => {
      if (c.id !== commentId) return c;
      const existing = c.reactions.find(r => r.emoji === emoji);
      if (existing) {
        const hasReacted = existing.users.includes(userProfile.name);
        if (hasReacted) {
          return {
            ...c,
            reactions: c.reactions.map(r => r.emoji === emoji ? {
              ...r,
              count: r.count - 1,
              users: r.users.filter(u => u !== userProfile.name)
            } : r).filter(r => r.count > 0)
          };
        } else {
          return {
            ...c,
            reactions: c.reactions.map(r => r.emoji === emoji ? {
              ...r,
              count: r.count + 1,
              users: [...r.users, userProfile.name]
            } : r)
          };
        }
      } else {
        return {
          ...c,
          reactions: [...c.reactions, { emoji, count: 1, users: [userProfile.name] }]
        };
      }
    }));
  };

  const togglePinComment = (commentId: string) => {
    setComments(prev => prev.map(c => c.id === commentId ? { ...c, pinned: !c.pinned } : c));
  };

  const deleteComment = (commentId: string) => {
    setComments(prev => prev.filter(c => c.id !== commentId));
  };

  const addActivity = (actData: Omit<ActivityItem, 'id' | 'timestamp'>) => {
    const newAct: ActivityItem = {
      ...actData,
      id: `act${Date.now()}`,
      timestamp: 'Just now'
    };
    setActivities(prev => [newAct, ...prev.slice(0, 19)]);
  };

  const markNotificationAsRead = (id: string) => {
    setNotifications(prev => prev.map(n => n.id === id ? { ...n, read: true } : n));
  };

  const markAllNotificationsAsRead = () => {
    setNotifications(prev => prev.map(n => ({ ...n, read: true })));
  };

  const addNotification = (item: Omit<NotificationItem, 'id' | 'timestamp' | 'read'>) => {
    const newItem: NotificationItem = {
      ...item,
      id: `n${Date.now()}`,
      timestamp: 'Just now',
      read: false
    };
    setNotifications(prev => [newItem, ...prev]);
  };

  const addEvent = (evData: Omit<CalendarEvent, 'id'>) => {
    const newEv: CalendarEvent = { ...evData, id: `ev${Date.now()}` };
    setEvents(prev => [...prev, newEv]);
  };

  const deleteEvent = (id: string) => {
    setEvents(prev => prev.filter(e => e.id !== id));
  };

  const toggleStudyDayCompleted = (dayNumber: number) => {
    setStudyPlan(prev => {
      const updatedDays = prev.days.map(d => d.dayNumber === dayNumber ? { ...d, completed: !d.completed } : d);
      const completedCount = updatedDays.filter(d => d.completed).length;
      const progress = Math.round((completedCount / updatedDays.length) * 100);
      return {
        ...prev,
        days: updatedDays,
        progress
      };
    });
  };

  const generateNewPlan = (subject: string, examDate: string, hours: number, difficulty: StudyPlan['difficulty']) => {
    const planTopics = [
      'Foundations & Core Principles',
      'Data Structures & Memory Models',
      'Algorithmic Patterns & Complexity',
      'Advanced Problem Solving & Edge Cases',
      'System Integration & Practical Lab',
      'Mock Problem Solving & Diagnostic Test',
      'Final Revision & Exam Blueprint Mastery'
    ];
    const newPlan: StudyPlan = {
      id: `sp${Date.now()}`,
      subject,
      examDate,
      availableHoursPerDay: hours,
      difficulty,
      progress: 0,
      weakTopics: ['Algorithmic Patterns & Complexity', 'System Integration & Practical Lab'],
      days: planTopics.map((topic, i) => ({
        dayNumber: i + 1,
        topic,
        durationHours: hours,
        completed: false,
        weakArea: i === 2 || i === 4
      }))
    };
    setStudyPlan(newPlan);
  };

  const toggleSaveResource = (id: string) => {
    setStudyResources(prev => prev.map(r => r.id === id ? { ...r, saved: !r.saved } : r));
  };

  const addStudyResource = (resData: Omit<StudyResource, 'id' | 'saved'>) => {
    const newRes: StudyResource = { ...resData, id: `sr${Date.now()}`, saved: true };
    setStudyResources(prev => [newRes, ...prev]);
  };

  const uploadFile = (fileData: Omit<ProjectFile, 'id' | 'uploadedAt'>) => {
    const newFile: ProjectFile = {
      ...fileData,
      id: `f${Date.now()}`,
      uploadedAt: 'Just now'
    };
    setFiles(prev => [newFile, ...prev]);
    addActivity({
      authorName: userProfile.name,
      action: 'uploaded',
      target: `"${newFile.name}"`,
      type: 'upload',
      projectId: newFile.projectId
    });
  };

  const deleteFile = (id: string) => {
    setFiles(prev => prev.filter(f => f.id !== id));
  };

  const addAuditLog = (logData: Omit<AuditLogItem, 'id' | 'timestamp'>) => {
    const newLog: AuditLogItem = {
      ...logData,
      id: `al${Date.now()}`,
      timestamp: 'Just now'
    };
    setAuditLogs(prev => [newLog, ...prev]);
  };

  const resolveSuspiciousLogin = (action: 'confirm' | 'secure') => {
    setIsSuspiciousLoginOpen(false);
    if (action === 'confirm') {
      addAuditLog({
        title: 'Device Verified by User',
        description: 'User confirmed Windows PC login from Patna as authorized.',
        user: userProfile.name,
        severity: 'info'
      });
    } else {
      addAuditLog({
        title: 'Security Alert: Session Revoked',
        description: 'User marked device as unauthorized. Active tokens invalidated.',
        user: userProfile.name,
        severity: 'danger'
      });
    }
  };

  const resetAllData = () => {
    localStorage.clear();
    setUserProfile(initialUserProfile);
    setProjects(initialProjects);
    setTasks(initialTasks);
    setTodos(initialToDos);
    setTeamMembers(initialTeamMembers);
    setComments(initialComments);
    setActivities(initialActivities);
    setNotifications(initialNotifications);
    setEvents(initialEvents);
    setStudyPlan(initialStudyPlan);
    setStudyResources(initialStudyResources);
    setFiles(initialFiles);
    setAuditLogs(initialAuditLogs);
    setActiveTab('dashboard');
  };

  return (
    <AppContext.Provider
      value={{
        activeTab,
        setActiveTab,
        selectedProjectId,
        setSelectedProjectId,
        openProjectDetails,
        projectDetailsSubTab,
        setProjectDetailsSubTab,
        userProfile,
        updateUserProfile,
        updatePrivacySetting,
        toggle2FA,
        projects,
        addProject,
        updateProject,
        deleteProject,
        tasks,
        addTask,
        updateTask,
        deleteTask,
        moveTaskStatus,
        toggleTaskCompletion,
        todos,
        addToDo,
        toggleToDo,
        updateToDo,
        deleteToDo,
        teamMembers,
        updateMemberRole,
        addTeamMember,
        comments,
        addComment,
        addReply,
        addReaction,
        togglePinComment,
        deleteComment,
        activities,
        addActivity,
        notifications,
        markNotificationAsRead,
        markAllNotificationsAsRead,
        addNotification,
        events,
        addEvent,
        deleteEvent,
        studyPlan,
        toggleStudyDayCompleted,
        generateNewPlan,
        studyResources,
        toggleSaveResource,
        addStudyResource,
        files,
        uploadFile,
        deleteFile,
        auditLogs,
        addAuditLog,
        searchQuery,
        setSearchQuery,
        isQuickCreateOpen,
        setIsQuickCreateOpen,
        quickCreateInitialType,
        openQuickCreate,
        isSuspiciousLoginOpen,
        setIsSuspiciousLoginOpen,
        resolveSuspiciousLogin,
        isHelpModalOpen,
        setIsHelpModalOpen,
        isDailyBriefingOpen,
        setIsDailyBriefingOpen,
        openDailyBriefing,
        resetAllData
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = (): AppContextType => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
