import { Router, Response } from 'express';
import { PrismaClient } from '@prisma/client';
import { GoogleGenAI } from '@google/genai';
import { authenticate, AuthRequest } from '../middleware/auth';

const router = Router();
const prisma = new PrismaClient();

// Helper to initialize GoogleGenAI safely
function getGeminiClient(): GoogleGenAI | null {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === 'your_gemini_api_key_here') {
    return null;
  }
  try {
    return new GoogleGenAI({ apiKey });
  } catch (e) {
    console.warn('Failed to initialize GoogleGenAI client:', e);
    return null;
  }
}

// -------------------------------------------------------------------
// AI CONVERSATIONAL CHAT
// -------------------------------------------------------------------
router.post('/chat', authenticate, async (req: AuthRequest, res: Response) => {
  try {
    const { message, conversationId, history = [] } = req.body;
    if (!message) {
      return res.status(400).json({ error: 'Message is required' });
    }

    const userName = req.user?.name || 'Shivam Singh';
    let targetConvId = conversationId;

    // Create or retrieve conversation
    if (!targetConvId) {
      const newConv = await prisma.aIConversation.create({
        data: {
          userId: req.user?.id,
          title: message.substring(0, 30) + '...'
        }
      });
      targetConvId = newConv.id;
    }

    // Save user message
    await prisma.aIMessage.create({
      data: {
        conversationId: targetConvId,
        sender: 'user',
        text: message
      }
    });

    let replyText = '';
    const ai = getGeminiClient();

    if (ai) {
      try {
        const systemPrompt = `You are TASKNOVA AI, an intelligent project management and academic productivity copilot. You are assisting ${userName}, who is a Student & Project Contributor. Be concise, structured, helpful, and professional. Use markdown formatting.`;
        
        const contents = [
          { role: 'user', parts: [{ text: `${systemPrompt}\n\nUser Question: ${message}` }] }
        ];

        const response = await ai.models.generateContent({
          model: 'gemini-2.5-flash',
          contents: contents as any
        });

        replyText = response.text || "I'm here to help you plan, collaborate, and achieve your goals.";
      } catch (err: any) {
        console.warn('Gemini API call failed, using intelligent built-in fallback:', err?.message || err);
        replyText = generateFallbackChatResponse(message, userName);
      }
    } else {
      replyText = generateFallbackChatResponse(message, userName);
    }

    // Save AI reply
    const savedReply = await prisma.aIMessage.create({
      data: {
        conversationId: targetConvId,
        sender: 'assistant',
        text: replyText
      }
    });

    res.json({
      conversationId: targetConvId,
      reply: replyText,
      messageId: savedReply.id
    });
  } catch (error) {
    console.error('AI chat error:', error);
    res.status(500).json({ error: 'AI processing failed' });
  }
});

function generateFallbackChatResponse(message: string, userName: string): string {
  const lower = message.toLowerCase();
  if (lower.includes('today') || lower.includes('work on') || lower.includes('priorit')) {
    return `Hello ${userName}! Here is your strategic recommendation for today:\n\n1. **Finish Auth Middleware & Security Auditing** (High Priority, Due Soon)\n2. **Review Team Pull Requests** for the Frontend Dashboard\n3. **30-Min Focused Study Session** on Distributed Systems or Algorithms\n\nWould you like me to schedule these directly into your calendar?`;
  }
  if (lower.includes('study') || lower.includes('exam') || lower.includes('revision')) {
    return `For optimal retention, I recommend the **Feynman + Pomodoro Technique**:\n- 25-minute concentrated sprint on core theorems\n- 5-minute active recall break\n- Test yourself with practice questions before reviewing solutions.\n\nCheck the **Study Hub** tab to launch a dedicated Focus Session with ambient sounds!`;
  }
  if (lower.includes('project') || lower.includes('plan') || lower.includes('task')) {
    return `To structure your project effectively, break it down into four distinct phases:\n1. **Discovery & Architecture Spec**\n2. **Core Implementation & Database Models**\n3. **API Integration & Validation**\n4. **Deployment & Performance Auditing**\n\nYou can use our **AI Project Planner** tab to generate a complete interactive Kanban breakdown with one click!`;
  }
  return `As your TASKNOVA AI assistant, I can help you organize tasks, break down complex milestones, generate study plans, search academic papers, and optimize your sprint schedule. What would you like to accomplish next, ${userName}?`;
}

// -------------------------------------------------------------------
// AI PROJECT BREAKDOWN (With instant task generation)
// -------------------------------------------------------------------
router.post('/project-plan', authenticate, async (req: AuthRequest, res: Response) => {
  try {
    const { title, goal, techStack = 'TypeScript, React, Node.js', timeline = '4 weeks' } = req.body;
    if (!title) {
      return res.status(400).json({ error: 'Project title is required' });
    }

    const ai = getGeminiClient();
    let planData: any = null;

    if (ai) {
      try {
        const prompt = `Generate a comprehensive project execution plan for:
Project Name: "${title}"
Goal: "${goal || 'Build a scalable, modern software solution'}"
Tech Stack: "${techStack}"
Timeline: "${timeline}"

Respond ONLY with valid JSON in this exact structure:
{
  "summary": "Brief executive summary",
  "estimatedDuration": "${timeline}",
  "phases": [
    {
      "name": "Phase 1: Architecture & Foundations",
      "duration": "1 week",
      "tasks": [
        {
          "title": "Setup repository and database schemas",
          "priority": "High",
          "estimatedHours": 8,
          "tags": ["Architecture", "Database"]
        }
      ]
    }
  ],
  "potentialRisks": [
    "Identified technical or timeline risk with mitigation strategy"
  ]
}`;

        const response = await ai.models.generateContent({
          model: 'gemini-2.5-flash',
          contents: prompt
        });

        const rawText = response.text || '{}';
        const cleaned = rawText.replace(/```json/g, '').replace(/```/g, '').trim();
        planData = JSON.parse(cleaned);
      } catch (err) {
        console.warn('Gemini project plan generation error, using fallback:', err);
      }
    }

    if (!planData || !planData.phases) {
      planData = {
        summary: `Strategic execution roadmap for ${title} focusing on high reliability and clear team delegation.`,
        estimatedDuration: timeline,
        phases: [
          {
            name: 'Phase 1: Architecture & API Design',
            duration: '1 week',
            tasks: [
              { title: 'Define relational database schema and migration scripts', priority: 'High', estimatedHours: 6, tags: ['Database', 'Backend'] },
              { title: 'Design RESTful API routes and JWT authentication guards', priority: 'High', estimatedHours: 8, tags: ['Security', 'API'] },
              { title: 'Setup CI/CD linting and environment configuration', priority: 'Medium', estimatedHours: 4, tags: ['DevOps'] }
            ]
          },
          {
            name: 'Phase 2: Core Feature Implementation',
            duration: '2 weeks',
            tasks: [
              { title: 'Implement frontend UI components and responsive views', priority: 'High', estimatedHours: 14, tags: ['Frontend', 'React'] },
              { title: 'Connect state management to backend endpoints', priority: 'High', estimatedHours: 10, tags: ['Integration'] },
              { title: 'Build automated regression test suites', priority: 'Medium', estimatedHours: 6, tags: ['QA', 'Testing'] }
            ]
          },
          {
            name: 'Phase 3: Security, Performance & Deployment',
            duration: '1 week',
            tasks: [
              { title: 'Conduct vulnerability scanning and RBAC permission testing', priority: 'Critical', estimatedHours: 5, tags: ['Security'] },
              { title: 'Optimize bundle size and database queries', priority: 'Medium', estimatedHours: 4, tags: ['Optimization'] },
              { title: 'Deploy to production environment and configure health monitoring', priority: 'High', estimatedHours: 4, tags: ['Release'] }
            ]
          }
        ],
        potentialRisks: [
          'Scope creep during phase 2: Mitigate by locking API contracts early.',
          'Database migration latency under load: Mitigate with proper indexes.'
        ]
      };
    }

    res.json(planData);
  } catch (error) {
    console.error('Project plan error:', error);
    res.status(500).json({ error: 'Failed to generate project plan' });
  }
});

// -------------------------------------------------------------------
// CREATE TASKS AUTOMATICALLY FROM GENERATED PLAN
// -------------------------------------------------------------------
router.post('/create-tasks-from-plan', authenticate, async (req: AuthRequest, res: Response) => {
  try {
    const { projectId, tasks } = req.body;
    if (!projectId || !Array.isArray(tasks) || tasks.length === 0) {
      return res.status(400).json({ error: 'projectId and non-empty tasks array are required' });
    }

    const project = await prisma.project.findUnique({ where: { id: projectId } });
    if (!project) {
      return res.status(404).json({ error: 'Project not found' });
    }

    const createdTasks = [];
    const defaultAssignee = req.user?.name || 'Shivam Singh';

    for (const t of tasks) {
      const task = await prisma.task.create({
        data: {
          projectId,
          title: t.title || 'Untitled Generated Task',
          description: t.description || `Generated by TASKNOVA AI (${t.estimatedHours || 4}h estimated)`,
          priority: t.priority || 'Medium',
          status: 'TO DO',
          assigneeName: t.assigneeName || defaultAssignee,
          assigneeId: req.user?.id,
          dueDate: t.dueDate || new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
          tags: JSON.stringify(t.tags || ['AI-Plan'])
        }
      });
      createdTasks.push(task);
    }

    // Log activity
    await prisma.activity.create({
      data: {
        authorName: defaultAssignee,
        action: `generated and imported ${createdTasks.length} tasks with AI`,
        target: project.name,
        type: 'create',
        projectId
      }
    });

    res.status(201).json({
      message: `Successfully imported ${createdTasks.length} tasks into project`,
      tasks: createdTasks
    });
  } catch (error) {
    console.error('Create tasks from plan error:', error);
    res.status(500).json({ error: 'Failed to import tasks' });
  }
});

// -------------------------------------------------------------------
// AI STUDY PLANNER
// -------------------------------------------------------------------
router.post('/study-plan', authenticate, async (req: AuthRequest, res: Response) => {
  try {
    const { subject, examDate, availableHoursPerDay = 3.0, weakAreas = [] } = req.body;
    if (!subject || !examDate) {
      return res.status(400).json({ error: 'subject and examDate are required' });
    }

    const ai = getGeminiClient();
    let curriculum: any = null;

    if (ai) {
      try {
        const prompt = `Create a structured day-by-day revision schedule for:
Subject: ${subject}
Exam Date: ${examDate}
Daily Study Capacity: ${availableHoursPerDay} hours
Weak Topics needing extra reinforcement: ${weakAreas.join(', ') || 'None specified'}

Respond strictly with valid JSON:
{
  "curriculum": [
    {
      "dayNumber": 1,
      "topic": "Core Fundamentals & Notation",
      "durationHours": 2.5,
      "weakArea": false,
      "suggestedTechnique": "Active Recall & Mind-mapping"
    }
  ],
  "studyTips": ["Strategic advice 1", "Strategic advice 2"]
}`;

        const resp = await ai.models.generateContent({
          model: 'gemini-2.5-flash',
          contents: prompt
        });

        const raw = (resp.text || '{}').replace(/```json/g, '').replace(/```/g, '').trim();
        curriculum = JSON.parse(raw);
      } catch (err) {
        console.warn('Gemini study plan error, fallback triggered:', err);
      }
    }

    if (!curriculum || !curriculum.curriculum) {
      curriculum = {
        curriculum: [
          { dayNumber: 1, topic: `${subject}: Core Principles & Conceptual Overview`, durationHours: Number(availableHoursPerDay), weakArea: false, suggestedTechnique: 'Feynman Technique & Summary Notes' },
          { dayNumber: 2, topic: `${subject}: Problem Solving & Formula Applications`, durationHours: Number(availableHoursPerDay), weakArea: true, suggestedTechnique: 'Spaced Practice Problems' },
          { dayNumber: 3, topic: `${subject}: Advanced Case Studies & Edge Cases`, durationHours: Number(availableHoursPerDay), weakArea: true, suggestedTechnique: 'Flashcard Drills & Self-Testing' },
          { dayNumber: 4, topic: `${subject}: Timed Mock Examination & Gap Analysis`, durationHours: Number(availableHoursPerDay), weakArea: false, suggestedTechnique: 'Exam Simulation' },
          { dayNumber: 5, topic: `${subject}: High-Yield Rapid Review & Error Rectification`, durationHours: Number(availableHoursPerDay), weakArea: false, suggestedTechnique: 'Light Review & Sleep Consolidation' }
        ],
        studyTips: [
          'Prioritize active recall over passive reading of lecture slides.',
          'Take 5-minute breaks every 25-30 minutes to sustain high cognitive focus.',
          'Solve past papers under strict exam time constraints.'
        ]
      };
    }

    res.json(curriculum);
  } catch (error) {
    console.error('Study plan error:', error);
    res.status(500).json({ error: 'Failed to generate study plan' });
  }
});

// -------------------------------------------------------------------
// AI QUIZ GENERATOR
// -------------------------------------------------------------------
router.post('/quiz', authenticate, async (req: AuthRequest, res: Response) => {
  try {
    const { topic = 'Data Structures & Algorithms', questionCount = 5 } = req.body;
    const ai = getGeminiClient();
    let quiz: any = null;

    if (ai) {
      try {
        const prompt = `Generate a ${questionCount}-question multiple choice quiz on the topic: "${topic}".
Respond strictly with valid JSON:
{
  "topic": "${topic}",
  "questions": [
    {
      "id": 1,
      "question": "Question text here",
      "options": ["Option A", "Option B", "Option C", "Option D"],
      "correctAnswer": 0,
      "explanation": "Why option A is correct"
    }
  ]
}`;

        const resp = await ai.models.generateContent({
          model: 'gemini-2.5-flash',
          contents: prompt
        });

        const raw = (resp.text || '{}').replace(/```json/g, '').replace(/```/g, '').trim();
        quiz = JSON.parse(raw);
      } catch (err) {
        console.warn('Gemini quiz error, fallback triggered:', err);
      }
    }

    if (!quiz || !quiz.questions) {
      quiz = {
        topic,
        questions: [
          {
            id: 1,
            question: `What is the worst-case time complexity of searching in a balanced Binary Search Tree?`,
            options: ['O(1)', 'O(log n)', 'O(n)', 'O(n log n)'],
            correctAnswer: 1,
            explanation: 'A balanced binary search tree guarantees O(log n) height, yielding O(log n) worst-case search complexity.'
          },
          {
            id: 2,
            question: `Which data structure operates on a Last-In-First-Out (LIFO) principle?`,
            options: ['Queue', 'Stack', 'Linked List', 'Hash Map'],
            correctAnswer: 1,
            explanation: 'A Stack is a LIFO data structure where elements are pushed and popped from the same end.'
          },
          {
            id: 3,
            question: `In HTTP/REST API design, which idempotent method is best suited for resource replacement?`,
            options: ['POST', 'PUT', 'PATCH', 'OPTIONS'],
            correctAnswer: 1,
            explanation: 'PUT replaces an entire target resource idempotently, meaning multiple identical requests produce the same state.'
          },
          {
            id: 4,
            question: `What ensures database transaction ACID properties against concurrent race conditions?`,
            options: ['Isolation', 'Durability', 'Atomicity', 'Consistency'],
            correctAnswer: 0,
            explanation: 'Isolation levels (Read Committed, Repeatable Read, Serializable) control concurrent access to prevent dirty or phantom reads.'
          },
          {
            id: 5,
            question: `Which distributed consensus algorithm is designed specifically for ease of understanding over Paxos?`,
            options: ['Raft', 'Two-Phase Commit', 'Byzantine Agreement', 'Gossip Protocol'],
            correctAnswer: 0,
            explanation: 'Raft was developed at Stanford specifically to decompose consensus into leader election, log replication, and safety.'
          }
        ]
      };
    }

    res.json(quiz);
  } catch (error) {
    console.error('Quiz generator error:', error);
    res.status(500).json({ error: 'Failed to generate quiz' });
  }
});

// -------------------------------------------------------------------
// PROJECT RISK ANALYSIS
// -------------------------------------------------------------------
router.post('/risk-analysis', authenticate, async (req: AuthRequest, res: Response) => {
  try {
    const { projectId } = req.body;
    if (!projectId) {
      return res.status(400).json({ error: 'projectId is required' });
    }

    const project = await prisma.project.findUnique({
      where: { id: projectId },
      include: {
        tasks: true,
        members: true
      }
    });

    if (!project) {
      return res.status(404).json({ error: 'Project not found' });
    }

    const totalTasks = project.tasks.length;
    const completedTasks = project.tasks.filter(t => t.status === 'COMPLETED').length;
    const urgentPending = project.tasks.filter(t => (t.priority === 'High' || t.priority === 'Critical') && t.status !== 'COMPLETED').length;
    
    let riskLevel = 'Low';
    const riskFactors = [];
    const recommendations = [];

    if (totalTasks > 0 && (completedTasks / totalTasks) < 0.4) {
      riskLevel = 'Medium';
      riskFactors.push(`Low completion rate (${project.progress}%) relative to current sprint milestone.`);
      recommendations.push('Reallocate team members to in-progress blockers.');
    }

    if (urgentPending >= 3) {
      riskLevel = 'High';
      riskFactors.push(`${urgentPending} high or critical priority tasks are currently uncompleted.`);
      recommendations.push('Schedule an urgent sprint alignment meeting to reprioritize deliverables.');
    }

    if (project.members.length < 2) {
      riskFactors.push('Single point of failure: limited team member redundancy.');
      recommendations.push('Assign a co-maintainer or contributor to critical task paths.');
    }

    if (riskFactors.length === 0) {
      riskFactors.push('Sufficient velocity observed across all task tracks.');
      recommendations.push('Maintain steady sprint cadence and keep automated checks enabled.');
    }

    res.json({
      projectName: project.name,
      overallRisk: riskLevel,
      progress: project.progress,
      totalTasks,
      completedTasks,
      urgentPending,
      riskFactors,
      recommendations,
      evaluatedAt: new Date().toISOString()
    });
  } catch (error) {
    console.error('Risk analysis error:', error);
    res.status(500).json({ error: 'Failed to perform risk analysis' });
  }
});

// -------------------------------------------------------------------
// DAILY BRIEFING ("What should I work on today?")
// -------------------------------------------------------------------
router.get('/daily-briefing', authenticate, async (req: AuthRequest, res: Response) => {
  try {
    const userName = req.user?.name || 'Shivam Singh';
    const todayStr = new Date().toISOString().split('T')[0];

    // Fetch high priority or uncompleted tasks
    const pendingTasks = await prisma.task.findMany({
      where: {
        status: { not: 'COMPLETED' }
      },
      include: {
        project: { select: { name: true } }
      },
      orderBy: [
        { dueDate: 'asc' },
        { priority: 'desc' }
      ],
      take: 6
    });

    // Fetch active study goals
    const pendingGoals = await prisma.studyGoal.findMany({
      where: { completed: false },
      take: 3
    });

    // Fetch personal todos for today
    const activeTodos = await prisma.todo.findMany({
      where: { completed: false },
      take: 4
    });

    // Generate tailored guidance
    const priorities = [];

    if (pendingTasks.length > 0) {
      const topTask = pendingTasks[0];
      priorities.push({
        title: topTask.title,
        type: 'Task',
        context: `${topTask.project?.name || 'Project'} • Priority: ${topTask.priority}`,
        action: 'Immediate Focus',
        id: topTask.id
      });
    }

    if (pendingTasks.length > 1) {
      const secondTask = pendingTasks[1];
      priorities.push({
        title: secondTask.title,
        type: 'Task',
        context: `${secondTask.project?.name || 'Project'} • Due: ${secondTask.dueDate}`,
        action: 'Secondary Focus',
        id: secondTask.id
      });
    }

    if (pendingGoals.length > 0) {
      priorities.push({
        title: pendingGoals[0].title,
        type: 'Study Goal',
        context: `Target: ${pendingGoals[0].targetDate}`,
        action: 'Dedicated Study Block (45 mins)',
        id: pendingGoals[0].id
      });
    }

    if (activeTodos.length > 0) {
      priorities.push({
        title: activeTodos[0].title,
        type: 'Todo',
        context: `Category: ${activeTodos[0].category}`,
        action: 'Quick Win',
        id: activeTodos[0].id
      });
    }

    res.json({
      greeting: `Good morning, ${userName} 👋`,
      date: todayStr,
      summaryMessage: `You have ${pendingTasks.length} active tasks and ${pendingGoals.length} study goals requiring your focus today. Here is your prioritized plan to maximize productivity:`,
      priorities,
      focusTip: 'Start with your highest-priority engineering deliverable before checking email or chat notifications.'
    });
  } catch (error) {
    console.error('Daily briefing error:', error);
    res.status(500).json({ error: 'Failed to generate daily briefing' });
  }
});

// -------------------------------------------------------------------
// SUMMARIZE (Documents or Discussions)
// -------------------------------------------------------------------
router.post('/summarize', authenticate, async (req: AuthRequest, res: Response) => {
  try {
    const { text, type = 'document' } = req.body;
    if (!text) {
      return res.status(400).json({ error: 'Text to summarize is required' });
    }

    const ai = getGeminiClient();
    let summary = '';

    if (ai) {
      try {
        const prompt = `Provide a high-impact, bulleted executive summary of the following ${type}:\n\n${text}\n\nHighlight key decisions, action items, and crucial takeaways:`;
        const resp = await ai.models.generateContent({
          model: 'gemini-2.5-flash',
          contents: prompt
        });
        summary = resp.text || '';
      } catch (err) {
        console.warn('Gemini summarizer error:', err);
      }
    }

    if (!summary) {
      // Fallback summary
      summary = `**Executive Summary:**\n- **Core Theme:** Primary discussion revolves around architecture execution and alignment.\n- **Key Takeaway:** Dependencies should be locked and validated early.\n- **Action Item:** Complete priority deliverables and test before final merge.`;
    }

    res.json({ summary });
  } catch (error) {
    console.error('Summarize error:', error);
    res.status(500).json({ error: 'Failed to summarize text' });
  }
});

export default router;
