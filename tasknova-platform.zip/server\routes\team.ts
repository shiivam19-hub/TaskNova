import { Router, Response } from 'express';
import { PrismaClient } from '@prisma/client';
import { authenticate, AuthRequest, requireRole } from '../middleware/auth';

const router = Router();
const prisma = new PrismaClient();

// Get all team members
router.get('/', authenticate, async (req: AuthRequest, res: Response) => {
  try {
    const { department, search } = req.query;

    const members = await prisma.teamMember.findMany({
      where: {
        ...(department && department !== 'All' ? { department: String(department) } : {}),
        ...(search ? {
          OR: [
            { name: { contains: String(search) } },
            { role: { contains: String(search) } },
            { email: { contains: String(search) } }
          ]
        } : {})
      },
      orderBy: { productivity: 'desc' }
    });

    res.json(members);
  } catch (error: any) {
    res.status(500).json({ error: error.message || 'Failed to fetch team members' });
  }
});

// Invite member (Admin / Owner / Project Manager)
router.post('/invite', authenticate, requireRole(['Owner', 'Admin', 'Project Manager']), async (req: AuthRequest, res: Response) => {
  try {
    const { name, email, role, department, roleType } = req.body;

    if (!name || !email) {
      return res.status(400).json({ error: 'Name and email are required' });
    }

    const member = await prisma.teamMember.create({
      data: {
        name: name.trim(),
        email: email.trim().toLowerCase(),
        role: role || 'Contributor',
        department: department || 'Engineering',
        roleType: roleType || 'Contributor',
        status: 'online',
        productivity: 90,
        avatarColor: 'bg-indigo-600',
        initials: name.split(' ').map((n: string) => n[0]).slice(0, 2).join('').toUpperCase()
      }
    });

    await prisma.activity.create({
      data: {
        authorName: req.user!.name,
        action: 'invited',
        target: `${member.name} (${member.role})`,
        type: 'permission'
      }
    });

    res.status(201).json(member);
  } catch (error: any) {
    res.status(500).json({ error: error.message || 'Failed to invite team member' });
  }
});

// Update Member Role
router.patch('/:memberId/role', authenticate, requireRole(['Owner', 'Admin']), async (req: AuthRequest, res: Response) => {
  try {
    const { memberId } = req.params;
    const { roleType } = req.body;

    if (!roleType) {
      return res.status(400).json({ error: 'roleType is required' });
    }

    const member = await prisma.teamMember.update({
      where: { id: memberId },
      data: { roleType }
    });

    await prisma.activity.create({
      data: {
        authorName: req.user!.name,
        action: 'changed role of',
        target: `${member.name} to ${roleType}`,
        type: 'permission'
      }
    });

    res.json(member);
  } catch (error: any) {
    res.status(500).json({ error: error.message || 'Failed to update member role' });
  }
});

// Remove Member
router.delete('/:memberId', authenticate, requireRole(['Owner', 'Admin']), async (req: AuthRequest, res: Response) => {
  try {
    const { memberId } = req.params;
    await prisma.teamMember.delete({ where: { id: memberId } });
    res.json({ message: 'Member removed successfully' });
  } catch (error: any) {
    res.status(500).json({ error: error.message || 'Failed to remove member' });
  }
});

export default router;
