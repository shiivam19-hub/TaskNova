import React, { useState } from 'react';
import {
  LayoutDashboard,
  CheckSquare,
  ListTodo,
  FolderKanban,
  Users,
  MessageSquare,
  Calendar,
  Timer,
  BookOpen,
  Bot,
  BarChart3,
  Bell,
  Settings,
  ShieldCheck,
  ChevronLeft,
  ChevronRight,
  Plus,
  Layers,
  ChevronDown,
  Sparkles,
  FolderPlus,
  ListPlus,
  CalendarPlus,
  Target,
  UploadCloud
} from 'lucide-react';
import { useApp, NavigationTab } from '../../context/AppContext';
import { Avatar } from '../common/Avatar';

interface SidebarProps {
  isCollapsed: boolean;
  setIsCollapsed: (collapsed: boolean) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ isCollapsed, setIsCollapsed }) => {
  const {
    activeTab,
    setActiveTab,
    openQuickCreate,
    userProfile,
    notifications,
    tasks
  } = useApp();

  const [isCreateDropdownOpen, setIsCreateDropdownOpen] = useState(false);
  const [isWorkspaceDropdownOpen, setIsWorkspaceDropdownOpen] = useState(false);

  const unreadCount = notifications.filter(n => !n.read).length;
  const pendingTasksCount = tasks.filter(t => t.status !== 'COMPLETED').length;

  const navItems: { id: NavigationTab; label: string; icon: React.FC<{ className?: string }>; badge?: number }[] = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'tasks', label: 'My Tasks', icon: CheckSquare, badge: pendingTasksCount },
    { id: 'todos', label: 'To-Do List', icon: ListTodo },
    { id: 'projects', label: 'Projects', icon: FolderKanban },
    { id: 'team', label: 'Team', icon: Users },
    { id: 'comments', label: 'Team Comments', icon: MessageSquare },
    { id: 'calendar', label: 'Calendar', icon: Calendar },
    { id: 'timer', label: 'Focus Timer', icon: Timer },
    { id: 'study-hub', label: 'Study Hub', icon: BookOpen },
    { id: 'ai-assistant', label: 'AI Assistant', icon: Bot },
    { id: 'analytics', label: 'Analytics', icon: BarChart3 },
    { id: 'notifications', label: 'Notifications', icon: Bell, badge: unreadCount },
    { id: 'privacy', label: 'Privacy & Security', icon: ShieldCheck },
    { id: 'settings', label: 'Settings', icon: Settings }
  ];

  const handleNavClick = (id: NavigationTab) => {
    setActiveTab(id);
  };

  const handleCreateOption = (type: 'project' | 'task' | 'todo' | 'meeting' | 'goal' | 'file') => {
    setIsCreateDropdownOpen(false);
    openQuickCreate(type);
  };

  return (
    <aside
      className={`relative flex flex-col h-screen shrink-0 bg-[#0f172a]/95 border-r border-slate-800/80 transition-all duration-300 z-30 select-none ${
        isCollapsed ? 'w-20' : 'w-64'
      }`}
    >
      {/* Top Header: TASKNOVA Logo + Brand */}
      <div className="flex items-center justify-between h-16 px-4 border-b border-slate-800/80">
        <div
          onClick={() => setActiveTab('dashboard')}
          className="flex items-center gap-3 cursor-pointer overflow-hidden group"
        >
          <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-indigo-500 via-indigo-600 to-cyan-500 flex items-center justify-center text-white shadow-lg shadow-indigo-600/25 shrink-0 group-hover:scale-105 transition-transform">
            <Sparkles className="w-5 h-5 text-white" />
          </div>

          {!isCollapsed && (
            <div className="flex flex-col min-w-0">
              <span className="text-base font-bold tracking-tight text-white flex items-center gap-1.5">
                TASKNOVA
                <span className="text-[9px] font-semibold px-1.5 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                  PRO
                </span>
              </span>
              <span className="text-[10px] text-slate-400 truncate tracking-wide">
                Plan. Collaborate. Achieve.
              </span>
            </div>
          )}
        </div>

        {/* Collapse toggle button */}
        {!isCollapsed && (
          <button
            onClick={() => setIsCollapsed(true)}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800/60 transition-colors"
            title="Collapse Sidebar"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>
        )}
      </div>

      {/* Prominent "+ Create New" Action Button with Dropdown */}
      <div className="p-3 relative">
        <div className="relative">
          <button
            type="button"
            onClick={() => setIsCreateDropdownOpen(prev => !prev)}
            className={`w-full flex items-center justify-center gap-2 py-2.5 rounded-xl bg-gradient-to-r from-indigo-600 to-indigo-500 hover:from-indigo-500 hover:to-indigo-400 text-white font-medium shadow-md shadow-indigo-950/50 hover:shadow-indigo-600/20 transition-all ${
              isCollapsed ? 'px-0' : 'px-4'
            }`}
            title="Create New"
          >
            <Plus className="w-5 h-5 shrink-0" />
            {!isCollapsed && <span className="text-sm font-semibold tracking-wide">+ Create New</span>}
          </button>

          {/* "+ Create New" Dropdown Menu */}
          {isCreateDropdownOpen && (
            <>
              <div
                className="fixed inset-0 z-40"
                onClick={() => setIsCreateDropdownOpen(false)}
              />
              <div
                className={`absolute left-0 top-full mt-2 w-56 bg-[#161f30] border border-slate-700/80 rounded-2xl shadow-2xl z-50 py-2 animate-pop-in ${
                  isCollapsed ? 'left-14' : 'left-0'
                }`}
              >
                <div className="px-3 py-1 text-[11px] font-semibold uppercase tracking-wider text-slate-400">
                  Quick Create
                </div>
                <button
                  onClick={() => handleCreateOption('project')}
                  className="w-full flex items-center gap-2.5 px-3.5 py-2 text-xs text-slate-200 hover:bg-indigo-600/20 hover:text-indigo-300 transition-colors text-left"
                >
                  <FolderPlus className="w-4 h-4 text-indigo-400" />
                  <span>New Project</span>
                </button>
                <button
                  onClick={() => handleCreateOption('task')}
                  className="w-full flex items-center gap-2.5 px-3.5 py-2 text-xs text-slate-200 hover:bg-indigo-600/20 hover:text-indigo-300 transition-colors text-left"
                >
                  <CheckSquare className="w-4 h-4 text-cyan-400" />
                  <span>New Task</span>
                </button>
                <button
                  onClick={() => handleCreateOption('todo')}
                  className="w-full flex items-center gap-2.5 px-3.5 py-2 text-xs text-slate-200 hover:bg-indigo-600/20 hover:text-indigo-300 transition-colors text-left"
                >
                  <ListPlus className="w-4 h-4 text-emerald-400" />
                  <span>New To-Do</span>
                </button>
                <button
                  onClick={() => handleCreateOption('meeting')}
                  className="w-full flex items-center gap-2.5 px-3.5 py-2 text-xs text-slate-200 hover:bg-indigo-600/20 hover:text-indigo-300 transition-colors text-left"
                >
                  <CalendarPlus className="w-4 h-4 text-amber-400" />
                  <span>Schedule Meeting</span>
                </button>
                <button
                  onClick={() => handleCreateOption('goal')}
                  className="w-full flex items-center gap-2.5 px-3.5 py-2 text-xs text-slate-200 hover:bg-indigo-600/20 hover:text-indigo-300 transition-colors text-left"
                >
                  <Target className="w-4 h-4 text-rose-400" />
                  <span>Add Study Goal</span>
                </button>
                <button
                  onClick={() => handleCreateOption('file')}
                  className="w-full flex items-center gap-2.5 px-3.5 py-2 text-xs text-slate-200 hover:bg-indigo-600/20 hover:text-indigo-300 transition-colors text-left"
                >
                  <UploadCloud className="w-4 h-4 text-blue-400" />
                  <span>Upload File</span>
                </button>
              </div>
            </>
          )}
        </div>
      </div>

      {/* Main Navigation Items */}
      <nav className="flex-1 px-3 py-2 space-y-1 overflow-y-auto overflow-x-hidden">
        {navItems.map(item => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => handleNavClick(item.id)}
              className={`w-full flex items-center gap-3 px-3 py-2 rounded-xl text-sm font-medium transition-all group relative ${
                isActive
                  ? 'bg-indigo-600/15 text-indigo-400 border border-indigo-500/30'
                  : 'text-slate-400 hover:text-slate-100 hover:bg-slate-800/60'
              } ${isCollapsed ? 'justify-center px-0' : ''}`}
              title={isCollapsed ? item.label : undefined}
            >
              <Icon
                className={`w-4 h-4 shrink-0 transition-colors ${
                  isActive ? 'text-indigo-400' : 'text-slate-400 group-hover:text-slate-200'
                }`}
              />

              {!isCollapsed && (
                <span className="truncate flex-1 text-left">{item.label}</span>
              )}

              {item.badge !== undefined && item.badge > 0 && (
                <span
                  className={`text-[10px] font-semibold px-1.5 py-0.2 rounded-full ${
                    item.id === 'notifications'
                      ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                      : 'bg-slate-800 text-slate-300 border border-slate-700'
                  } ${isCollapsed ? 'absolute top-1 right-1 px-1 py-0 text-[8px]' : ''}`}
                >
                  {item.badge}
                </span>
              )}

              {/* Active Indicator Bar */}
              {isActive && (
                <span className="absolute left-0 top-1.5 bottom-1.5 w-1 bg-indigo-500 rounded-r-full" />
              )}
            </button>
          );
        })}
      </nav>

      {/* Expand button when collapsed */}
      {isCollapsed && (
        <div className="p-3 flex justify-center border-t border-slate-800/80">
          <button
            onClick={() => setIsCollapsed(false)}
            className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
            title="Expand Sidebar"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Bottom Area: Workspace Selector & User Profile */}
      <div className="p-3 border-t border-slate-800/80 space-y-2 bg-[#0c1220]/80">
        {/* Workspace Selector */}
        {!isCollapsed && (
          <div className="relative">
            <button
              onClick={() => setIsWorkspaceDropdownOpen(prev => !prev)}
              className="w-full flex items-center justify-between p-2 rounded-xl bg-slate-900/80 border border-slate-800 hover:border-slate-700 text-xs text-slate-300 transition-colors"
            >
              <div className="flex items-center gap-2 truncate">
                <Layers className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
                <span className="truncate font-medium">{userProfile.workspace}</span>
              </div>
              <ChevronDown className="w-3.5 h-3.5 text-slate-500 shrink-0" />
            </button>

            {isWorkspaceDropdownOpen && (
              <>
                <div
                  className="fixed inset-0 z-40"
                  onClick={() => setIsWorkspaceDropdownOpen(false)}
                />
                <div className="absolute left-0 bottom-full mb-2 w-full bg-[#161f30] border border-slate-700/80 rounded-xl shadow-2xl z-50 py-1.5 text-xs animate-pop-in">
                  <div className="px-3 py-1 text-[10px] uppercase font-semibold text-slate-400">
                    Switch Workspace
                  </div>
                  {['Tasknova University Workspace', 'Acme Studio Team', 'Personal Lab'].map(ws => (
                    <button
                      key={ws}
                      onClick={() => {
                        setIsWorkspaceDropdownOpen(false);
                      }}
                      className="w-full px-3 py-1.5 text-left text-slate-300 hover:bg-indigo-600/20 hover:text-indigo-300 truncate"
                    >
                      {ws}
                    </button>
                  ))}
                </div>
              </>
            )}
          </div>
        )}

        {/* User Profile Card (Alex Morgan) */}
        <div
          onClick={() => setActiveTab('settings')}
          className={`flex items-center gap-3 p-2 rounded-xl hover:bg-slate-800/60 cursor-pointer transition-colors ${
            isCollapsed ? 'justify-center p-1' : ''
          }`}
          title="Account Settings"
        >
          <Avatar
            name={userProfile.name}
            initials={userProfile.avatarInitials}
            size="md"
            status={userProfile.status}
            showStatus={true}
          />

          {!isCollapsed && (
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-slate-200 truncate">
                  {userProfile.name}
                </span>
                <span className="text-[9px] px-1.5 py-0.5 rounded bg-indigo-950/60 text-indigo-300 border border-indigo-500/20">
                  {userProfile.roleType}
                </span>
              </div>
              <p className="text-[11px] text-slate-400 truncate mt-0.5">
                {userProfile.role}
              </p>
            </div>
          )}
        </div>
      </div>
    </aside>
  );
};
