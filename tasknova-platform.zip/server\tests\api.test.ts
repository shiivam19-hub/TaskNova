process.env.NODE_ENV = 'test';

import app from '../index';
import http from 'http';

async function runTests() {
  console.log('🧪 Starting TASKNOVA Production Backend API Test Suite...\n');

  // Start temporary server on random port
  const server = http.createServer(app);
  await new Promise<void>((resolve) => server.listen(0, resolve));
  const address = server.address() as any;
  const baseUrl = `http://localhost:${address.port}/api`;

  let token = '';
  let testProjectId = '';
  let testTaskId = '';
  let testTodoId = '';
  let testCommentId = '';

  let passed = 0;
  let failed = 0;

  async function assert(desc: string, fn: () => Promise<boolean | void>) {
    try {
      const res = await fn();
      if (res === false) {
        throw new Error('Assertion returned false');
      }
      console.log(`  ✅ PASS: ${desc}`);
      passed++;
    } catch (err: any) {
      console.error(`  ❌ FAIL: ${desc} -> ${err.message}`);
      failed++;
    }
  }

  try {
    // 1. Health Check
    await assert('GET /api/health should return status healthy', async () => {
      const res = await fetch(`${baseUrl}/health`);
      const data = await res.json();
      return res.status === 200 && data.status === 'healthy';
    });

    // 2. Authentication: Login
    await assert('POST /api/auth/login should authenticate SHIVAM SINGH', async () => {
      const res = await fetch(`${baseUrl}/auth/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          email: 'shivam.singh@tasknova.app',
          password: 'Password@123'
        })
      });
      const data = await res.json();
      token = data.token;
      return res.status === 200 && token && data.user.name.toLowerCase() === 'shivam singh';
    });

    // 3. Authentication: /me
    await assert('GET /api/auth/me should verify current authenticated session', async () => {
      const res = await fetch(`${baseUrl}/auth/me`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      const data = await res.json();
      const user = data.user || data;
      return res.status === 200 && user.name.toLowerCase() === 'shivam singh' && user.role === 'Student & Project Contributor';
    });

    // 4. Projects: List
    await assert('GET /api/projects should return seeded projects', async () => {
      const res = await fetch(`${baseUrl}/projects`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      const data = await res.json();
      if (Array.isArray(data) && data.length > 0) {
        testProjectId = data[0].id;
        return true;
      }
      return false;
    });

    // 5. Tasks: Create & Status Transition
    await assert('POST /api/tasks and PATCH status should manage task lifecycle', async () => {
      // Create
      const createRes = await fetch(`${baseUrl}/tasks`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({
          projectId: testProjectId,
          title: 'Automated Test Pipeline Execution',
          description: 'Verifying end-to-end task mutations',
          priority: 'High',
          dueDate: '2026-09-30',
          assigneeName: 'Shivam Singh',
          tags: ['Testing', 'CI']
        })
      });
      
      const rawText = await createRes.text();
      let created: any = {};
      try {
        created = JSON.parse(rawText);
      } catch (e) {
        throw new Error(`Status ${createRes.status}: ${rawText.slice(0, 100)}`);
      }
      testTaskId = created.id;

      // Update status
      const statusRes = await fetch(`${baseUrl}/tasks/${testTaskId}/status`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({ status: 'COMPLETED' })
      });
      const updated = await statusRes.json();

      return createRes.status === 201 && updated.status === 'COMPLETED';
    });

    // 6. Todos: Create & Toggle
    await assert('POST /api/todos and PATCH toggle should manage checklist items', async () => {
      const createRes = await fetch(`${baseUrl}/todos`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({
          title: 'Automated Unit Verification Checklist',
          category: 'Today',
          priority: 'High',
          dueDate: 'Today'
        })
      });
      
      const rawText = await createRes.text();
      let todo: any = {};
      try {
        todo = JSON.parse(rawText);
      } catch (e) {
        throw new Error(`Status ${createRes.status}: ${rawText.slice(0, 100)}`);
      }
      testTodoId = todo.id;

      const toggleRes = await fetch(`${baseUrl}/todos/${testTodoId}/toggle`, {
        method: 'PATCH',
        headers: { Authorization: `Bearer ${token}` }
      });
      const toggled = await toggleRes.json();

      return createRes.status === 201 && toggled.completed === true;
    });

    // 7. Comments: Post & Reactions
    await assert('POST /api/comments and reaction toggle should work', async () => {
      const commentRes = await fetch(`${baseUrl}/comments`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({
          projectId: testProjectId,
          content: 'Verification comment posted from automated test runner'
        })
      });
      const comment = await commentRes.json();
      testCommentId = comment.id;

      const reactRes = await fetch(`${baseUrl}/comments/${testCommentId}/reaction`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({ emoji: '🔥' })
      });
      const reactData = await reactRes.json();

      return commentRes.status === 201 && reactData.action === 'added';
    });

    // 8. Activity Feed
    await assert('GET /api/activity should return real-time system activities', async () => {
      const res = await fetch(`${baseUrl}/activity?limit=10`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      const activities = await res.json();
      return res.status === 200 && Array.isArray(activities) && activities.length > 0;
    });

    // 9. Notifications: List and Mark All Read
    await assert('GET /api/notifications and PATCH read-all should function', async () => {
      const res = await fetch(`${baseUrl}/notifications`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      const data = await res.json();

      const patchRes = await fetch(`${baseUrl}/notifications/read-all`, {
        method: 'PATCH',
        headers: { Authorization: `Bearer ${token}` }
      });

      return res.status === 200 && patchRes.status === 200;
    });

    // 10. AI: Daily Briefing ("What should I work on today?")
    await assert('GET /api/ai/daily-briefing should return personalized guidance for SHIVAM SINGH', async () => {
      const res = await fetch(`${baseUrl}/ai/daily-briefing`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      const data = await res.json();
      return res.status === 200 && data.greeting.toLowerCase().includes('shivam') && Array.isArray(data.priorities);
    });

    // 11. AI: Project Plan Generation & Auto Task Import
    await assert('POST /api/ai/project-plan and /create-tasks-from-plan should import tasks', async () => {
      const planRes = await fetch(`${baseUrl}/ai/project-plan`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({
          title: 'Distributed File Cache',
          goal: 'Build an LRU cache with consistent hashing',
          timeline: '2 weeks'
        })
      });
      const plan = await planRes.json();

      const importRes = await fetch(`${baseUrl}/ai/create-tasks-from-plan`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({
          projectId: testProjectId,
          tasks: plan.phases[0].tasks
        })
      });
      const importData = await importRes.json();

      return planRes.status === 200 && importRes.status === 201 && Array.isArray(importData.tasks);
    });

    // 12. AI: Quiz Generator
    await assert('POST /api/ai/quiz should return multiple-choice questions with answers', async () => {
      const res = await fetch(`${baseUrl}/ai/quiz`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({ topic: 'Operating Systems' })
      });
      const quiz = await res.json();
      return res.status === 200 && Array.isArray(quiz.questions) && quiz.questions.length === 5;
    });

    // 13. Study: Academic Search (Open Library)
    await assert('GET /api/study/search/books should return book publications', async () => {
      const res = await fetch(`${baseUrl}/study/search/books?q=algorithms&limit=3`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      const books = await res.json();
      return res.status === 200 && Array.isArray(books) && books.length > 0;
    });

    // 14. Study: Open-Meteo Weather Integration
    await assert('GET /api/study/environment/weather should return focus climate data', async () => {
      const res = await fetch(`${baseUrl}/study/environment/weather`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      const weather = await res.json();
      return res.status === 200 && weather.temperature !== undefined;
    });

    // 15. Privacy: Data Export (GDPR Portability)
    await assert('GET /api/privacy/export-data should export comprehensive user profile and tasks', async () => {
      const res = await fetch(`${baseUrl}/privacy/export-data`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      const exportData = await res.json();
      return res.status === 200 && exportData.application === 'TASKNOVA Platform' && exportData.user.name.toLowerCase() === 'shivam singh';
    });

    // Clean up created test items
    if (testTaskId) await fetch(`${baseUrl}/tasks/${testTaskId}`, { method: 'DELETE', headers: { Authorization: `Bearer ${token}` } });
    if (testTodoId) await fetch(`${baseUrl}/todos/${testTodoId}`, { method: 'DELETE', headers: { Authorization: `Bearer ${token}` } });
    if (testCommentId) await fetch(`${baseUrl}/comments/${testCommentId}`, { method: 'DELETE', headers: { Authorization: `Bearer ${token}` } });

  } finally {
    server.close();
  }

  console.log('\n=========================================');
  console.log(`📊 Test Summary: ${passed} PASSED, ${failed} FAILED (Total: ${passed + failed})`);
  console.log('=========================================\n');

  if (failed > 0) {
    process.exit(1);
  }
  process.exit(0);
}

runTests().catch(err => {
  console.error('Fatal test error:', err);
  process.exit(1);
});
