import React, { useState } from 'react';
import {
  MessageSquare,
  Send,
  Pin,
  Smile,
  Paperclip,
  Trash2,
  Reply,
  AtSign,
  Filter,
  Check
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { Avatar } from '../common/Avatar';
import { useToast } from '../../context/ToastContext';

export const CommentsView: React.FC = () => {
  const {
    comments,
    addComment,
    addReply,
    addReaction,
    togglePinComment,
    deleteComment,
    projects,
    teamMembers,
    userProfile
  } = useApp();

  const { showToast } = useToast();

  const [selectedProjectId, setSelectedProjectId] = useState<string>('All');
  const [newComment, setNewComment] = useState('');
  const [activeReplyId, setActiveReplyId] = useState<string | null>(null);
  const [replyContent, setReplyContent] = useState('');
  const [showMentionMenu, setShowMentionMenu] = useState(false);

  const filteredComments = comments.filter(c => {
    return selectedProjectId === 'All' || c.projectId === selectedProjectId;
  });

  const handlePost = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newComment.trim()) return;
    const targetProject = selectedProjectId === 'All' ? (projects[0]?.id || 'p1') : selectedProjectId;
    addComment(targetProject, newComment.trim());
    setNewComment('');
    showToast('Discussion Published', 'Your comment has been broadcast to team feeds.', 'success');
  };

  const handleReplySubmit = (commentId: string) => {
    if (!replyContent.trim()) return;
    addReply(commentId, replyContent.trim());
    setReplyContent('');
    setActiveReplyId(null);
    showToast('Reply Submitted', 'Thread updated.', 'success');
  };

  const insertMention = (memberName: string) => {
    setNewComment(prev => `${prev} @${memberName} `);
    setShowMentionMenu(false);
  };

  return (
    <div className="space-y-6 animate-fade-in pb-16 max-w-4xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-white flex items-center gap-2.5">
            <MessageSquare className="w-6 h-6 text-indigo-400" />
            Team Collaboration Hub
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Async discussion threads, design feedback, @mentions, and release sync.
          </p>
        </div>

        {/* Project channel filter */}
        <div className="flex items-center gap-2">
          <Filter className="w-3.5 h-3.5 text-slate-400" />
          <select
            value={selectedProjectId}
            onChange={e => setSelectedProjectId(e.target.value)}
            className="px-3 py-1.5 bg-slate-900 border border-slate-700 rounded-xl text-xs text-slate-200 focus:outline-none focus:border-indigo-500"
          >
            <option value="All">All Channels & Projects</option>
            {projects.map(p => (
              <option key={p.id} value={p.id}>{p.name}</option>
            ))}
          </select>
        </div>
      </div>

      {/* Main Comment Creation Box */}
      <form onSubmit={handlePost} className="bg-[#111827] border border-slate-800 rounded-2xl p-4 shadow-sm space-y-3 relative">
        <textarea
          rows={3}
          value={newComment}
          onChange={e => setNewComment(e.target.value)}
          placeholder="Start a thread or share an engineering update (type @ to mention a teammate)..."
          className="w-full px-3.5 py-2.5 bg-slate-900 border border-slate-700/80 rounded-xl text-xs text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-indigo-500 leading-relaxed"
        />

        <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
          <div className="flex items-center gap-2 relative">
            <button
              type="button"
              onClick={() => setShowMentionMenu(prev => !prev)}
              className="flex items-center gap-1 px-2.5 py-1 text-xs text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
            >
              <AtSign className="w-3.5 h-3.5" />
              Mention
            </button>

            {/* Mention Dropdown */}
            {showMentionMenu && (
              <div className="absolute left-0 top-full mt-1 w-48 bg-[#161f30] border border-slate-700 rounded-xl shadow-xl z-30 py-1 text-xs">
                {teamMembers.map(m => (
                  <button
                    key={m.id}
                    type="button"
                    onClick={() => insertMention(m.name)}
                    className="w-full px-3 py-1.5 text-left text-slate-300 hover:bg-indigo-600/20 hover:text-indigo-300 flex items-center gap-2"
                  >
                    <Avatar name={m.name} size="xs" color={m.avatarColor} />
                    <span className="truncate">{m.name}</span>
                  </button>
                ))}
              </div>
            )}

            <button
              type="button"
              onClick={() => showToast('Attachment Attached', 'mock-artifact.pdf added to payload', 'info')}
              className="flex items-center gap-1 px-2.5 py-1 text-xs text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
            >
              <Paperclip className="w-3.5 h-3.5" />
              Attach
            </button>
          </div>

          <button
            type="submit"
            className="flex items-center gap-2 px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold rounded-xl shadow-md shadow-indigo-950/40 transition-colors"
          >
            <Send className="w-3.5 h-3.5" />
            Publish Thread
          </button>
        </div>
      </form>

      {/* Discussion List */}
      <div className="space-y-4">
        {filteredComments.length === 0 ? (
          <div className="p-8 text-center bg-[#111827] border border-slate-800 rounded-2xl text-slate-500 text-xs">
            No discussion messages in this channel yet.
          </div>
        ) : (
          filteredComments.map(comment => (
            <div
              key={comment.id}
              className={`p-5 bg-[#111827] border rounded-2xl shadow-sm space-y-3 transition-colors ${
                comment.pinned ? 'border-amber-500/40 bg-amber-950/10' : 'border-slate-800 hover:border-slate-700'
              }`}
            >
              {/* Comment Header */}
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-center gap-3">
                  <Avatar name={comment.authorName} size="md" color="bg-indigo-600" />
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-slate-100">{comment.authorName}</span>
                      <span className="text-[10px] text-slate-400 font-medium">{comment.authorRole}</span>
                      {comment.pinned && (
                        <span className="text-[9px] font-bold px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30 flex items-center gap-1">
                          <Pin className="w-2.5 h-2.5" /> PINNED
                        </span>
                      )}
                    </div>
                    <div className="flex items-center gap-2 text-[10px] text-slate-400 mt-0.5">
                      <span className="text-indigo-400">#{comment.projectName}</span>
                      <span>•</span>
                      <span>{comment.timestamp}</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-1">
                  <button
                    onClick={() => togglePinComment(comment.id)}
                    className={`p-1.5 rounded-lg transition-colors ${
                      comment.pinned ? 'text-amber-400 bg-amber-500/10' : 'text-slate-500 hover:text-white hover:bg-slate-800'
                    }`}
                    title={comment.pinned ? 'Unpin comment' : 'Pin comment'}
                  >
                    <Pin className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => deleteComment(comment.id)}
                    className="p-1.5 text-slate-500 hover:text-rose-400 rounded-lg hover:bg-slate-800 transition-colors"
                    title="Delete"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              {/* Comment Content */}
              <div className="text-xs text-slate-200 leading-relaxed pl-12 whitespace-pre-wrap">
                {comment.content}
              </div>

              {/* Reactions & Reply Bar */}
              <div className="pl-12 flex flex-wrap items-center gap-2 pt-1">
                {comment.reactions.map(r => (
                  <button
                    key={r.emoji}
                    onClick={() => addReaction(comment.id, r.emoji)}
                    className="px-2 py-0.5 rounded-lg bg-slate-900 border border-slate-700/80 text-slate-300 hover:border-indigo-500 text-[11px] flex items-center gap-1 transition-colors"
                  >
                    <span>{r.emoji}</span>
                    <span className="font-semibold">{r.count}</span>
                  </button>
                ))}

                {['👍', '🚀', '❤️', '🔥', '👀'].map(emoji => (
                  <button
                    key={emoji}
                    onClick={() => addReaction(comment.id, emoji)}
                    className="p-1 rounded hover:bg-slate-800 text-xs text-slate-400 hover:text-white"
                  >
                    {emoji}
                  </button>
                ))}

                <button
                  onClick={() => setActiveReplyId(activeReplyId === comment.id ? null : comment.id)}
                  className="flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-semibold text-indigo-400 hover:text-indigo-300 hover:bg-indigo-950/40 transition-colors ml-2"
                >
                  <Reply className="w-3.5 h-3.5" />
                  Reply ({comment.replies.length})
                </button>
              </div>

              {/* Threaded Replies */}
              {comment.replies.length > 0 && (
                <div className="pl-12 space-y-2 pt-2 border-t border-slate-800/60">
                  {comment.replies.map(reply => (
                    <div key={reply.id} className="p-3 bg-slate-900/80 border border-slate-800 rounded-xl space-y-1">
                      <div className="flex items-center justify-between text-xs">
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-slate-200">{reply.authorName}</span>
                          <span className="text-[10px] text-slate-400">{reply.authorRole}</span>
                        </div>
                        <span className="text-[10px] text-slate-500">{reply.timestamp}</span>
                      </div>
                      <p className="text-xs text-slate-300 leading-normal">{reply.content}</p>
                    </div>
                  ))}
                </div>
              )}

              {/* Inline Reply Form */}
              {activeReplyId === comment.id && (
                <div className="pl-12 pt-2 flex items-center gap-2">
                  <input
                    type="text"
                    value={replyContent}
                    onChange={e => setReplyContent(e.target.value)}
                    placeholder="Write a response..."
                    className="flex-1 px-3 py-1.5 bg-slate-900 border border-slate-700 rounded-xl text-xs text-slate-100 focus:outline-none focus:border-indigo-500"
                  />
                  <button
                    onClick={() => handleReplySubmit(comment.id)}
                    className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-semibold"
                  >
                    Reply
                  </button>
                </div>
              )}
            </div>
          ))
        )}
      </div>
    </div>
  );
};
