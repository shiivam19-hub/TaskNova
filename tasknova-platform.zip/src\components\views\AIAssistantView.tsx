import React, { useState, useRef, useEffect } from 'react';
import {
  Bot,
  Send,
  Sparkles,
  Copy,
  Check,
  PlusCircle,
  HelpCircle,
  Lightbulb,
  BookOpen,
  Code,
  ListTodo,
  CheckSquare,
  Key
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { useToast } from '../../context/ToastContext';
import { generateAIResponse, AIMessage, promptTemplates } from '../../services/geminiService';
import { Avatar } from '../common/Avatar';

export const AIAssistantView: React.FC = () => {
  const { addTask, userProfile, projects, openDailyBriefing } = useApp();
  const { showToast } = useToast();

  const [inputQuery, setInputQuery] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const [messages, setMessages] = useState<AIMessage[]>([
    {
      id: 'init-1',
      sender: 'assistant',
      timestamp: '11:45 AM',
      text: `Hello ${userProfile.name}! I'm **TASKNOVA AI**, your academic and project copilot.

I can help you:
* **Explain technical concepts** (e.g. *"Explain polymorphism in simple terms"*)
* **Break projects into tasks** (e.g. *"Break my AI project into tasks"*)
* **Generate diagnostic quizzes & flashcards**
* **Summarize complex lecture notes**
* **Analyze project progress & deadlines**

How can I accelerate your work today?`
    }
  ]);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isLoading]);

  const handleSend = async (queryText?: string) => {
    const textToSend = queryText || inputQuery;
    if (!textToSend.trim() || isLoading) return;

    const userMsg: AIMessage = {
      id: `user-${Date.now()}`,
      sender: 'user',
      text: textToSend.trim(),
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages(prev => [...prev, userMsg]);
    setInputQuery('');
    setIsLoading(true);

    try {
      const aiResponse = await generateAIResponse(textToSend);
      setMessages(prev => [...prev, aiResponse]);
    } catch (err) {
      showToast('AI Error', 'Failed to generate response. Check network connectivity.', 'error');
    } finally {
      setIsLoading(false);
    }
  };

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    showToast('Copied to Clipboard', 'Text copied successfully.', 'info');
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleAddTasksToProject = (actionableTasks: string[]) => {
    const targetProject = projects[0]?.id || 'p1';
    actionableTasks.forEach((t, i) => {
      addTask({
        projectId: targetProject,
        title: t,
        priority: i < 2 ? 'High' : 'Medium',
        status: 'TO DO',
        assignee: { name: userProfile.name, avatarColor: 'bg-indigo-600' },
        dueDate: `Day ${i + 1}`,
        tags: ['AI-Generated']
      });
    });
    showToast('Tasks Added to Backlog', `Registered ${actionableTasks.length} tasks to ${projects[0]?.name || 'Project'}.`, 'success');
  };

  return (
    <div className="flex flex-col h-[calc(100vh-8rem)] max-w-5xl mx-auto animate-fade-in pb-4">
      {/* Header */}
      <div className="flex items-center justify-between pb-3 border-b border-slate-800 shrink-0">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-500 to-cyan-500 flex items-center justify-center text-white shadow-lg shadow-indigo-600/30">
            <Bot className="w-5 h-5" />
          </div>
          <div>
            <h1 className="text-lg font-bold text-white flex items-center gap-2">
              TASKNOVA AI Copilot
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 font-semibold">
                Gemini 2.5 Flash Engine
              </span>
            </h1>
            <p className="text-xs text-slate-400">Contextual intelligence for project management & academic mastery</p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={openDailyBriefing}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-indigo-600/25 to-cyan-500/25 hover:from-indigo-600/35 hover:to-cyan-500/35 border border-indigo-500/40 hover:border-indigo-400 text-xs font-semibold text-indigo-200 hover:text-white transition-all shadow-md shadow-indigo-950/30 cursor-pointer"
          >
            <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
            <span>✨ What should I work on today?</span>
          </button>
          <span className="hidden sm:inline-flex text-xs text-slate-400 font-mono bg-slate-900 px-3 py-1 rounded-xl border border-slate-800">
            Gemini 2.5 Flash
          </span>
        </div>
      </div>

      {/* Suggested Prompt Pills (Horizontal Scroll) */}
      <div className="py-3 flex items-center gap-2 overflow-x-auto shrink-0 text-xs">
        <Sparkles className="w-3.5 h-3.5 text-indigo-400 ml-1 shrink-0" />
        {promptTemplates.map((item, idx) => (
          <button
            key={idx}
            onClick={() => handleSend(item.prompt)}
            className="px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 hover:border-indigo-500/40 text-slate-300 hover:text-white transition-colors shrink-0 flex items-center gap-1.5"
          >
            <span>{item.title}</span>
          </button>
        ))}
      </div>

      {/* Messages Scroll Area */}
      <div className="flex-1 overflow-y-auto space-y-4 pr-2 py-2">
        {messages.map(msg => (
          <div
            key={msg.id}
            className={`flex items-start gap-3 text-xs ${
              msg.sender === 'user' ? 'flex-row-reverse' : ''
            }`}
          >
            {msg.sender === 'user' ? (
              <Avatar
                name={userProfile.name}
                initials={userProfile.avatarInitials}
                size="sm"
                color="bg-indigo-600"
              />
            ) : (
              <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-indigo-600 to-cyan-600 flex items-center justify-center text-white shrink-0 shadow-md shadow-indigo-950/50">
                <Bot className="w-4 h-4" />
              </div>
            )}

            <div
              className={`max-w-2xl rounded-2xl p-4 space-y-3 leading-relaxed ${
                msg.sender === 'user'
                  ? 'bg-indigo-600 text-white shadow-md shadow-indigo-950/40'
                  : 'bg-[#111827] border border-slate-800 text-slate-200 shadow-sm'
              }`}
            >
              <div className="whitespace-pre-wrap font-sans text-xs sm:text-sm">
                {msg.text}
              </div>

              {/* Actionable task buttons if AI broke down a project */}
              {msg.actionableTasks && (
                <div className="pt-3 border-t border-slate-800 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-[11px] font-bold text-indigo-400 uppercase tracking-wider">
                      Interactive Project Backlog
                    </span>
                    <button
                      onClick={() => handleAddTasksToProject(msg.actionableTasks!)}
                      className="flex items-center gap-1.5 px-3 py-1 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-semibold shadow-xs"
                    >
                      <PlusCircle className="w-3.5 h-3.5" />
                      Add all 7 to Project Backlog
                    </button>
                  </div>
                </div>
              )}

              {/* Message Footer: Timestamp & Copy */}
              <div className="flex items-center justify-between text-[10px] text-slate-400 pt-1">
                <span>{msg.timestamp}</span>
                {msg.sender === 'assistant' && (
                  <button
                    onClick={() => handleCopy(msg.text, msg.id)}
                    className="flex items-center gap-1 text-slate-400 hover:text-white p-1 rounded hover:bg-slate-800 transition-colors"
                  >
                    {copiedId === msg.id ? (
                      <>
                        <Check className="w-3 h-3 text-emerald-400" /> Copied
                      </>
                    ) : (
                      <>
                        <Copy className="w-3 h-3" /> Copy
                      </>
                    )}
                  </button>
                )}
              </div>
            </div>
          </div>
        ))}

        {isLoading && (
          <div className="flex items-center gap-3 text-xs text-slate-400">
            <div className="w-8 h-8 rounded-xl bg-indigo-600/30 flex items-center justify-center text-indigo-400 animate-pulse">
              <Bot className="w-4 h-4" />
            </div>
            <div className="p-3 bg-[#111827] border border-slate-800 rounded-xl flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-indigo-500 animate-ping" />
              <span>TASKNOVA AI is formulating response & structuring tasks...</span>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Input Form Bar */}
      <form
        onSubmit={e => {
          e.preventDefault();
          handleSend();
        }}
        className="mt-2 shrink-0 relative flex items-center bg-[#111827] border border-slate-800 rounded-2xl p-2 shadow-lg focus-within:border-indigo-500 transition-colors"
      >
        <input
          type="text"
          value={inputQuery}
          onChange={e => setInputQuery(e.target.value)}
          placeholder="Ask anything (e.g. 'Explain polymorphism', 'Break my AI project into tasks', 'Generate quiz')..."
          className="flex-1 bg-transparent px-3 py-2 text-xs sm:text-sm text-slate-100 placeholder:text-slate-500 focus:outline-none"
        />

        <button
          type="submit"
          disabled={!inputQuery.trim() || isLoading}
          className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-40 text-white text-xs font-semibold rounded-xl flex items-center gap-1.5 transition-all shadow-md shadow-indigo-950/40"
        >
          <Send className="w-3.5 h-3.5" />
          Send
        </button>
      </form>
    </div>
  );
};
