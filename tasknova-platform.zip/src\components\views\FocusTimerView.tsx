import React, { useState, useEffect, useRef } from 'react';
import {
  Timer,
  Play,
  Pause,
  RotateCcw,
  SkipForward,
  Flame,
  CheckCircle2,
  Clock,
  Sparkles,
  Settings
} from 'lucide-react';
import { useToast } from '../../context/ToastContext';
import { useApp } from '../../context/AppContext';

export const FocusTimerView: React.FC = () => {
  const { showToast } = useToast();
  const { tasks, toggleTaskCompletion } = useApp();

  const [mode, setMode] = useState<'focus' | 'break'>('focus');
  const [focusDuration, setFocusDuration] = useState(25); // in minutes
  const [breakDuration, setBreakDuration] = useState(5); // in minutes
  const [timeLeft, setTimeLeft] = useState(25 * 60); // in seconds
  const [isActive, setIsActive] = useState(false);

  // Statistics
  const [sessionsCompleted, setSessionsCompleted] = useState(3);
  const [todayFocusMinutes, setTodayFocusMinutes] = useState(105); // 1h 45m
  const [streakDays, setStreakDays] = useState(7);

  const totalDurationSeconds = (mode === 'focus' ? focusDuration : breakDuration) * 60;
  const progressPercent = ((totalDurationSeconds - timeLeft) / totalDurationSeconds) * 100;

  useEffect(() => {
    let interval: any = null;
    if (isActive && timeLeft > 0) {
      interval = setInterval(() => {
        setTimeLeft(prev => prev - 1);
        if (mode === 'focus') {
          // Increment seconds tracked
          setTodayFocusMinutes(m => m + (1 / 60));
        }
      }, 1000);
    } else if (isActive && timeLeft === 0) {
      // Completed!
      setIsActive(false);
      if (mode === 'focus') {
        setSessionsCompleted(prev => prev + 1);
        showToast('Focus session complete! 🎉', 'Take a short break. You earned it!', 'success', 8000);
        setMode('break');
        setTimeLeft(breakDuration * 60);
      } else {
        showToast('Break finished ⚡', 'Ready for your next deep focus block?', 'info');
        setMode('focus');
        setTimeLeft(focusDuration * 60);
      }
    }
    return () => clearInterval(interval);
  }, [isActive, timeLeft, mode, focusDuration, breakDuration, showToast]);

  const toggleTimer = () => {
    setIsActive(prev => !prev);
  };

  const handleReset = () => {
    setIsActive(false);
    setTimeLeft((mode === 'focus' ? focusDuration : breakDuration) * 60);
  };

  const handleSkip = () => {
    setIsActive(false);
    if (mode === 'focus') {
      setMode('break');
      setTimeLeft(breakDuration * 60);
    } else {
      setMode('focus');
      setTimeLeft(focusDuration * 60);
    }
  };

  const setPreset = (focusMins: number, breakMins: number) => {
    setIsActive(false);
    setFocusDuration(focusMins);
    setBreakDuration(breakMins);
    setMode('focus');
    setTimeLeft(focusMins * 60);
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
  };

  // SVG Circular progress computation
  const circleRadius = 140;
  const circumference = 2 * Math.PI * circleRadius;
  const strokeDashoffset = circumference - (progressPercent / 100) * circumference;

  return (
    <div className="space-y-6 animate-fade-in pb-16 max-w-4xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-white flex items-center gap-2.5">
            <Timer className="w-6 h-6 text-cyan-400" />
            Pomodoro Deep Focus Timer
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Science-backed productivity intervals to prevent fatigue and achieve flow state.
          </p>
        </div>

        {/* Preset Selector */}
        <div className="flex items-center gap-2 bg-[#111827] border border-slate-800 p-1.5 rounded-2xl text-xs font-semibold">
          <button
            onClick={() => setPreset(25, 5)}
            className={`px-3 py-1.5 rounded-xl transition-all ${
              focusDuration === 25
                ? 'bg-indigo-600 text-white shadow-md shadow-indigo-950/40'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            25 / 5 Standard
          </button>
          <button
            onClick={() => setPreset(50, 10)}
            className={`px-3 py-1.5 rounded-xl transition-all ${
              focusDuration === 50
                ? 'bg-indigo-600 text-white shadow-md shadow-indigo-950/40'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            50 / 10 Deep
          </button>
          <button
            onClick={() => setPreset(15, 3)}
            className={`px-3 py-1.5 rounded-xl transition-all ${
              focusDuration === 15
                ? 'bg-indigo-600 text-white shadow-md shadow-indigo-950/40'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            15 / 3 Sprint
          </button>
        </div>
      </div>

      {/* Main Timer Display Card (Section 18) */}
      <div className="bg-[#111827] border border-slate-800 rounded-3xl p-8 flex flex-col items-center justify-center relative overflow-hidden shadow-2xl">
        {/* Glow ambient background */}
        <div className={`absolute w-72 h-72 rounded-full filter blur-3xl opacity-20 pointer-events-none transition-all duration-700 ${
          mode === 'focus' ? 'bg-indigo-500' : 'bg-emerald-500'
        }`} />

        {/* Mode Tag */}
        <div className="mb-4">
          <span className={`text-xs font-bold uppercase tracking-widest px-4 py-1 rounded-full border ${
            mode === 'focus'
              ? 'bg-indigo-500/15 text-indigo-300 border-indigo-500/30'
              : 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30'
          }`}>
            {mode === 'focus' ? '🎯 DEEP FOCUS SESSION' : '☕ SHORT BREAK RECOVERY'}
          </span>
        </div>

        {/* Large Circular Timer SVG */}
        <div className="relative w-80 h-80 flex items-center justify-center my-4">
          <svg className="w-full h-full transform -rotate-90" viewBox="0 0 320 320">
            {/* Background Ring */}
            <circle
              cx="160"
              cy="160"
              r={circleRadius}
              stroke="currentColor"
              strokeWidth="10"
              className="text-slate-800/80"
              fill="transparent"
            />
            {/* Progress Ring */}
            <circle
              cx="160"
              cy="160"
              r={circleRadius}
              stroke="currentColor"
              strokeWidth="10"
              strokeDasharray={circumference}
              strokeDashoffset={strokeDashoffset}
              strokeLinecap="round"
              className={`transition-all duration-1000 ${
                mode === 'focus' ? 'text-indigo-500' : 'text-emerald-500'
              }`}
              fill="transparent"
            />
          </svg>

          {/* Time digits */}
          <div className="absolute flex flex-col items-center justify-center">
            <span className="text-6xl font-extrabold tracking-tighter text-white font-mono">
              {formatTime(timeLeft)}
            </span>
            <span className="text-xs text-slate-400 mt-2 font-medium">
              {isActive ? 'Session in progress...' : 'Paused'}
            </span>
          </div>
        </div>

        {/* Controls: Start, Pause, Reset, Skip */}
        <div className="flex items-center gap-4 mt-6">
          <button
            onClick={handleReset}
            className="p-3 bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-400 hover:text-white rounded-2xl transition-colors"
            title="Reset Timer"
          >
            <RotateCcw className="w-5 h-5" />
          </button>

          <button
            onClick={toggleTimer}
            className={`px-8 py-4 rounded-2xl text-base font-bold text-white flex items-center gap-3 transition-all shadow-xl ${
              isActive
                ? 'bg-amber-600 hover:bg-amber-500 shadow-amber-950/40'
                : 'bg-indigo-600 hover:bg-indigo-500 shadow-indigo-950/40'
            }`}
          >
            {isActive ? (
              <>
                <Pause className="w-5 h-5" /> Pause
              </>
            ) : (
              <>
                <Play className="w-5 h-5" /> Start Focus
              </>
            )}
          </button>

          <button
            onClick={handleSkip}
            className="p-3 bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-400 hover:text-white rounded-2xl transition-colors"
            title="Skip to next session"
          >
            <SkipForward className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Metrics Row: Focus time, sessions, tasks completed during focus, streak */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="bg-[#111827] border border-slate-800 rounded-2xl p-4">
          <span className="text-xs text-slate-400 uppercase tracking-wider block">Today's Focus Time</span>
          <div className="mt-2 flex items-baseline gap-1">
            <span className="text-2xl font-bold text-cyan-400">{Math.floor(todayFocusMinutes)}</span>
            <span className="text-xs text-slate-400">minutes</span>
          </div>
          <span className="text-[11px] text-slate-400 mt-1 block">Goal: 120 mins</span>
        </div>

        <div className="bg-[#111827] border border-slate-800 rounded-2xl p-4">
          <span className="text-xs text-slate-400 uppercase tracking-wider block">Sessions Done</span>
          <div className="mt-2 flex items-baseline gap-1">
            <span className="text-2xl font-bold text-indigo-400">{sessionsCompleted}</span>
            <span className="text-xs text-slate-400">blocks</span>
          </div>
          <span className="text-[11px] text-slate-400 mt-1 block">Optimal flow state</span>
        </div>

        <div className="bg-[#111827] border border-slate-800 rounded-2xl p-4">
          <span className="text-xs text-slate-400 uppercase tracking-wider block">Tasks Completed</span>
          <div className="mt-2 flex items-baseline gap-1">
            <span className="text-2xl font-bold text-emerald-400">5</span>
            <span className="text-xs text-slate-400">during focus</span>
          </div>
          <span className="text-[11px] text-slate-400 mt-1 block">High productivity rate</span>
        </div>

        <div className="bg-[#111827] border border-slate-800 rounded-2xl p-4">
          <span className="text-xs text-slate-400 uppercase tracking-wider block">Daily Streak</span>
          <div className="mt-2 flex items-center gap-2">
            <span className="text-2xl font-bold text-amber-400">{streakDays} Days</span>
            <Flame className="w-5 h-5 text-amber-400 animate-pulse" />
          </div>
          <span className="text-[11px] text-slate-400 mt-1 block">Consecutive study days</span>
        </div>
      </div>

      {/* Focus Checklist to check off during session */}
      <div className="bg-[#111827] border border-slate-800 rounded-2xl p-5 space-y-4">
        <h3 className="text-sm font-bold text-white flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          Focus Session Checklist
        </h3>

        <div className="space-y-2.5">
          {tasks.slice(0, 3).map(task => (
            <div
              key={task.id}
              className="p-3 bg-slate-900/70 border border-slate-800 rounded-xl flex items-center justify-between text-xs"
            >
              <div className="flex items-center gap-3">
                <button
                  onClick={() => toggleTaskCompletion(task.id)}
                  className={`w-5 h-5 rounded-md border flex items-center justify-center transition-colors ${
                    task.status === 'COMPLETED'
                      ? 'bg-emerald-500 border-emerald-500 text-white'
                      : 'border-slate-700 hover:border-indigo-500'
                  }`}
                >
                  {task.status === 'COMPLETED' && <CheckCircle2 className="w-3.5 h-3.5" />}
                </button>
                <span className={`font-semibold ${task.status === 'COMPLETED' ? 'line-through text-slate-500' : 'text-slate-200'}`}>
                  {task.title}
                </span>
              </div>
              <span className="text-[10px] text-slate-400">{task.projectName}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
