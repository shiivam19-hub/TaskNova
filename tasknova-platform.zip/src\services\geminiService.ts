import { apiClient } from './apiClient';

// AI Assistant Service for TASKNOVA

export interface AIMessage {
  id: string;
  sender: 'user' | 'assistant';
  text: string;
  timestamp: string;
  actionableTasks?: string[];
  suggestedResources?: { title: string; type: string }[];
}

export const promptTemplates = [
  {
    title: '✨ What should I work on today?',
    prompt: 'What should I work on today based on my active deliverables, upcoming sprint milestones, and study goals?',
    category: 'Prioritization'
  },
  {
    title: 'Explain Polymorphism',
    prompt: 'Explain polymorphism in simple terms with a real-world example and a quick code analogy.',
    category: 'Study'
  },
  {
    title: 'Break AI Project into Tasks',
    prompt: 'Break my AI project into 7 structured engineering tasks with priorities and milestones.',
    category: 'Project'
  },
  {
    title: 'Generate Quiz Questions',
    prompt: 'Generate 4 multiple-choice quiz questions on Tree Traversals and BST properties with explanations.',
    category: 'Study'
  },
  {
    title: 'Summarize Notes',
    prompt: 'Summarize key takeaways from distributed consensus algorithms (Raft vs Paxos).',
    category: 'Academic'
  },
  {
    title: 'Analyze Project Risks',
    prompt: 'Analyze current risks for the AI Analytics Platform project and recommend mitigation strategies.',
    category: 'Management'
  }
];

export async function generateAIResponse(userPrompt: string): Promise<AIMessage> {
  const id = `ai-msg-${Date.now()}`;
  const timestamp = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

  try {
    const backendRes = await apiClient.ai.chat(userPrompt);
    if (backendRes && backendRes.reply) {
      const lines = backendRes.reply.split('\n');
      const taskLines = lines
        .filter(l => l.trim().startsWith('- [ ]') || l.trim().startsWith('* Task') || (l.includes('Phase') && l.includes(':')))
        .map(l => l.replace(/^[-*\[\]\d.]+\s*/, '').trim())
        .filter(Boolean);

      return {
        id,
        sender: 'assistant',
        timestamp,
        text: backendRes.reply,
        actionableTasks: taskLines.length > 0 ? taskLines.slice(0, 6) : undefined
      };
    }
  } catch (err) {
    console.warn('Backend AI chat error, falling back to local reasoning:', err);
  }

  // Fallback to local structured reasoning
  const lower = userPrompt.toLowerCase();

  if (lower.includes('polymorphism')) {
    return {
      id,
      sender: 'assistant',
      timestamp,
      text: `### What is Polymorphism? (Explained Simply)

**Polymorphism** comes from the Greek words *poly* (many) and *morph* (form). In computer science, it means:

> **"The ability of different objects to respond to the very same message or function call in their own specific way."**

---

#### 🚗 Real-World Analogy: The Steering Wheel
* Think of the command **"Turn Left"**.
* If you tell a **Bicycle** to turn left, you lean your handlebars.
* If you tell a **Sports Car** to turn left, the power rack-and-pinion shifts the wheels.
* If you tell a **Sailboat** to turn left, the rudder pivots in the water.

The interface is always **turn()**, but each vehicle executes it according to its own nature.

---

#### 💻 Code Illustration (TypeScript / Object-Oriented):
\`\`\`typescript
interface Shape {
  calculateArea(): number;
}

class Circle implements Shape {
  constructor(private radius: number) {}
  calculateArea() { return Math.PI * this.radius ** 2; }
}

class Rectangle implements Shape {
  constructor(private w: number, private h: number) {}
  calculateArea() { return this.w * this.h; }
}

// Same method call handles any shape!
function printArea(shape: Shape) {
  console.log("Area is: " + shape.calculateArea());
}
\`\`\`

#### Key Benefits:
1. **Extensibility**: Add new shapes or features without modifying existing client code.
2. **Decoupling**: Code depends on general contracts (interfaces), not rigid implementations.`,
      suggestedResources: [
        { title: 'Designing Data-Intensive Applications', type: 'book' },
        { title: 'Object-Oriented Design Patterns Course', type: 'video' }
      ]
    };
  }

  if (lower.includes('break') && (lower.includes('task') || lower.includes('project') || lower.includes('ai'))) {
    return {
      id,
      sender: 'assistant',
      timestamp,
      text: `Here is the structured task breakdown for your **AI Project**, organized sequentially from architecture through deployment:

1. **Requirement Analysis & Dataset Scoping** (Priority: High)
   * Define input/output contracts, target inference latency (<150ms), and gather training/validation benchmarks.
2. **UI & Interaction Design** (Priority: Medium)
   * Draft user flows, chat interface states, model parameter controls, and responsive layouts in Figma.
3. **Database & Schema Architecture** (Priority: High)
   * Configure vector database indexing, user session schemas, and audit logging tables.
4. **Backend Pipeline & Inference Service** (Priority: High)
   * Implement asynchronous streaming pipelines with rate limiting and fallback handlers.
5. **API & Gateway Integration** (Priority: Urgent)
   * Wire client endpoints, token verification interceptors, and CORS policies.
6. **Model Evaluation & Stress Testing** (Priority: High)
   * Execute automated load testing with 500 concurrent sessions and adversarial prompt tests.
7. **Production Cloud Deployment & Monitoring** (Priority: High)
   * Containerize with Docker, configure Kubernetes horizontal pod autoscaling, and setup CloudWatch/Prometheus alerts.`,
      actionableTasks: [
        'Requirement analysis & dataset scoping',
        'UI & Interaction design in Figma',
        'Database & schema architecture',
        'Backend pipeline & inference service',
        'API & gateway integration',
        'Model evaluation & stress testing',
        'Production cloud deployment & monitoring'
      ]
    };
  }

  if (lower.includes('quiz') || lower.includes('question') || lower.includes('tree') || lower.includes('bst')) {
    return {
      id,
      sender: 'assistant',
      timestamp,
      text: `### 🎯 Quick Diagnostic Quiz: Binary Search Trees & Traversals

**Question 1: Inorder Traversal Property**
What is the result of performing an Inorder (L-N-R) traversal on a valid Binary Search Tree?
* A) Nodes are visited in reverse postorder
* B) Nodes are visited in strictly non-decreasing sorted order ✅
* C) Elements are grouped by depth level
* D) The tree becomes balanced automatically
* *Explanation: By BST definition, all left descendants are smaller and right descendants larger. Inorder visits Left, then Node, then Right, giving sorted order.*

---

**Question 2: Time Complexity in Worst-Case**
What is the worst-case search time complexity in an un-balanced BST of $N$ nodes?
* A) $O(\\log N)$
* B) $O(1)$
* C) $O(N)$ ✅
* D) $O(N \\log N)$
* *Explanation: If elements were inserted in sorted order, the BST degenerates into a linked list of height $N$.*

---

**Question 3: Lowest Common Ancestor (LCA)**
In a BST, if both node $P$ and node $Q$ have keys smaller than the current root node, where must their LCA lie?
* A) In the right subtree
* B) In the left subtree ✅
* C) The root itself is always the LCA
* D) At the deepest leaf
* *Explanation: Since both keys are strictly less than root, both nodes reside in the left branch.*`,
      suggestedResources: [
        { title: 'Introduction to Algorithms (CLRS) - Chapter 12', type: 'book' },
        { title: 'Graph & Tree Algorithms Full Course', type: 'video' }
      ]
    };
  }

  if (lower.includes('summar') || lower.includes('note') || lower.includes('raft') || lower.includes('paxos')) {
    return {
      id,
      sender: 'assistant',
      timestamp,
      text: `### 📝 Study Notes Summary: Raft vs. Paxos Consensus

#### 1. Core Mission
Both **Paxos** and **Raft** solve the replicated state machine problem: ensuring a distributed cluster of nodes agrees on an identical sequence of state changes even in the presence of network partitions and node crashes.

#### 2. Key Architectural Differences
* **Raft (Understandability First)**:
  * Decomposes consensus into distinct subproblems: **Leader Election**, **Log Replication**, and **Safety**.
  * Strong leader approach: client requests must go through the leader; followers only passively accept log entries.
  * Easy to reason about term numbers and heartbeats.
* **Multi-Paxos (High Performance, High Complexity)**:
  * Uses two-phase prepare/accept rounds.
  * Permits out-of-order log commitments which complicates state compaction and log reconciliation.
  * Notoriously difficult to implement in production without ambiguities.

#### 🎯 Key Revision Takeaway:
* Use **Raft** for straightforward correctness, active maintenance, and predictable operational debugging (e.g. etcd, CockroachDB).
* Understand Paxos conceptually for academic theory and historical foundation.`,
      suggestedResources: [
        { title: 'Designing Data-Intensive Applications (Chapter 9)', type: 'book' }
      ]
    };
  }

  // Default intelligent assistant response
  return {
    id,
    sender: 'assistant',
    timestamp,
    text: `### TASKNOVA AI Analysis & Guidance

I've processed your prompt: **"${userPrompt}"**.

Here is an actionable breakdown tailored to your current projects and study roadmap:

1. **Strategic Alignment**:
   Ensure this objective is mapped to your active milestones in **Website Redesign** or **Data Structures Study Plan**.
2. **Immediate Next Step**:
   Create a tracked task with a clear acceptance criterion and assign a realistic time-box.
3. **Productivity Recommendation**:
   Schedule a 25-minute Pomodoro session in the **Focus Timer** to make uninterrupted progress.

*Would you like me to automatically add this as an interactive task or generate flashcard questions for this topic?*`
  };
}
