import React, { useState } from 'react';
import {
  Bell,
  CheckCheck,
  Filter,
  CheckCircle2,
  Trash2,
  Clock,
  Sparkles,
  ExternalLink
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { useToast } from '../../context/ToastContext';
import { NotificationItem } from '../../types';

export const NotificationsView: React.FC = () => {
  const {
    notifications,
    markNotificationAsRead,
    markAllNotificationsAsRead,
    setActiveTab
  } = useApp();

  const { showToast } = useToast();
  const [filterType, setFilterType] = useState<string>('all');

  const unreadCount = notifications.filter(n => !n.read).length;

  const filteredNotifications = notifications.filter(n => {
    if (filterType === 'unread') return !n.read;
    if (filterType === 'deadline') return n.type === 'deadline';
    if (filterType === 'comment') return n.type === 'comment';
    if (filterType === 'file') return n.type === 'file';
    if (filterType === 'assignment') return n.type === 'assignment';
    return true;
  });

  const getNotificationBadge = (type: NotificationItem['type']) => {
    switch (type) {
      case 'deadline':
        return 'bg-amber-500/15 text-amber-300 border-amber-500/30';
      case 'comment':
        return 'bg-cyan-500/15 text-cyan-300 border-cyan-500/30';
      case 'file':
        return 'bg-indigo-500/15 text-indigo-300 border-indigo-500/30';
      case 'assignment':
        return 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30';
      default:
        return 'bg-slate-800 text-slate-300 border-slate-700';
    }
  };

  return (
    <div className="space-y-6 animate-fade-in pb-16 max-w-4xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-white flex items-center gap-2.5">
            <Bell className="w-6 h-6 text-indigo-400" />
            Notifications Center
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Real-time project updates, deadline warnings, team mentions, and system dispatches.
          </p>
        </div>

        {unreadCount > 0 && (
          <button
            onClick={markAllNotificationsAsRead}
            className="flex items-center gap-2 px-3.5 py-2 bg-slate-900 border border-slate-800 hover:border-slate-700 text-xs font-semibold text-indigo-400 hover:text-indigo-300 rounded-xl transition-colors self-start sm:self-auto"
          >
            <CheckCheck className="w-4 h-4" />
            Mark all as read ({unreadCount})
          </button>
        )}
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-2 bg-[#111827] border border-slate-800 p-2 rounded-2xl overflow-x-auto text-xs font-semibold">
        {[
          { id: 'all', label: 'All Notifications' },
          { id: 'unread', label: `Unread (${unreadCount})` },
          { id: 'deadline', label: 'Deadlines' },
          { id: 'comment', label: 'Comments' },
          { id: 'file', label: 'Files' },
          { id: 'assignment', label: 'Assignments' }
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => setFilterType(tab.id)}
            className={`px-3.5 py-1.5 rounded-xl transition-all shrink-0 ${
              filterType === tab.id
                ? 'bg-indigo-600 text-white shadow-md shadow-indigo-950/40'
                : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Notifications List */}
      <div className="space-y-3">
        {filteredNotifications.length === 0 ? (
          <div className="p-12 text-center bg-[#111827] border border-slate-800 rounded-2xl text-slate-400 text-xs">
            <Bell className="w-10 h-10 text-slate-600 mx-auto mb-2" />
            <p className="font-semibold text-slate-300">You're all caught up! 🎉</p>
            <p className="text-[11px] text-slate-500 mt-1">No new notifications in this filter category.</p>
          </div>
        ) : (
          filteredNotifications.map(item => (
            <div
              key={item.id}
              onClick={() => {
                markNotificationAsRead(item.id);
                if (item.linkTo) setActiveTab(item.linkTo as any);
              }}
              className={`p-4 rounded-2xl border transition-all flex items-start justify-between gap-4 cursor-pointer ${
                !item.read
                  ? 'bg-indigo-950/25 border-indigo-500/40 shadow-sm'
                  : 'bg-[#111827] border-slate-800/80 hover:border-slate-700'
              }`}
            >
              <div className="flex items-start gap-3 min-w-0">
                <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border mt-0.5 shrink-0 ${getNotificationBadge(item.type)}`}>
                  {item.type.toUpperCase()}
                </span>

                <div className="space-y-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <h4 className="font-bold text-slate-100 text-xs">{item.title}</h4>
                    {!item.read && (
                      <span className="w-2 h-2 rounded-full bg-indigo-500" />
                    )}
                  </div>
                  <p className="text-xs text-slate-300 leading-normal">{item.message}</p>
                  <span className="text-[10px] text-slate-500 block pt-0.5">{item.timestamp}</span>
                </div>
              </div>

              <div className="flex items-center gap-2 shrink-0">
                {!item.read && (
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      markNotificationAsRead(item.id);
                    }}
                    className="p-1 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
                    title="Mark read"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                  </button>
                )}
                <ExternalLink className="w-3.5 h-3.5 text-slate-500" />
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
