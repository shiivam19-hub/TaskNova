import React, { useState } from 'react';
import {
  BookOpen,
  FileText,
  Video,
  Bookmark,
  Search,
  ExternalLink,
  Plus,
  Lock,
  Sparkles,
  Calendar,
  CheckCircle2,
  Trash2,
  BookmarkCheck
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { StudyResource } from '../../types';
import { useToast } from '../../context/ToastContext';
import { searchOpenLibrary, searchCrossrefPapers, searchEducationalVideos } from '../../services/apiArchitecture';

export const StudyHubView: React.FC = () => {
  const {
    studyResources,
    toggleSaveResource,
    addStudyResource,
    setActiveTab
  } = useApp();

  const { showToast } = useToast();

  const [activeTab, setActiveTabLocal] = useState<'Library' | 'Research' | 'Videos' | 'Notes'>('Library');
  const [searchQuery, setSearchQuery] = useState('');

  // Study Note state
  const [noteTitle, setNoteTitle] = useState('');
  const [noteContent, setNoteContent] = useState('');
  const [noteIsPrivate, setNoteIsPrivate] = useState(true);
  const [notesList, setNotesList] = useState([
    {
      id: 'sn1',
      title: 'B-Tree & LSM-Tree Storage Comparison',
      content: 'B-Trees optimize for point reads (O(log N) random I/O). LSM-Trees optimize for fast sequential write throughput by batching in memory and compacting SSTables in background.',
      date: 'Sept 10, 2026',
      isPrivate: true
    },
    {
      id: 'sn2',
      title: 'Dynamic Programming Patterns: Memoization vs Tabulation',
      content: 'Top-down with recursive call stack and cache table vs Bottom-up iterative table filling. Always check state space reduction (e.g. keeping only prev 2 states).',
      date: 'Sept 9, 2026',
      isPrivate: false
    }
  ]);

  const handleSaveNote = (e: React.FormEvent) => {
    e.preventDefault();
    if (!noteTitle.trim() || !noteContent.trim()) return;
    const newN = {
      id: `sn${Date.now()}`,
      title: noteTitle.trim(),
      content: noteContent.trim(),
      date: 'Just now',
      isPrivate: noteIsPrivate
    };
    setNotesList(prev => [newN, ...prev]);
    setNoteTitle('');
    setNoteContent('');
    showToast('Study Note Saved', noteIsPrivate ? '🔒 Private Note stored securely.' : 'Note saved to study hub.', 'success');
  };

  const filteredResources = studyResources.filter(r => {
    const matchesSearch = r.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      r.authorsOrChannel.toLowerCase().includes(searchQuery.toLowerCase());
    if (activeTab === 'Library') return r.type === 'book' && matchesSearch;
    if (activeTab === 'Research') return r.type === 'paper' && matchesSearch;
    if (activeTab === 'Videos') return r.type === 'video' && matchesSearch;
    return matchesSearch;
  });

  return (
    <div className="space-y-6 animate-fade-in pb-16">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-white flex items-center gap-2.5">
            <BookOpen className="w-6 h-6 text-purple-400" />
            Study Hub & Academic Productivity
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Access books via Open Library, scientific papers via Crossref, and technical lectures via YouTube Data API.
          </p>
        </div>

        <button
          onClick={() => setActiveTab('study-planner')}
          className="flex items-center gap-2 px-4 py-2.5 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white text-xs font-semibold rounded-xl shadow-lg shadow-purple-950/40 transition-all self-start sm:self-auto"
        >
          <Calendar className="w-4 h-4" />
          Open 7-Day Study Planner
        </button>
      </div>

      {/* Hub Tabs */}
      <div className="bg-[#111827] border border-slate-800 rounded-2xl p-4 flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-1.5 overflow-x-auto w-full sm:w-auto">
          {[
            { id: 'Library', label: '📚 My Library', source: 'Open Library' },
            { id: 'Research', label: '🔬 Research Papers', source: 'Crossref REST' },
            { id: 'Videos', label: '🎥 Learning Videos', source: 'YouTube API' },
            { id: 'Notes', label: '📝 Study Notes', source: 'Markdown' }
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTabLocal(tab.id as any)}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-all shrink-0 ${
                activeTab === tab.id
                  ? 'bg-purple-600 text-white shadow-md shadow-purple-950/40'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {activeTab !== 'Notes' && (
          <div className="relative w-full sm:w-72">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              placeholder="Search resource or author..."
              className="w-full pl-8 pr-3 py-1.5 bg-slate-900 border border-slate-700 rounded-xl text-xs text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-purple-500"
            />
          </div>
        )}
      </div>

      {/* 1. MY LIBRARY (Open Library API) */}
      {activeTab === 'Library' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between text-xs text-slate-400 px-1">
            <span>Powered by Open Library Public REST API Architecture</span>
            <span>{filteredResources.length} items cataloged</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {filteredResources.map(book => (
              <div
                key={book.id}
                className="bg-[#111827] border border-slate-800 rounded-2xl p-5 shadow-sm space-y-3 flex flex-col justify-between hover:border-slate-700 transition-colors"
              >
                <div className="space-y-2">
                  <div className="flex items-start justify-between gap-2">
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-indigo-500/15 text-indigo-300 border border-indigo-500/30">
                      Open Library API • {book.year}
                    </span>
                    <button
                      onClick={() => {
                        toggleSaveResource(book.id);
                        showToast(book.saved ? 'Removed from saved' : 'Book Saved', `"${book.title}"`, 'info');
                      }}
                      className="p-1 text-slate-400 hover:text-purple-400 transition-colors"
                      title={book.saved ? 'Saved to library' : 'Save book'}
                    >
                      {book.saved ? (
                        <BookmarkCheck className="w-4 h-4 text-purple-400" />
                      ) : (
                        <Bookmark className="w-4 h-4" />
                      )}
                    </button>
                  </div>

                  <h3 className="text-sm font-bold text-white leading-snug">{book.title}</h3>
                  <p className="text-xs text-slate-400">Authors: {book.authorsOrChannel}</p>
                  <p className="text-[11px] text-slate-500 font-mono">{book.identifierOrUrl}</p>
                </div>

                <div className="pt-3 border-t border-slate-800 flex items-center justify-between text-xs">
                  <div className="flex items-center gap-1.5">
                    {book.tags.map(t => (
                      <span key={t} className="text-[9px] px-1.5 py-0.5 rounded bg-slate-800 text-slate-400">
                        {t}
                      </span>
                    ))}
                  </div>
                  <button
                    onClick={() => {
                      window.open(`https://openlibrary.org/search?q=${encodeURIComponent(book.title)}`, '_blank');
                    }}
                    className="text-xs text-purple-400 hover:text-purple-300 font-medium flex items-center gap-1"
                  >
                    View on Open Library <ExternalLink className="w-3 h-3" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 2. RESEARCH PAPERS (Crossref REST API) */}
      {activeTab === 'Research' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between text-xs text-slate-400 px-1">
            <span>Powered by Crossref DOI & Metadata REST API Architecture</span>
            <span>{filteredResources.length} peer-reviewed works</span>
          </div>

          <div className="grid grid-cols-1 gap-4">
            {filteredResources.map(paper => (
              <div
                key={paper.id}
                className="bg-[#111827] border border-slate-800 rounded-2xl p-5 shadow-sm space-y-3 hover:border-slate-700 transition-colors"
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-cyan-500/15 text-cyan-300 border border-cyan-500/30">
                        Crossref REST API • {paper.year}
                      </span>
                      <span className="text-xs text-slate-400">Journal: Advances in AI / IEEE</span>
                    </div>
                    <h3 className="text-base font-bold text-white mt-1">{paper.title}</h3>
                    <p className="text-xs text-slate-300">Authors: {paper.authorsOrChannel}</p>
                    <p className="text-[11px] text-indigo-400 font-mono">DOI: {paper.identifierOrUrl}</p>
                  </div>

                  <button
                    onClick={() => {
                      toggleSaveResource(paper.id);
                      showToast(paper.saved ? 'Removed from saved' : 'Research Saved', `"${paper.title}"`, 'info');
                    }}
                    className={`p-2 rounded-xl border text-xs font-semibold flex items-center gap-1.5 transition-colors ${
                      paper.saved
                        ? 'bg-purple-950/60 border-purple-500/40 text-purple-300'
                        : 'bg-slate-900 border-slate-700 text-slate-300 hover:text-white'
                    }`}
                  >
                    <Bookmark className="w-3.5 h-3.5" />
                    {paper.saved ? 'Saved' : 'Save'}
                  </button>
                </div>

                <div className="pt-3 border-t border-slate-800 flex items-center justify-between text-xs">
                  <div className="flex items-center gap-1.5">
                    {paper.tags.map(t => (
                      <span key={t} className="text-[9px] px-1.5 py-0.5 rounded bg-slate-800 text-slate-400">
                        {t}
                      </span>
                    ))}
                  </div>
                  <button
                    onClick={() => window.open(`https://doi.org/${paper.identifierOrUrl}`, '_blank')}
                    className="text-xs text-cyan-400 hover:text-cyan-300 font-medium flex items-center gap-1"
                  >
                    Open DOI Resolver <ExternalLink className="w-3 h-3" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 3. LEARNING VIDEOS (YouTube Data API) */}
      {activeTab === 'Videos' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between text-xs text-slate-400 px-1">
            <span>Powered by YouTube Data API v3 Architecture</span>
            <span>Curated Educational Lectures</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {filteredResources.map(video => (
              <div
                key={video.id}
                className="bg-[#111827] border border-slate-800 rounded-2xl p-5 shadow-sm space-y-3 flex flex-col justify-between hover:border-slate-700 transition-colors"
              >
                <div className="space-y-2">
                  <div className="flex items-start justify-between gap-2">
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-rose-500/15 text-rose-300 border border-rose-500/30">
                      YouTube Data API • {video.year}
                    </span>
                    <button
                      onClick={() => {
                        toggleSaveResource(video.id);
                        showToast(video.saved ? 'Removed from saved' : 'Video Bookmarked', `"${video.title}"`, 'info');
                      }}
                      className="p-1 text-slate-400 hover:text-rose-400 transition-colors"
                      title="Bookmark video"
                    >
                      {video.saved ? (
                        <BookmarkCheck className="w-4 h-4 text-rose-400" />
                      ) : (
                        <Bookmark className="w-4 h-4" />
                      )}
                    </button>
                  </div>

                  <h3 className="text-sm font-bold text-white leading-snug">{video.title}</h3>
                  <p className="text-xs text-slate-400">Channel: {video.authorsOrChannel}</p>
                </div>

                <div className="pt-3 border-t border-slate-800 flex items-center justify-between text-xs">
                  <div className="flex items-center gap-1.5">
                    {video.tags.map(t => (
                      <span key={t} className="text-[9px] px-1.5 py-0.5 rounded bg-slate-800 text-slate-400">
                        {t}
                      </span>
                    ))}
                  </div>
                  <button
                    onClick={() => window.open(video.identifierOrUrl, '_blank')}
                    className="text-xs text-rose-400 hover:text-rose-300 font-medium flex items-center gap-1"
                  >
                    Watch Lecture <ExternalLink className="w-3 h-3" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 4. STUDY NOTES WITH PRIVATE NOTES (Section 27) */}
      {activeTab === 'Notes' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Note Editor Form */}
          <div className="lg:col-span-1 bg-[#111827] border border-slate-800 rounded-2xl p-5 space-y-4">
            <h3 className="text-sm font-bold text-white">Create Study Note</h3>
            <form onSubmit={handleSaveNote} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-400 mb-1 font-semibold uppercase text-[10px]">Title</label>
                <input
                  type="text"
                  required
                  value={noteTitle}
                  onChange={e => setNoteTitle(e.target.value)}
                  placeholder="e.g. Raft Consensus Algorithm Notes"
                  className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-slate-100 focus:outline-none focus:border-purple-500"
                />
              </div>

              <div>
                <label className="block text-slate-400 mb-1 font-semibold uppercase text-[10px]">Content</label>
                <textarea
                  rows={5}
                  required
                  value={noteContent}
                  onChange={e => setNoteContent(e.target.value)}
                  placeholder="Write formulas, algorithms, or key exam concepts..."
                  className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-slate-100 focus:outline-none focus:border-purple-500"
                />
              </div>

              {/* 🔒 Private Note Toggle (Section 27) */}
              <div className="p-3 bg-indigo-950/30 border border-indigo-500/20 rounded-xl flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Lock className="w-4 h-4 text-indigo-400" />
                  <div>
                    <span className="font-semibold text-slate-200 block text-[11px]">🔒 Private Note</span>
                    <span className="text-[10px] text-slate-400">Keep exclusive to your account</span>
                  </div>
                </div>
                <input
                  type="checkbox"
                  checked={noteIsPrivate}
                  onChange={e => setNoteIsPrivate(e.target.checked)}
                  className="w-4 h-4 rounded text-indigo-600 focus:ring-indigo-500"
                />
              </div>

              <button
                type="submit"
                className="w-full py-2 bg-purple-600 hover:bg-purple-500 text-white font-semibold rounded-xl transition-colors"
              >
                Save Note
              </button>
            </form>
          </div>

          {/* Notes Display List */}
          <div className="lg:col-span-2 space-y-4">
            <h3 className="text-sm font-bold text-white">Saved Notes & Revisions</h3>
            <div className="space-y-3">
              {notesList.map(note => (
                <div
                  key={note.id}
                  className="p-4 bg-[#111827] border border-slate-800 rounded-2xl space-y-2 hover:border-slate-700 transition-colors"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <h4 className="font-bold text-slate-100 text-sm">{note.title}</h4>
                      {note.isPrivate && (
                        <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-indigo-950 text-indigo-300 border border-indigo-500/30 flex items-center gap-1">
                          <Lock className="w-3 h-3 text-indigo-400" /> Private Note
                        </span>
                      )}
                    </div>
                    <span className="text-[10px] text-slate-500">{note.date}</span>
                  </div>

                  <p className="text-xs text-slate-300 leading-relaxed whitespace-pre-wrap">
                    {note.content}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
