import { Router, Response } from 'express';
import { PrismaClient } from '@prisma/client';
import path from 'path';
import fs from 'fs';
import { authenticate, AuthRequest } from '../middleware/auth';
import { upload } from '../middleware/upload';

const router = Router();
const prisma = new PrismaClient();

function formatBytes(bytes: number, decimals = 1): string {
  if (bytes === 0) return '0 Bytes';
  const k = 1024;
  const dm = decimals < 0 ? 0 : decimals;
  const sizes = ['Bytes', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
}

function getFileType(filename: string): string {
  const ext = path.extname(filename).toLowerCase().replace('.', '');
  if (['png', 'jpg', 'jpeg', 'gif', 'webp'].includes(ext)) return 'image';
  if (['doc', 'docx', 'txt', 'rtf'].includes(ext)) return 'doc';
  if (['xls', 'xlsx', 'csv'].includes(ext)) return 'sheet';
  if (['ppt', 'pptx'].includes(ext)) return 'presentation';
  if (ext === 'pdf') return 'pdf';
  if (['fig', 'sketch', 'xd'].includes(ext)) return 'fig';
  if (['zip', 'rar', 'tar', 'gz'].includes(ext)) return 'zip';
  return 'file';
}

// List files
router.get('/', authenticate, async (req: AuthRequest, res: Response) => {
  try {
    const { projectId } = req.query;

    const files = await prisma.file.findMany({
      where: {
        ...(projectId && projectId !== 'all' ? { projectId: String(projectId) } : {})
      },
      include: {
        project: {
          select: { id: true, name: true }
        }
      },
      orderBy: { createdAt: 'desc' }
    });

    res.json(files);
  } catch (error) {
    console.error('Fetch files error:', error);
    res.status(500).json({ error: 'Failed to fetch files' });
  }
});

// Upload a file
router.post('/upload', authenticate, upload.single('file'), async (req: AuthRequest, res: Response) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'No file uploaded' });
    }

    const { projectId } = req.body;
    if (!projectId) {
      // Remove temporary uploaded file if projectId is missing
      if (fs.existsSync(req.file.path)) {
        fs.unlinkSync(req.file.path);
      }
      return res.status(400).json({ error: 'projectId is required' });
    }

    const project = await prisma.project.findUnique({ where: { id: projectId } });
    if (!project) {
      if (fs.existsSync(req.file.path)) {
        fs.unlinkSync(req.file.path);
      }
      return res.status(404).json({ error: 'Project not found' });
    }

    const uploadedBy = req.user?.name || 'Shivam Singh';
    const readableSize = formatBytes(req.file.size);
    const fileType = getFileType(req.file.originalname);

    const fileRecord = await prisma.file.create({
      data: {
        projectId,
        name: req.file.originalname,
        size: readableSize,
        type: fileType,
        mimeType: req.file.mimetype,
        path: req.file.filename, // store filename in uploads dir
        uploadedBy
      }
    });

    // Record activity
    await prisma.activity.create({
      data: {
        authorName: uploadedBy,
        action: 'uploaded file',
        target: req.file.originalname,
        type: 'upload',
        projectId
      }
    });

    res.status(201).json(fileRecord);
  } catch (error: any) {
    console.error('File upload error:', error);
    res.status(500).json({ error: error.message || 'File upload failed' });
  }
});

// Download file
router.get('/:id/download', authenticate, async (req: AuthRequest, res: Response) => {
  try {
    const { id } = req.params;
    const file = await prisma.file.findUnique({ where: { id } });

    if (!file) {
      return res.status(404).json({ error: 'File not found' });
    }

    if (!file.path) {
      return res.status(404).json({ error: 'Physical file not found' });
    }

    const filePath = path.join(process.cwd(), 'uploads', file.path);
    if (!fs.existsSync(filePath)) {
      return res.status(404).json({ error: 'Physical file no longer exists on disk' });
    }

    res.download(filePath, file.name);
  } catch (error) {
    console.error('Download file error:', error);
    res.status(500).json({ error: 'Failed to download file' });
  }
});

// Delete file
router.delete('/:id', authenticate, async (req: AuthRequest, res: Response) => {
  try {
    const { id } = req.params;
    const file = await prisma.file.findUnique({ where: { id } });

    if (!file) {
      return res.status(404).json({ error: 'File not found' });
    }

    if (file.path) {
      const filePath = path.join(process.cwd(), 'uploads', file.path);
      if (fs.existsSync(filePath)) {
        fs.unlinkSync(filePath);
      }
    }

    await prisma.file.delete({ where: { id } });
    res.json({ message: 'File deleted successfully' });
  } catch (error) {
    console.error('Delete file error:', error);
    res.status(500).json({ error: 'Failed to delete file' });
  }
});

export default router;
