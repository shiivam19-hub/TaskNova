import React from 'react';
import { Modal } from './Modal';
import {
  Sparkles,
  Command,
  CheckCircle2,
  FolderKanban,
  BookOpen,
  Timer,
  ShieldCheck,
  Zap,
  Globe
} from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const HelpModal: React.FC = () => {
  const { isHelpModalOpen, setIsHelpModalOpen } = useApp();

  if (!isHelpModalOpen) return null;

  return (
    <Modal
      isOpen={isHelpModalOpen}
      onClose={() => setIsHelpModalOpen(false)}
      title="TASKNOVA Platform Documentation"
      subtitle="Plan. Collaborate. Learn. Achieve. • Complete Guide"
      size="lg"
    >
      <div className="space-y-6 text-xs text-slate-300 leading-relaxed">
        {/* About TASKNOVA */}
        <div className="p-4 bg-indigo-950/30 border border-indigo-500/30 rounded-xl space-y-2">
          <h4 className="font-bold text-white flex items-center gap-1.5 text-sm">
            <Sparkles className="w-4 h-4 text-indigo-400" />
            Welcome to TASKNOVA
          </h4>
          <p>
            TASKNOVA combines professional enterprise project management (Kanban, Milestones, Timelines, Team Collaboration) with rigorous academic productivity (Open Library books, Crossref research, YouTube educational lectures, 7-day study schedule generator, Pomodoro Focus Timer, and Gemini AI).
          </p>
        </div>

        {/* Keyboard Shortcuts */}
        <div className="space-y-2">
          <h4 className="font-bold text-white uppercase tracking-wider text-[11px] flex items-center gap-1.5">
            <Command className="w-3.5 h-3.5 text-cyan-400" />
            Keyboard Shortcuts
          </h4>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
            <div className="p-2.5 bg-slate-900 border border-slate-800 rounded-xl flex items-center justify-between">
              <span>Global Search & Command Palette</span>
              <kbd className="px-2 py-0.5 bg-slate-800 border border-slate-700 rounded text-slate-300 font-mono text-[10px]">
                Ctrl + K / ⌘K
              </kbd>
            </div>
            <div className="p-2.5 bg-slate-900 border border-slate-800 rounded-xl flex items-center justify-between">
              <span>Close Active Modal or Dropdown</span>
              <kbd className="px-2 py-0.5 bg-slate-800 border border-slate-700 rounded text-slate-300 font-mono text-[10px]">
                Escape
              </kbd>
            </div>
          </div>
        </div>

        {/* Modules Guide */}
        <div className="space-y-2.5">
          <h4 className="font-bold text-white uppercase tracking-wider text-[11px]">
            Platform Feature Quick Reference
          </h4>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
            <div className="p-3 bg-slate-900/60 border border-slate-800 rounded-xl space-y-1">
              <span className="font-semibold text-slate-100 flex items-center gap-1.5">
                <FolderKanban className="w-3.5 h-3.5 text-indigo-400" /> Projects & Kanban
              </span>
              <p className="text-slate-400 text-[11px]">
                Organize deliverables with 8-tab project spaces: Overview, Tasks, Kanban, Timeline, Team, Files, Comments, and Analytics.
              </p>
            </div>

            <div className="p-3 bg-slate-900/60 border border-slate-800 rounded-xl space-y-1">
              <span className="font-semibold text-slate-100 flex items-center gap-1.5">
                <BookOpen className="w-3.5 h-3.5 text-purple-400" /> Study Hub & Planner
              </span>
              <p className="text-slate-400 text-[11px]">
                Search books via Open Library API, papers via Crossref REST, videos via YouTube API, and generate customized 7-day exam schedules.
              </p>
            </div>

            <div className="p-3 bg-slate-900/60 border border-slate-800 rounded-xl space-y-1">
              <span className="font-semibold text-slate-100 flex items-center gap-1.5">
                <Timer className="w-3.5 h-3.5 text-cyan-400" /> Focus Timer
              </span>
              <p className="text-slate-400 text-[11px]">
                Pomodoro intervals (25/5, 50/10, custom) with animated celebratory notifications and study streak tracking.
              </p>
            </div>

            <div className="p-3 bg-slate-900/60 border border-slate-800 rounded-xl space-y-1">
              <span className="font-semibold text-slate-100 flex items-center gap-1.5">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" /> Privacy & Security Center
              </span>
              <p className="text-slate-400 text-[11px]">
                2FA enforcement, Security Audit logs, Suspicious Login detections, full JSON data export, and 🔒 Private Notes.
              </p>
            </div>
          </div>
        </div>

        <div className="pt-2 flex justify-end">
          <button
            onClick={() => setIsHelpModalOpen(false)}
            className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-semibold rounded-xl text-xs"
          >
            Got It
          </button>
        </div>
      </div>
    </Modal>
  );
};
