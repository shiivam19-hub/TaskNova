import { PrismaClient } from '@prisma/client';
import bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

async function main() {
  console.log('🌱 Starting database seed...');

  // Clean existing tables
  await prisma.commentReaction.deleteMany();
  await prisma.commentReply.deleteMany();
  await prisma.comment.deleteMany();
  await prisma.taskSubtask.deleteMany();
  await prisma.task.deleteMany();
  await prisma.todo.deleteMany();
  await prisma.projectMilestone.deleteMany();
  await prisma.projectPermission.deleteMany();
  await prisma.projectMember.deleteMany();
  await prisma.file.deleteMany();
  await prisma.project.deleteMany();
  await prisma.teamMember.deleteMany();
  await prisma.team.deleteMany();
  await prisma.activity.deleteMany();
  await prisma.notification.deleteMany();
  await prisma.calendarEvent.deleteMany();
  await prisma.savedResource.deleteMany();
  await prisma.studyResource.deleteMany();
  await prisma.studySession.deleteMany();
  await prisma.studyPlan.deleteMany();
  await prisma.studyGoal.deleteMany();
  await prisma.focusSession.deleteMany();
  await prisma.aIMessage.deleteMany();
  await prisma.aIConversation.deleteMany();
  await prisma.securityEvent.deleteMany();
  await prisma.privacySettings.deleteMany();
  await prisma.userSettings.deleteMany();
  await prisma.profile.deleteMany();
  await prisma.user.deleteMany();

  // 1. Create Default User: SHIVAM SINGH
  const passwordHash = await bcrypt.hash('Password@123', 10);
  const user = await prisma.user.create({
    data: {
      email: 'shivam.singh@tasknova.app',
      name: 'Shivam Singh',
      passwordHash,
      role: 'Student & Project Contributor',
      roleType: 'Editor',
      profile: {
        create: {
          bio: 'Undergraduate researcher focusing on distributed computing, high-performance systems, and artificial intelligence.',
          timezone: 'Asia/Kolkata',
          workspace: 'Tasknova University Workspace',
          preferences: JSON.stringify({ theme: 'dark', soundEffects: true, autoSave: true })
        }
      },
      settings: {
        create: {
          appearance: 'dark',
          notifyTaskReminders: true,
          notifyProjectUpdates: true,
          notifyMentions: true,
          notifyMeetings: true,
          notifyStudyReminders: true,
          notifySecurityAlerts: true
        }
      },
      privacySettings: {
        create: {
          profileVisibility: 'Team',
          emailVisibility: 'Team',
          activityStatus: true,
          onlineStatus: true,
          studyProgress: 'Private',
          studyNotes: 'Only Me',
          savedResearch: 'Only Me',
          defaultProjectPrivacy: 'Team',
          twoFactorEnabled: true,
          twoFactorMethod: 'Authenticator App'
        }
      },
      securityEvents: {
        create: [
          {
            title: 'Successful Authentication',
            description: 'Logged in via secure JWT session from Chrome on Windows',
            device: 'Desktop PC (Windows 11)',
            browser: 'Chrome 128',
            location: 'New Delhi, India',
            severity: 'info'
          },
          {
            title: 'Two-Factor Authentication Verified',
            description: 'Time-based one-time password (TOTP) successfully validated',
            device: 'Desktop PC (Windows 11)',
            browser: 'Chrome 128',
            location: 'New Delhi, India',
            severity: 'info'
          }
        ]
      }
    }
  });

  console.log(`👤 Created user: ${user.name} (${user.email})`);

  // 2. Create Team
  const team = await prisma.team.create({
    data: {
      name: 'Tasknova Core Systems Engineering',
      description: 'Cross-functional engineering and research division building core platforms.',
      members: {
        create: [
          {
            name: 'Shivam Singh',
            role: 'Student & Project Contributor',
            department: 'Distributed Systems',
            email: 'shivam.singh@tasknova.app',
            activeProjects: 3,
            tasksCompleted: 24,
            productivity: 96,
            status: 'online',
            roleType: 'Editor',
            avatarColor: 'bg-indigo-600',
            initials: 'SS',
            userId: user.id
          },
          {
            name: 'Marcus Chen',
            role: 'Lead Systems Architect',
            department: 'Infrastructure',
            email: 'marcus.chen@tasknova.app',
            activeProjects: 2,
            tasksCompleted: 42,
            productivity: 94,
            status: 'online',
            roleType: 'Admin',
            avatarColor: 'bg-emerald-600',
            initials: 'MC'
          },
          {
            name: 'Sophia Ramirez',
            role: 'Cryptography Specialist',
            department: 'Security Engineering',
            email: 'sophia.ramirez@tasknova.app',
            activeProjects: 2,
            tasksCompleted: 31,
            productivity: 91,
            status: 'busy',
            roleType: 'Editor',
            avatarColor: 'bg-purple-600',
            initials: 'SR'
          },
          {
            name: 'Alex Rivera',
            role: 'Backend Platform Engineer',
            department: 'Cloud Services',
            email: 'alex.rivera@tasknova.app',
            activeProjects: 1,
            tasksCompleted: 19,
            productivity: 88,
            status: 'away',
            roleType: 'Contributor',
            avatarColor: 'bg-amber-600',
            initials: 'AR'
          }
        ]
      }
    }
  });

  console.log(`👥 Created team: ${team.name}`);

  // 3. Create Projects
  const project1 = await prisma.project.create({
    data: {
      name: 'Distributed Neural Cloud Engine',
      description: 'A fault-tolerant, high-throughput model serving architecture with zero-copy shared memory.',
      category: 'Engineering',
      status: 'In Progress',
      priority: 'High',
      progress: 74,
      deadline: '2026-10-20',
      ownerName: 'Shivam Singh',
      visibility: 'Team',
      members: {
        create: [
          { memberName: 'Shivam Singh', role: 'Project Contributor', department: 'Systems', userId: user.id },
          { memberName: 'Marcus Chen', role: 'Architecture Reviewer', department: 'Infrastructure' },
          { memberName: 'Sophia Ramirez', role: 'Security Auditor', department: 'Security' }
        ]
      },
      milestones: {
        create: [
          { title: 'Cluster Membership & Heartbeat Protocol', dueDate: '2026-09-25', completed: true },
          { title: 'Zero-Copy Shared Memory Interprocess Ring', dueDate: '2026-10-05', completed: false },
          { title: 'Distributed Tracing & Production Benchmarks', dueDate: '2026-10-18', completed: false }
        ]
      },
      permissions: {
        create: [
          { roleType: 'Owner', canView: true, canCreate: true, canEdit: true, canDelete: true },
          { roleType: 'Editor', canView: true, canCreate: true, canEdit: true, canDelete: false },
          { roleType: 'Viewer', canView: true, canCreate: false, canEdit: false, canDelete: false }
        ]
      }
    }
  });

  const project2 = await prisma.project.create({
    data: {
      name: 'BioCompute Genome Variant Pipeline',
      description: 'Deep learning pipeline for single-nucleotide polymorphism annotation and structural variant classification.',
      category: 'Biotechnology',
      status: 'In Progress',
      priority: 'Critical',
      progress: 45,
      deadline: '2026-11-15',
      ownerName: 'Shivam Singh',
      visibility: 'Team',
      members: {
        create: [
          { memberName: 'Shivam Singh', role: 'Lead Researcher', department: 'Bioinformatics', userId: user.id },
          { memberName: 'Alex Rivera', role: 'Data Engineer', department: 'Cloud Services' }
        ]
      }
    }
  });

  const project3 = await prisma.project.create({
    data: {
      name: 'Campus Smart Grid IoT Optimizer',
      description: 'Real-time telemetry and edge predictive load balancing for microgrid electrical storage.',
      category: 'IoT & ML',
      status: 'Completed',
      priority: 'Medium',
      progress: 100,
      deadline: '2026-08-30',
      ownerName: 'Marcus Chen',
      visibility: 'Public',
      members: {
        create: [
          { memberName: 'Marcus Chen', role: 'Project Lead', department: 'Infrastructure' },
          { memberName: 'Shivam Singh', role: 'Contributor', department: 'Systems', userId: user.id }
        ]
      }
    }
  });

  const project4 = await prisma.project.create({
    data: {
      name: 'Quantum Key Distribution Simulator',
      description: 'BB84 protocol simulation over noisy fiber channels with continuous error correction.',
      category: 'Cybersecurity',
      status: 'In Review',
      priority: 'High',
      progress: 68,
      deadline: '2026-12-01',
      ownerName: 'Sophia Ramirez',
      visibility: 'Team',
      members: {
        create: [
          { memberName: 'Sophia Ramirez', role: 'Cryptographer', department: 'Security' },
          { memberName: 'Shivam Singh', role: 'Reviewer', department: 'Systems', userId: user.id }
        ]
      }
    }
  });

  console.log('📁 Created 4 flagship projects');

  // 4. Create Tasks
  await prisma.task.create({
    data: {
      projectId: project1.id,
      title: 'Implement Raft Consensus State Machine',
      description: 'Formalize term election, log compaction, and uncommitted entry truncation in pure TypeScript/Node.',
      priority: 'Critical',
      status: 'IN PROGRESS',
      assigneeName: 'Shivam Singh',
      assigneeId: user.id,
      dueDate: '2026-09-22',
      tags: JSON.stringify(['Consensus', 'Core', 'High-Impact']),
      attachmentIndicator: true,
      subtasks: {
        create: [
          { title: 'Leader election timeout randomized timer', completed: true },
          { title: 'Heartbeat RPC ping payload', completed: true },
          { title: 'Log reconciliation catch-up routine', completed: false }
        ]
      }
    }
  });

  await prisma.task.create({
    data: {
      projectId: project1.id,
      title: 'Benchmark GPU Kernel Memory Allocation',
      description: 'Measure latency across pinned host memory and CUDA device buffers for 4K batch sizes.',
      priority: 'High',
      status: 'TO DO',
      assigneeName: 'Shivam Singh',
      assigneeId: user.id,
      dueDate: '2026-09-28',
      tags: JSON.stringify(['Performance', 'CUDA', 'Benchmarking']),
      attachmentIndicator: false
    }
  });

  await prisma.task.create({
    data: {
      projectId: project1.id,
      title: 'Design Token Bucket Rate Limiter',
      description: 'Protect internal gRPC control plane endpoints from unauthenticated burst traffic.',
      priority: 'Medium',
      status: 'COMPLETED',
      assigneeName: 'Marcus Chen',
      dueDate: '2026-09-10',
      tags: JSON.stringify(['Security', 'Networking'])
    }
  });

  await prisma.task.create({
    data: {
      projectId: project2.id,
      title: 'VCF Callset Ingestion & Variant Normalization',
      description: 'Clean genomic coordinates and align indels with reference genome assembly GRCh38.',
      priority: 'High',
      status: 'IN PROGRESS',
      assigneeName: 'Shivam Singh',
      assigneeId: user.id,
      dueDate: '2026-10-02',
      tags: JSON.stringify(['Genomics', 'Dataform'])
    }
  });

  await prisma.task.create({
    data: {
      projectId: project4.id,
      title: 'Conduct Formal Threat Modeling Audit',
      description: 'Verify side-channel timing resistance and decoy-state probability matrices.',
      priority: 'High',
      status: 'IN REVIEW',
      assigneeName: 'Sophia Ramirez',
      dueDate: '2026-10-12',
      tags: JSON.stringify(['Security', 'Audit'])
    }
  });

  console.log('✅ Created initial project tasks');

  // 5. Create Personal Checklist Todos for SHIVAM SINGH
  await prisma.todo.createMany({
    data: [
      {
        userId: user.id,
        title: 'Review Transformer Attention paper for research seminar',
        completed: false,
        priority: 'High',
        dueDate: 'Today',
        category: 'Study',
        notes: 'Pay special attention to multi-head self-attention projection matrices.'
      },
      {
        userId: user.id,
        title: 'Submit Operating Systems Lab Assignment 4 (Locks & Semaphores)',
        completed: true,
        priority: 'High',
        dueDate: 'Today',
        category: 'Today',
        notes: 'Graded A+ on automated grading test cases.'
      },
      {
        userId: user.id,
        title: 'Prepare presentation deck for Wednesday Team Sprint Review',
        completed: false,
        priority: 'Medium',
        dueDate: 'Upcoming',
        category: 'Project',
        notes: 'Include live demo of Raft consensus cluster failover.'
      },
      {
        userId: user.id,
        title: 'Complete 45-minute Pomodoro study block on Graph Algorithms',
        completed: false,
        priority: 'Medium',
        dueDate: 'Today',
        category: 'Study'
      }
    ]
  });

  console.log('📝 Created personal todos');

  // 6. Comments, Replies & Reactions
  const comment1 = await prisma.comment.create({
    data: {
      projectId: project1.id,
      userId: user.id,
      authorName: 'Shivam Singh',
      authorRole: 'Student & Project Contributor',
      content: 'We finished initial profiling of the Raft leader election state machine. Heartbeat roundtrip latency is under 1.2ms across local loopback.',
      pinned: true,
      replies: {
        create: [
          {
            authorName: 'Marcus Chen',
            authorRole: 'Lead Systems Architect',
            content: 'Exceptional work Shivam. Let us ensure the election timeout has sufficient jitter to avoid split-vote oscillations.'
          }
        ]
      },
      reactions: {
        create: [
          { emoji: '🚀', userName: 'Marcus Chen' },
          { emoji: '🔥', userName: 'Sophia Ramirez' },
          { emoji: '👍', userName: 'Alex Rivera' }
        ]
      }
    }
  });

  // 7. Activity Logs
  await prisma.activity.createMany({
    data: [
      {
        authorName: 'Shivam Singh',
        action: 'completed task',
        target: 'Submit Operating Systems Lab Assignment 4',
        type: 'complete',
        projectId: project1.id
      },
      {
        authorName: 'Marcus Chen',
        action: 'approved review for',
        target: 'Token Bucket Rate Limiter',
        type: 'status_change',
        projectId: project1.id
      },
      {
        authorName: 'Shivam Singh',
        action: 'pinned key discussion in',
        target: 'Distributed Neural Cloud Engine',
        type: 'comment',
        projectId: project1.id
      },
      {
        authorName: 'Sophia Ramirez',
        action: 'updated security policy for',
        target: 'Quantum Key Distribution Simulator',
        type: 'permission',
        projectId: project4.id
      }
    ]
  });

  // 8. Notifications
  await prisma.notification.createMany({
    data: [
      {
        userId: user.id,
        title: 'Upcoming Milestone Deadline',
        message: 'Milestone "Cluster Membership & Heartbeat Protocol" is scheduled for review.',
        type: 'deadline',
        read: false,
        linkTo: `/projects/${project1.id}`
      },
      {
        userId: user.id,
        title: 'New Comment Mention',
        message: 'Marcus Chen replied to your message on Distributed Neural Cloud Engine.',
        type: 'comment',
        read: false,
        linkTo: `/projects/${project1.id}`
      },
      {
        userId: user.id,
        title: 'Security Alert: Two-Factor Enabled',
        message: 'Your account is secured with Authenticator App 2FA verification.',
        type: 'security',
        read: true
      }
    ]
  });

  // 9. Calendar Events
  await prisma.calendarEvent.createMany({
    data: [
      {
        title: 'Core Systems Sprint Standup',
        date: '2026-09-12',
        time: '10:00 AM',
        type: 'meeting',
        location: 'Virtual Room A (Google Meet)',
        reminderMinutes: 15,
        projectId: project1.id
      },
      {
        title: 'Distributed Systems Midterm Exam',
        date: '2026-09-16',
        time: '02:00 PM',
        type: 'exam',
        location: 'Main Auditorium / Hall 3',
        reminderMinutes: 60
      },
      {
        title: 'Research Paper Seminar: Large Models',
        date: '2026-09-18',
        time: '04:30 PM',
        type: 'class',
        location: 'CS Department Seminar Room',
        reminderMinutes: 30
      },
      {
        title: 'Project Milestone 1 Release Demo',
        date: '2026-09-25',
        time: '11:00 AM',
        type: 'milestone',
        location: 'Engineering Hub',
        reminderMinutes: 30,
        projectId: project1.id
      }
    ]
  });

  // 10. Study Goals & Focus Sessions
  await prisma.studyGoal.createMany({
    data: [
      {
        title: 'Master Raft Consensus and Byzantine Fault Tolerance',
        targetDate: '2026-09-20',
        description: 'Read the original Diego Ongaro PhD dissertation and implement simulation.',
        completed: false
      },
      {
        title: 'Score 95%+ in Advanced Operating Systems Examination',
        targetDate: '2026-09-30',
        description: 'Review virtual memory paging, copy-on-write, and file system journaling.',
        completed: false
      },
      {
        title: 'Publish Research Abstract on Genomic Variant Inference',
        targetDate: '2026-10-15',
        description: 'Draft 4-page paper for upcoming student symposium.',
        completed: false
      }
    ]
  });

  await prisma.focusSession.createMany({
    data: [
      {
        userId: user.id,
        durationMins: 50,
        mode: 'focus',
        tasksResolved: 2
      },
      {
        userId: user.id,
        durationMins: 25,
        mode: 'focus',
        tasksResolved: 1
      },
      {
        userId: user.id,
        durationMins: 45,
        mode: 'focus',
        tasksResolved: 2
      }
    ]
  });

  // 11. Study Plans
  await prisma.studyPlan.create({
    data: {
      subject: 'Distributed Systems & Cloud Computing',
      examDate: '2026-09-28',
      availableHoursPerDay: 3.5,
      progress: 60,
      difficulty: 'Hard',
      weakTopics: JSON.stringify(['Two-Phase Commit vs Paxos', 'Vector Clocks', 'Distributed Deadlock Detection']),
      sessions: {
        create: [
          { dayNumber: 1, topic: 'Logical Clocks & Lamport Timestamps', durationHours: 3.0, completed: true, weakArea: false },
          { dayNumber: 2, topic: 'Raft Leader Election & Safety Proofs', durationHours: 3.5, completed: true, weakArea: false },
          { dayNumber: 3, topic: 'Two-Phase Commit & Quorum Consensus', durationHours: 3.5, completed: true, weakArea: true },
          { dayNumber: 4, topic: 'Vector Clocks & Causality Violation Scenarios', durationHours: 4.0, completed: false, weakArea: true },
          { dayNumber: 5, topic: 'Mock Exam & Complex Architecture Case Study', durationHours: 3.0, completed: false, weakArea: false }
        ]
      }
    }
  });

  // 12. Curated Academic Resources
  await prisma.studyResource.createMany({
    data: [
      {
        title: 'Designing Data-Intensive Applications',
        type: 'book',
        authorsOrChannel: 'Martin Kleppmann',
        source: 'O\'Reilly Media',
        identifierOrUrl: 'ISBN 978-1449373320',
        tags: JSON.stringify(['Distributed Systems', 'Storage', 'Reliability']),
        year: '2017'
      },
      {
        title: 'In Search of an Understandable Consensus Algorithm (Extended Raft Paper)',
        type: 'paper',
        authorsOrChannel: 'Diego Ongaro and John Ousterhout (Stanford)',
        source: 'USENIX ATC',
        identifierOrUrl: 'https://raft.github.io/raft.pdf',
        tags: JSON.stringify(['Consensus', 'Fault Tolerance', 'Systems']),
        year: '2014'
      },
      {
        title: 'MIT 6.824: Distributed Systems Spring 2024 Lectures',
        type: 'video',
        authorsOrChannel: 'Robert Morris (MIT OpenCourseWare)',
        source: 'YouTube / MIT OCW',
        identifierOrUrl: 'https://www.youtube.com/playlist?list=PLrw6a1wE39_tb2fErI4-WkMbsvGQk9_UB',
        tags: JSON.stringify(['Lecture', 'MIT', 'Distributed Systems']),
        year: '2024'
      }
    ]
  });

  console.log('📚 Seeded study resources, plans, and focus sessions');
  console.log('🎉 TASKNOVA Database seeding completed successfully!');
}

main()
  .catch((e) => {
    console.error('❌ Database seeding error:', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
