import React, { useState } from 'react';
import {
  Settings as SettingsIcon,
  User,
  Moon,
  Sun,
  Laptop,
  Bell,
  Layers,
  Zap,
  Shield,
  Save,
  CheckCircle2,
  RefreshCw
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { useToast } from '../../context/ToastContext';
import { Avatar } from '../common/Avatar';

export const SettingsView: React.FC = () => {
  const { userProfile, updateUserProfile, resetAllData } = useApp();
  const { showToast } = useToast();

  const [activeTab, setActiveTab] = useState<'Profile' | 'Appearance' | 'Notifications' | 'Workspace' | 'Integrations'>('Profile');

  // Form states
  const [name, setName] = useState(userProfile.name);
  const [role, setRole] = useState(userProfile.role);
  const [email, setEmail] = useState(userProfile.email);
  const [workspaceName, setWorkspaceName] = useState(userProfile.workspace);

  // Notification toggles
  const [notifyTaskReminders, setNotifyTaskReminders] = useState(true);
  const [notifyProjectUpdates, setNotifyProjectUpdates] = useState(true);
  const [notifyMentions, setNotifyMentions] = useState(true);
  const [notifyMeetings, setNotifyMeetings] = useState(true);
  const [notifyStudyReminders, setNotifyStudyReminders] = useState(true);
  const [notifySecurityAlerts, setNotifySecurityAlerts] = useState(true);

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    updateUserProfile({
      name: name.trim(),
      role: role.trim(),
      email: email.trim(),
      avatarInitials: name.split(' ').map(n => n[0]).slice(0, 2).join('').toUpperCase()
    });
    showToast('Profile Updated', 'Your identity preferences have been saved.', 'success');
  };

  const handleSaveWorkspace = (e: React.FormEvent) => {
    e.preventDefault();
    updateUserProfile({ workspace: workspaceName.trim() });
    showToast('Workspace Renamed', `Current workspace set to "${workspaceName}".`, 'success');
  };

  return (
    <div className="space-y-6 animate-fade-in pb-16 max-w-4xl mx-auto">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-white flex items-center gap-2.5">
          <SettingsIcon className="w-6 h-6 text-indigo-400" />
          Settings & Workspace Configuration
        </h1>
        <p className="text-xs text-slate-400 mt-1">
          Configure profile identity, theme preferences, notification channels, and cloud integrations.
        </p>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-2 bg-[#111827] border border-slate-800 p-2 rounded-2xl overflow-x-auto text-xs font-semibold">
        {[
          { id: 'Profile', label: 'User Profile' },
          { id: 'Appearance', label: 'Appearance & Theme' },
          { id: 'Notifications', label: 'Notification Preferences' },
          { id: 'Workspace', label: 'Workspace' },
          { id: 'Integrations', label: 'Integrations & APIs' }
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={`px-4 py-2 rounded-xl transition-all shrink-0 ${
              activeTab === tab.id
                ? 'bg-indigo-600 text-white shadow-md shadow-indigo-950/40'
                : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* 1. PROFILE SETTINGS */}
      {activeTab === 'Profile' && (
        <form onSubmit={handleSaveProfile} className="bg-[#111827] border border-slate-800 rounded-2xl p-6 space-y-6">
          <div className="flex items-center gap-4 pb-6 border-b border-slate-800">
            <Avatar
              name={name}
              initials={name.split(' ').map(n => n[0]).slice(0, 2).join('').toUpperCase()}
              size="xl"
              status={userProfile.status}
              showStatus={true}
            />
            <div className="space-y-1">
              <h3 className="text-base font-bold text-white">{name}</h3>
              <p className="text-xs text-slate-400">{role}</p>
              <span className="inline-block text-[10px] px-2 py-0.5 rounded bg-indigo-950 text-indigo-300 border border-indigo-500/20">
                Neutral Blank Avatar (SaaS Identity Standard)
              </span>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            <div>
              <label className="block text-slate-300 mb-1.5 font-semibold uppercase text-[10px]">
                Full Name
              </label>
              <input
                type="text"
                required
                value={name}
                onChange={e => setName(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-slate-100 focus:outline-none focus:border-indigo-500"
              />
            </div>

            <div>
              <label className="block text-slate-300 mb-1.5 font-semibold uppercase text-[10px]">
                Role & Designation
              </label>
              <input
                type="text"
                required
                value={role}
                onChange={e => setRole(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-slate-100 focus:outline-none focus:border-indigo-500"
              />
            </div>

            <div className="sm:col-span-2">
              <label className="block text-slate-300 mb-1.5 font-semibold uppercase text-[10px]">
                Email Address
              </label>
              <input
                type="email"
                required
                value={email}
                onChange={e => setEmail(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-slate-100 focus:outline-none focus:border-indigo-500"
              />
            </div>
          </div>

          <div className="flex justify-end pt-4 border-t border-slate-800">
            <button
              type="submit"
              className="flex items-center gap-2 px-5 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold rounded-xl shadow-lg shadow-indigo-950/40 transition-all"
            >
              <Save className="w-4 h-4" />
              Save Profile Changes
            </button>
          </div>
        </form>
      )}

      {/* 2. APPEARANCE SETTINGS */}
      {activeTab === 'Appearance' && (
        <div className="bg-[#111827] border border-slate-800 rounded-2xl p-6 space-y-6">
          <div>
            <h3 className="text-sm font-bold text-white">Visual Identity & Theme</h3>
            <p className="text-xs text-slate-400">Select interface tone for day or night productivity</p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div
              onClick={() => {
                updateUserProfile({ appearance: 'dark' });
                showToast('Dark Mode Enabled', 'Deep charcoal SaaS theme active.', 'info');
              }}
              className={`p-4 rounded-2xl border cursor-pointer transition-all ${
                userProfile.appearance === 'dark'
                  ? 'bg-indigo-950/40 border-indigo-500 shadow-md shadow-indigo-950/40'
                  : 'bg-slate-900/60 border-slate-800 hover:border-slate-700'
              }`}
            >
              <Moon className="w-5 h-5 text-indigo-400 mb-2" />
              <h4 className="font-bold text-white text-xs">Dark (Default)</h4>
              <p className="text-[11px] text-slate-400 mt-1">Deep navy & charcoal background with electric accents.</p>
            </div>

            <div
              onClick={() => {
                updateUserProfile({ appearance: 'light' });
                showToast('Light Mode Enabled', 'Clean daytime theme active.', 'info');
              }}
              className={`p-4 rounded-2xl border cursor-pointer transition-all ${
                userProfile.appearance === 'light'
                  ? 'bg-indigo-950/40 border-indigo-500 shadow-md shadow-indigo-950/40'
                  : 'bg-slate-900/60 border-slate-800 hover:border-slate-700'
              }`}
            >
              <Sun className="w-5 h-5 text-amber-400 mb-2" />
              <h4 className="font-bold text-white text-xs">Light Mode</h4>
              <p className="text-[11px] text-slate-400 mt-1">Crisp white surfaces with soft slate contrast.</p>
            </div>

            <div
              onClick={() => {
                updateUserProfile({ appearance: 'system' });
                showToast('System Preference Sync', 'Adapts to OS color scheme.', 'info');
              }}
              className={`p-4 rounded-2xl border cursor-pointer transition-all ${
                userProfile.appearance === 'system'
                  ? 'bg-indigo-950/40 border-indigo-500 shadow-md shadow-indigo-950/40'
                  : 'bg-slate-900/60 border-slate-800 hover:border-slate-700'
              }`}
            >
              <Laptop className="w-5 h-5 text-cyan-400 mb-2" />
              <h4 className="font-bold text-white text-xs">System Preference</h4>
              <p className="text-[11px] text-slate-400 mt-1">Matches system light/dark scheduler automatically.</p>
            </div>
          </div>
        </div>
      )}

      {/* 3. NOTIFICATION PREFERENCES */}
      {activeTab === 'Notifications' && (
        <div className="bg-[#111827] border border-slate-800 rounded-2xl p-6 space-y-6">
          <div>
            <h3 className="text-sm font-bold text-white">Event Notification Channels</h3>
            <p className="text-xs text-slate-400">Configure which triggers dispatch toasts and notification tray items</p>
          </div>

          <div className="space-y-3 text-xs">
            {[
              { label: 'Task Reminders', desc: 'Upcoming deadline alerts 24 hours prior', state: notifyTaskReminders, set: setNotifyTaskReminders },
              { label: 'Project Updates', desc: 'Milestone reached and status changes', state: notifyProjectUpdates, set: setNotifyProjectUpdates },
              { label: 'Team Mentions', desc: 'When colleagues @mention you in comment threads', state: notifyMentions, set: setNotifyMentions },
              { label: 'Meetings & Syncs', desc: 'Microsoft Teams calendar reminders 15m prior', state: notifyMeetings, set: setNotifyMeetings },
              { label: 'Study Reminders', desc: 'Daily study streak maintenance notification', state: notifyStudyReminders, set: setNotifyStudyReminders },
              { label: 'Security Alerts', desc: 'Suspicious login detections & password changes', state: notifySecurityAlerts, set: setNotifySecurityAlerts }
            ].map((item, i) => (
              <div
                key={i}
                className="p-3.5 bg-slate-900/70 border border-slate-800 rounded-xl flex items-center justify-between"
              >
                <div>
                  <span className="font-semibold text-slate-200 block">{item.label}</span>
                  <span className="text-[11px] text-slate-400">{item.desc}</span>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    item.set(!item.state);
                    showToast('Preference Saved', `${item.label} set to ${!item.state ? 'Enabled' : 'Disabled'}.`, 'info');
                  }}
                  className={`px-3 py-1 rounded-lg text-xs font-semibold transition-colors ${
                    item.state
                      ? 'bg-indigo-600 text-white'
                      : 'bg-slate-800 text-slate-400'
                  }`}
                >
                  {item.state ? 'Enabled ✅' : 'Disabled'}
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 4. WORKSPACE SETTINGS */}
      {activeTab === 'Workspace' && (
        <form onSubmit={handleSaveWorkspace} className="bg-[#111827] border border-slate-800 rounded-2xl p-6 space-y-6">
          <div>
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Layers className="w-4 h-4 text-indigo-400" />
              Workspace Identity
            </h3>
            <p className="text-xs text-slate-400">Manage multi-tenant organization naming and permissions</p>
          </div>

          <div className="space-y-3 text-xs">
            <div>
              <label className="block text-slate-300 mb-1.5 font-semibold uppercase text-[10px]">
                Workspace Name
              </label>
              <input
                type="text"
                required
                value={workspaceName}
                onChange={e => setWorkspaceName(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-slate-100 focus:outline-none focus:border-indigo-500"
              />
            </div>
          </div>

          <div className="flex justify-end pt-4 border-t border-slate-800">
            <button
              type="submit"
              className="flex items-center gap-2 px-5 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold rounded-xl shadow-lg shadow-indigo-950/40 transition-all"
            >
              <Save className="w-4 h-4" />
              Save Workspace
            </button>
          </div>
        </form>
      )}

      {/* 5. INTEGRATIONS & APIS */}
      {activeTab === 'Integrations' && (
        <div className="bg-[#111827] border border-slate-800 rounded-2xl p-6 space-y-6">
          <div>
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Zap className="w-4 h-4 text-amber-400" />
              Public & Enterprise API Architecture
            </h3>
            <p className="text-xs text-slate-400">Plug-and-play integrations connected to TASKNOVA</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
            <div className="p-4 bg-slate-900/80 border border-slate-800 rounded-xl space-y-2">
              <div className="flex items-center justify-between">
                <h4 className="font-bold text-white">Microsoft Graph API</h4>
                <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                  Ready
                </span>
              </div>
              <p className="text-[11px] text-slate-400">Microsoft Teams meeting synchronization and channel broadcast.</p>
            </div>

            <div className="p-4 bg-slate-900/80 border border-slate-800 rounded-xl space-y-2">
              <div className="flex items-center justify-between">
                <h4 className="font-bold text-white">Google Gemini API</h4>
                <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                  Ready
                </span>
              </div>
              <p className="text-[11px] text-slate-400">Autonomous task generation, concept explanations, and quiz engine.</p>
            </div>

            <div className="p-4 bg-slate-900/80 border border-slate-800 rounded-xl space-y-2">
              <div className="flex items-center justify-between">
                <h4 className="font-bold text-white">Open Library API</h4>
                <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                  Ready
                </span>
              </div>
              <p className="text-[11px] text-slate-400">Public academic book catalog and ISBN search.</p>
            </div>

            <div className="p-4 bg-slate-900/80 border border-slate-800 rounded-xl space-y-2">
              <div className="flex items-center justify-between">
                <h4 className="font-bold text-white">Crossref REST API</h4>
                <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                  Ready
                </span>
              </div>
              <p className="text-[11px] text-slate-400">Scientific paper citations, DOI resolving, and academic works.</p>
            </div>

            <div className="p-4 bg-slate-900/80 border border-slate-800 rounded-xl space-y-2">
              <div className="flex items-center justify-between">
                <h4 className="font-bold text-white">YouTube Data API v3</h4>
                <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                  Ready
                </span>
              </div>
              <p className="text-[11px] text-slate-400">Curated computer science video lectures and system design primers.</p>
            </div>

            <div className="p-4 bg-slate-900/80 border border-slate-800 rounded-xl space-y-2">
              <div className="flex items-center justify-between">
                <h4 className="font-bold text-white">Open-Meteo Weather API</h4>
                <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                  Ready
                </span>
              </div>
              <p className="text-[11px] text-slate-400">Real-time campus temperature and contextual study alerts.</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
