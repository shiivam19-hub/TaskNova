import { Router, Response } from 'express';
import { PrismaClient } from '@prisma/client';
import { authenticate, AuthRequest } from '../middleware/auth';

const router = Router();
const prisma = new PrismaClient();

// Helper to recalculate project progress
async function recalculateProjectProgress(projectId: string) {
  try {
    const allTasks = await prisma.task.findMany({ where: { projectId } });
    if (allTasks.length === 0) return;
    const completed = allTasks.filter(t => t.status === 'COMPLETED').length;
    const progress = Math.round((completed / allTasks.length) * 100);
    await prisma.project.update({
      where: { id: projectId },
      data: { progress }
    });
  } catch (err) {
    console.error('Failed to update project progress:', err);
  }
}

// List Tasks
router.get('/', authenticate, async (req: AuthRequest, res: Response) => {
  try {
    const { projectId, status, priority, search } = req.query;

    const tasks = await prisma.task.findMany({
      where: {
        ...(projectId && projectId !== 'all' ? { projectId: String(projectId) } : {}),
        ...(status && status !== 'All' ? { status: String(status) } : {}),
        ...(priority && priority !== 'All' ? { priority: String(priority) } : {}),
        ...(search ? {
          OR: [
            { title: { contains: String(search) } },
            { description: { contains: String(search) } }
          ]
        } : {})
      },
      include: {
        project: { select: { id: true, name: true } },
        subtasks: true
      },
      orderBy: { createdAt: 'desc' }
    });

    const formatted = tasks.map(t => ({
      id: t.id,
      projectId: t.projectId,
      projectName: t.project.name,
      title: t.title,
      description: t.description,
      priority: t.priority,
      status: t.status,
      assignee: {
        name: t.assigneeName,
        avatarColor: 'bg-indigo-600'
      },
      dueDate: t.dueDate,
      commentsCount: 2,
      attachmentIndicator: t.attachmentIndicator,
      tags: t.tags ? JSON.parse(t.tags) : [],
      subtasks: t.subtasks,
      createdAt: t.createdAt
    }));

    res.json(formatted);
  } catch (error: any) {
    res.status(500).json({ error: error.message || 'Failed to fetch tasks' });
  }
});

// Create Task
router.post('/', authenticate, async (req: AuthRequest, res: Response) => {
  try {
    const { projectId, title, description, priority, status, assigneeName, dueDate, tags, subtasks } = req.body;

    if (!projectId || !title || !title.trim()) {
      return res.status(400).json({ error: 'Project ID and title are required' });
    }

    const task = await prisma.task.create({
      data: {
        projectId,
        title: title.trim(),
        description,
        priority: priority || 'Medium',
        status: status || 'TO DO',
        assigneeName: assigneeName || req.user!.name,
        dueDate: dueDate || 'Tomorrow',
        tags: tags ? JSON.stringify(tags) : JSON.stringify(['Sprint']),
        attachmentIndicator: false,
        subtasks: {
          create: Array.isArray(subtasks) ? subtasks.map((st: any) => ({
            title: typeof st === 'string' ? st : st.title,
            completed: false
          })) : []
        }
      },
      include: {
        project: { select: { id: true, name: true } },
        subtasks: true
      }
    });

    // Update project progress
    await recalculateProjectProgress(projectId);

    // Record activity
    await prisma.activity.create({
      data: {
        authorName: req.user!.name,
        action: 'created',
        target: `Task "${task.title}"`,
        type: 'create',
        projectId
      }
    });

    // Notify if assigned to someone else
    if (assigneeName && assigneeName !== req.user!.name) {
      await prisma.notification.create({
        data: {
          title: 'New Task Assigned',
          message: `You were assigned to "${task.title}" in ${task.project.name}.`,
          type: 'assignment',
          linkTo: 'tasks'
        }
      });
    }

    res.status(201).json({
      ...task,
      projectName: task.project.name,
      assignee: { name: task.assigneeName, avatarColor: 'bg-indigo-600' },
      tags: task.tags ? JSON.parse(task.tags) : []
    });
  } catch (error: any) {
    res.status(500).json({ error: error.message || 'Failed to create task' });
  }
});

// Update Task
router.put('/:id', authenticate, async (req: AuthRequest, res: Response) => {
  try {
    const { id } = req.params;
    const { title, description, priority, status, assigneeName, dueDate, tags } = req.body;

    const task = await prisma.task.update({
      where: { id },
      data: {
        ...(title && { title }),
        ...(description !== undefined && { description }),
        ...(priority && { priority }),
        ...(status && { status }),
        ...(assigneeName && { assigneeName }),
        ...(dueDate && { dueDate }),
        ...(tags !== undefined && { tags: JSON.stringify(tags) })
      },
      include: {
        project: { select: { id: true, name: true } },
        subtasks: true
      }
    });

    await recalculateProjectProgress(task.projectId);

    res.json({
      ...task,
      projectName: task.project.name,
      assignee: { name: task.assigneeName, avatarColor: 'bg-indigo-600' },
      tags: task.tags ? JSON.parse(task.tags) : []
    });
  } catch (error: any) {
    res.status(500).json({ error: error.message || 'Failed to update task' });
  }
});

// Patch Task (Status Transition for Kanban)
router.patch('/:id/status', authenticate, async (req: AuthRequest, res: Response) => {
  try {
    const { id } = req.params;
    const { status } = req.body;
    const task = await prisma.task.update({
      where: { id },
      data: { status },
      include: { project: { select: { id: true, name: true } } }
    });
    await recalculateProjectProgress(task.projectId);
    res.json(task);
  } catch (error: any) {
    res.status(500).json({ error: error.message || 'Failed to update task status' });
  }
});

router.patch('/:id', authenticate, async (req: AuthRequest, res: Response) => {
  try {
    const { id } = req.params;
    const { status, priority, completed } = req.body;

    const updates: any = {};
    if (status) updates.status = status;
    if (priority) updates.priority = priority;
    if (completed !== undefined) {
      updates.status = completed ? 'COMPLETED' : 'IN PROGRESS';
    }

    const task = await prisma.task.update({
      where: { id },
      data: updates,
      include: {
        project: { select: { id: true, name: true } }
      }
    });

    await recalculateProjectProgress(task.projectId);

    // Record activity
    await prisma.activity.create({
      data: {
        authorName: req.user!.name,
        action: task.status === 'COMPLETED' ? 'completed' : 'moved',
        target: `"${task.title}" to ${task.status}`,
        type: task.status === 'COMPLETED' ? 'complete' : 'status_change',
        projectId: task.projectId
      }
    });

    res.json(task);
  } catch (error: any) {
    res.status(500).json({ error: error.message || 'Failed to update task status' });
  }
});

// Delete Task
router.delete('/:id', authenticate, async (req: AuthRequest, res: Response) => {
  try {
    const { id } = req.params;
    const target = await prisma.task.findUnique({ where: { id } });
    if (!target) return res.status(404).json({ error: 'Task not found' });

    await prisma.task.delete({ where: { id } });
    await recalculateProjectProgress(target.projectId);

    res.json({ message: `Task "${target.title}" removed successfully` });
  } catch (error: any) {
    res.status(500).json({ error: error.message || 'Failed to delete task' });
  }
});

export default router;
