import { Router, Response } from 'express';
import { PrismaClient } from '@prisma/client';
import { authenticate, AuthRequest } from '../middleware/auth';

const router = Router();
const prisma = new PrismaClient();

// Get privacy settings
router.get('/', authenticate, async (req: AuthRequest, res: Response) => {
  try {
    const userId = req.user?.id;
    if (!userId) {
      return res.status(401).json({ error: 'Unauthorized' });
    }

    let settings = await prisma.privacySettings.findUnique({
      where: { userId }
    });

    if (!settings) {
      settings = await prisma.privacySettings.create({
        data: { userId }
      });
    }

    res.json(settings);
  } catch (error) {
    console.error('Fetch privacy settings error:', error);
    res.status(500).json({ error: 'Failed to fetch privacy settings' });
  }
});

// Update privacy settings
router.put('/', authenticate, async (req: AuthRequest, res: Response) => {
  try {
    const userId = req.user?.id;
    if (!userId) {
      return res.status(401).json({ error: 'Unauthorized' });
    }

    const {
      profileVisibility,
      emailVisibility,
      activityStatus,
      onlineStatus,
      studyProgress,
      studyNotes,
      savedResearch,
      defaultProjectPrivacy,
      twoFactorEnabled,
      twoFactorMethod
    } = req.body;

    const updated = await prisma.privacySettings.upsert({
      where: { userId },
      update: {
        ...(profileVisibility !== undefined ? { profileVisibility } : {}),
        ...(emailVisibility !== undefined ? { emailVisibility } : {}),
        ...(activityStatus !== undefined ? { activityStatus: Boolean(activityStatus) } : {}),
        ...(onlineStatus !== undefined ? { onlineStatus: Boolean(onlineStatus) } : {}),
        ...(studyProgress !== undefined ? { studyProgress } : {}),
        ...(studyNotes !== undefined ? { studyNotes } : {}),
        ...(savedResearch !== undefined ? { savedResearch } : {}),
        ...(defaultProjectPrivacy !== undefined ? { defaultProjectPrivacy } : {}),
        ...(twoFactorEnabled !== undefined ? { twoFactorEnabled: Boolean(twoFactorEnabled) } : {}),
        ...(twoFactorMethod !== undefined ? { twoFactorMethod } : {})
      },
      create: {
        userId,
        profileVisibility: profileVisibility || 'Team',
        emailVisibility: emailVisibility || 'Team',
        activityStatus: activityStatus !== undefined ? Boolean(activityStatus) : true,
        onlineStatus: onlineStatus !== undefined ? Boolean(onlineStatus) : true,
        studyProgress: studyProgress || 'Private',
        studyNotes: studyNotes || 'Only Me',
        savedResearch: savedResearch || 'Only Me',
        defaultProjectPrivacy: defaultProjectPrivacy || 'Team',
        twoFactorEnabled: twoFactorEnabled !== undefined ? Boolean(twoFactorEnabled) : true,
        twoFactorMethod: twoFactorMethod || 'Authenticator App'
      }
    });

    res.json(updated);
  } catch (error) {
    console.error('Update privacy settings error:', error);
    res.status(500).json({ error: 'Failed to update privacy settings' });
  }
});

// Get security audit events
router.get('/security-events', authenticate, async (req: AuthRequest, res: Response) => {
  try {
    const userId = req.user?.id;
    if (!userId) {
      return res.status(401).json({ error: 'Unauthorized' });
    }

    const events = await prisma.securityEvent.findMany({
      where: { userId },
      orderBy: { timestamp: 'desc' },
      take: 20
    });

    res.json(events);
  } catch (error) {
    console.error('Fetch security events error:', error);
    res.status(500).json({ error: 'Failed to fetch security events' });
  }
});

// Export all user data (GDPR / Data Portability Compliance)
router.get('/export-data', authenticate, async (req: AuthRequest, res: Response) => {
  try {
    const userId = req.user?.id;
    if (!userId) {
      return res.status(401).json({ error: 'Unauthorized' });
    }

    const user = await prisma.user.findUnique({
      where: { id: userId },
      include: {
        profile: true,
        settings: true,
        privacySettings: true,
        securityEvents: true,
        tasksAssigned: true,
        todos: true,
        comments: true,
        notifications: true,
        focusSessions: true
      }
    });

    if (!user) {
      return res.status(404).json({ error: 'User record not found' });
    }

    // Exclude password hash from export
    const { passwordHash, ...safeUserData } = user;

    res.setHeader('Content-Type', 'application/json');
    res.setHeader('Content-Disposition', `attachment; filename=tasknova-data-export-${Date.now()}.json`);
    res.json({
      application: 'TASKNOVA Platform',
      exportedAt: new Date().toISOString(),
      user: safeUserData
    });
  } catch (error) {
    console.error('Data export error:', error);
    res.status(500).json({ error: 'Failed to export data' });
  }
});

// Delete account
router.delete('/delete-account', authenticate, async (req: AuthRequest, res: Response) => {
  try {
    const userId = req.user?.id;
    if (!userId) {
      return res.status(401).json({ error: 'Unauthorized' });
    }

    await prisma.user.delete({
      where: { id: userId }
    });

    res.json({ message: 'User account and associated records permanently deleted' });
  } catch (error) {
    console.error('Account delete error:', error);
    res.status(500).json({ error: 'Failed to delete account' });
  }
});

export default router;
