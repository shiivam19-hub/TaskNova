import { Router, Response } from 'express';
import { PrismaClient } from '@prisma/client';
import { authenticate, AuthRequest } from '../middleware/auth';

const router = Router();
const prisma = new PrismaClient();

// List comments for a project
router.get('/', authenticate, async (req: AuthRequest, res: Response) => {
  try {
    const { projectId } = req.query;
    if (!projectId) {
      return res.status(400).json({ error: 'projectId is required' });
    }

    const comments = await prisma.comment.findMany({
      where: { projectId: String(projectId) },
      include: {
        replies: {
          orderBy: { createdAt: 'asc' }
        },
        reactions: true
      },
      orderBy: [
        { pinned: 'desc' },
        { createdAt: 'desc' }
      ]
    });

    res.json(comments);
  } catch (error) {
    console.error('Fetch comments error:', error);
    res.status(500).json({ error: 'Failed to fetch comments' });
  }
});

// Add comment
router.post('/', authenticate, async (req: AuthRequest, res: Response) => {
  try {
    const { projectId, content, attachments, pinned } = req.body;
    if (!projectId || !content) {
      return res.status(400).json({ error: 'projectId and content are required' });
    }

    const authorName = req.user?.name || 'Shivam Singh';
    const authorRole = req.user?.role || 'Student & Project Contributor';

    const comment = await prisma.comment.create({
      data: {
        projectId,
        userId: req.user?.id,
        authorName,
        authorRole,
        content,
        pinned: !!pinned,
        attachments: attachments ? JSON.stringify(attachments) : null
      },
      include: {
        replies: true,
        reactions: true
      }
    });

    // Create activity record
    await prisma.activity.create({
      data: {
        authorName,
        action: 'commented on project discussion',
        target: content.substring(0, 40) + (content.length > 40 ? '...' : ''),
        type: 'comment',
        projectId
      }
    });

    res.status(201).json(comment);
  } catch (error) {
    console.error('Create comment error:', error);
    res.status(500).json({ error: 'Failed to post comment' });
  }
});

// Reply to a comment
router.post('/:id/reply', authenticate, async (req: AuthRequest, res: Response) => {
  try {
    const { id } = req.params;
    const { content } = req.body;
    if (!content) {
      return res.status(400).json({ error: 'content is required' });
    }

    const authorName = req.user?.name || 'Shivam Singh';
    const authorRole = req.user?.role || 'Student & Project Contributor';

    const reply = await prisma.commentReply.create({
      data: {
        commentId: id,
        authorName,
        authorRole,
        content
      }
    });

    res.status(201).json(reply);
  } catch (error) {
    console.error('Create comment reply error:', error);
    res.status(500).json({ error: 'Failed to post reply' });
  }
});

// Add or toggle emoji reaction
router.post('/:id/reaction', authenticate, async (req: AuthRequest, res: Response) => {
  try {
    const { id } = req.params;
    const { emoji } = req.body;
    const userName = req.user?.name || 'Shivam Singh';

    if (!emoji) {
      return res.status(400).json({ error: 'emoji is required' });
    }

    const existing = await prisma.commentReaction.findFirst({
      where: {
        commentId: id,
        emoji,
        userName
      }
    });

    if (existing) {
      await prisma.commentReaction.delete({ where: { id: existing.id } });
      return res.json({ action: 'removed', emoji });
    } else {
      const reaction = await prisma.commentReaction.create({
        data: {
          commentId: id,
          emoji,
          userName
        }
      });
      return res.status(201).json({ action: 'added', reaction });
    }
  } catch (error) {
    console.error('Reaction toggle error:', error);
    res.status(500).json({ error: 'Failed to update reaction' });
  }
});

// Delete comment
router.delete('/:id', authenticate, async (req: AuthRequest, res: Response) => {
  try {
    const { id } = req.params;
    await prisma.comment.delete({ where: { id } });
    res.json({ message: 'Comment deleted successfully' });
  } catch (error) {
    console.error('Delete comment error:', error);
    res.status(500).json({ error: 'Failed to delete comment' });
  }
});

export default router;
