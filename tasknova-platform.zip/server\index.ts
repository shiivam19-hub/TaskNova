import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import path from 'path';
import fs from 'fs';

// Load environment variables
dotenv.config();

// Import Routes
import authRouter from './routes/auth';
import projectsRouter from './routes/projects';
import tasksRouter from './routes/tasks';
import todosRouter from './routes/todos';
import teamRouter from './routes/team';
import commentsRouter from './routes/comments';
import activityRouter from './routes/activity';
import notificationsRouter from './routes/notifications';
import calendarRouter from './routes/calendar';
import filesRouter from './routes/files';
import studyRouter from './routes/study';
import aiRouter from './routes/ai';
import privacyRouter from './routes/privacy';

import { errorHandler } from './middleware/errorHandler';

const app = express();
const PORT = process.env.PORT || 5000;

// Ensure uploads folder exists
const uploadsDir = path.join(process.cwd(), 'uploads');
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
}

// Middleware
app.use(cors({
  origin: '*',
  credentials: true
}));
app.use(express.json({ limit: '15mb' }));
app.use(express.urlencoded({ extended: true, limit: '15mb' }));

// Serve static uploaded files
app.use('/uploads', express.static(uploadsDir));

// Health check
app.get('/api/health', (req, res) => {
  res.json({
    status: 'healthy',
    application: 'TASKNOVA Production Backend',
    version: '1.0.0',
    timestamp: new Date().toISOString()
  });
});

// Mount Routes
app.use('/api/auth', authRouter);
app.use('/api/projects', projectsRouter);
app.use('/api/tasks', tasksRouter);
app.use('/api/todos', todosRouter);
app.use('/api/team', teamRouter);
app.use('/api/comments', commentsRouter);
app.use('/api/activity', activityRouter);
app.use('/api/notifications', notificationsRouter);
app.use('/api/calendar', calendarRouter);
app.use('/api/files', filesRouter);
app.use('/api/study', studyRouter);
app.use('/api/ai', aiRouter);
app.use('/api/privacy', privacyRouter);

// Global Error Handler
app.use(errorHandler);

// Start server if not in test mode
if (process.env.NODE_ENV !== 'test') {
  app.listen(PORT, () => {
    console.log(`=========================================`);
    console.log(`🚀 TASKNOVA Server running on port ${PORT}`);
    console.log(`📡 API Health: http://localhost:${PORT}/api/health`);
    console.log(`📁 Uploads Directory: ${uploadsDir}`);
    console.log(`=========================================`);
  });
}

export default app;
