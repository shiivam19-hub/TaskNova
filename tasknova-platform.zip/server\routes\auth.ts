import { Router, Response } from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { PrismaClient } from '@prisma/client';
import { authenticate, AuthRequest } from '../middleware/auth';
import { JWT_SECRET } from '../config';

const router = Router();
const prisma = new PrismaClient();

// Sign Up
router.post('/signup', async (req, res) => {
  try {
    const { email, password, name, role } = req.body;

    if (!email || !password || !name) {
      return res.status(400).json({ error: 'Email, password, and name are required' });
    }

    const existingUser = await prisma.user.findUnique({ where: { email: email.toLowerCase() } });
    if (existingUser) {
      return res.status(409).json({ error: 'An account with this email address already exists' });
    }

    const passwordHash = await bcrypt.hash(password, 10);
    const user = await prisma.user.create({
      data: {
        email: email.toLowerCase(),
        passwordHash,
        name,
        role: role || 'Student & Project Contributor',
        roleType: 'Editor',
        profile: {
          create: {
            bio: 'Active contributor on TASKNOVA platform',
            timezone: 'Asia/Kolkata',
            workspace: 'Tasknova University Workspace'
          }
        },
        settings: {
          create: {
            appearance: 'dark'
          }
        },
        privacySettings: {
          create: {
            profileVisibility: 'Team',
            emailVisibility: 'Team'
          }
        }
      },
      include: {
        profile: true,
        settings: true,
        privacySettings: true
      }
    });

    const token = jwt.sign(
      { userId: user.id, email: user.email, roleType: user.roleType },
      JWT_SECRET,
      { expiresIn: '7d' }
    );

    // Record security log
    await prisma.securityEvent.create({
      data: {
        userId: user.id,
        title: 'User account created',
        description: `New account registered for ${user.name} (${user.email})`,
        severity: 'info'
      }
    });

    res.status(201).json({
      message: 'User registered successfully',
      token,
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        role: user.role,
        roleType: user.roleType,
        profile: user.profile,
        settings: user.settings,
        privacySettings: user.privacySettings
      }
    });
  } catch (error: any) {
    res.status(500).json({ error: error.message || 'Failed to register account' });
  }
});

// Login
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({ error: 'Email and password are required' });
    }

    const user = await prisma.user.findUnique({
      where: { email: email.toLowerCase() },
      include: {
        profile: true,
        settings: true,
        privacySettings: true
      }
    });

    if (!user) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    const isMatch = await bcrypt.compare(password, user.passwordHash);
    if (!isMatch) {
      await prisma.securityEvent.create({
        data: {
          userId: user.id,
          title: 'Failed login attempt',
          description: `Failed login attempt for ${user.email}`,
          severity: 'warning'
        }
      });
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    const token = jwt.sign(
      { userId: user.id, email: user.email, roleType: user.roleType },
      JWT_SECRET,
      { expiresIn: '7d' }
    );

    // Record login security event
    await prisma.securityEvent.create({
      data: {
        userId: user.id,
        title: 'Successful login',
        description: `User authenticated via password credential.`,
        device: req.headers['user-agent']?.slice(0, 40) || 'Web Browser',
        severity: 'info'
      }
    });

    res.json({
      message: 'Login successful',
      token,
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        role: user.role,
        roleType: user.roleType,
        profile: user.profile,
        settings: user.settings,
        privacySettings: user.privacySettings
      }
    });
  } catch (error: any) {
    res.status(500).json({ error: error.message || 'Login failed' });
  }
});

// Get Current Logged In User
router.get('/me', authenticate, async (req: AuthRequest, res: Response) => {
  try {
    const user = await prisma.user.findUnique({
      where: { id: req.user!.id },
      include: {
        profile: true,
        settings: true,
        privacySettings: true
      }
    });

    if (!user) {
      return res.status(404).json({ error: 'User profile not found' });
    }

    res.json({
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        role: user.role,
        roleType: user.roleType,
        profile: user.profile,
        settings: user.settings,
        privacySettings: user.privacySettings
      }
    });
  } catch (error: any) {
    res.status(500).json({ error: error.message || 'Failed to fetch user session' });
  }
});

// Update Profile
router.patch('/profile', authenticate, async (req: AuthRequest, res: Response) => {
  try {
    const { name, role, bio, timezone, workspace, avatarUrl } = req.body;

    const updatedUser = await prisma.user.update({
      where: { id: req.user!.id },
      data: {
        ...(name && { name }),
        ...(role && { role }),
        profile: {
          upsert: {
            create: { bio, timezone, workspace, avatarUrl },
            update: {
              ...(bio !== undefined && { bio }),
              ...(timezone && { timezone }),
              ...(workspace && { workspace }),
              ...(avatarUrl !== undefined && { avatarUrl })
            }
          }
        }
      },
      include: {
        profile: true,
        settings: true,
        privacySettings: true
      }
    });

    res.json({
      message: 'Profile updated successfully',
      user: {
        id: updatedUser.id,
        name: updatedUser.name,
        email: updatedUser.email,
        role: updatedUser.role,
        roleType: updatedUser.roleType,
        profile: updatedUser.profile,
        settings: updatedUser.settings,
        privacySettings: updatedUser.privacySettings
      }
    });
  } catch (error: any) {
    res.status(500).json({ error: error.message || 'Failed to update profile' });
  }
});

// Change Password
router.post('/change-password', authenticate, async (req: AuthRequest, res: Response) => {
  try {
    const { currentPassword, newPassword } = req.body;

    if (!currentPassword || !newPassword) {
      return res.status(400).json({ error: 'Current password and new password are required' });
    }

    const user = await prisma.user.findUnique({ where: { id: req.user!.id } });
    if (!user) return res.status(404).json({ error: 'User not found' });

    const isMatch = await bcrypt.compare(currentPassword, user.passwordHash);
    if (!isMatch) {
      return res.status(401).json({ error: 'Current password does not match' });
    }

    const newHash = await bcrypt.hash(newPassword, 10);
    await prisma.user.update({
      where: { id: user.id },
      data: { passwordHash: newHash }
    });

    await prisma.securityEvent.create({
      data: {
        userId: user.id,
        title: 'Password changed successfully',
        description: 'User rotated credentials via settings security panel.',
        severity: 'info'
      }
    });

    res.json({ message: 'Password updated successfully' });
  } catch (error: any) {
    res.status(500).json({ error: error.message || 'Failed to change password' });
  }
});

// Logout
router.post('/logout', authenticate, async (req: AuthRequest, res: Response) => {
  try {
    await prisma.securityEvent.create({
      data: {
        userId: req.user!.id,
        title: 'User logged out',
        description: 'Session invalidated gracefully.',
        severity: 'info'
      }
    });
    res.json({ message: 'Logged out successfully' });
  } catch (error: any) {
    res.status(500).json({ error: error.message || 'Logout failed' });
  }
});

export default router;
