import { Router, Response } from 'express';
import { PrismaClient } from '@prisma/client';
import { authenticate, AuthRequest } from '../middleware/auth';

const router = Router();
const prisma = new PrismaClient();

// List Todos
router.get('/', authenticate, async (req: AuthRequest, res: Response) => {
  try {
    const { category, search } = req.query;

    const todos = await prisma.todo.findMany({
      where: {
        ...(category && category !== 'All' ? { category: String(category) } : {}),
        ...(search ? { title: { contains: String(search) } } : {})
      },
      orderBy: { createdAt: 'desc' }
    });

    const formatted = todos.map(t => ({
      id: t.id,
      title: t.title,
      completed: t.completed,
      priority: t.priority,
      dueDate: t.dueDate,
      category: t.category,
      tags: t.tags ? JSON.parse(t.tags) : [t.category],
      notes: t.notes
    }));

    res.json(formatted);
  } catch (error: any) {
    res.status(500).json({ error: error.message || 'Failed to fetch todos' });
  }
});

// Create Todo
router.post('/', authenticate, async (req: AuthRequest, res: Response) => {
  try {
    const { title, priority, dueDate, category, tags, notes } = req.body;

    if (!title || !title.trim()) {
      return res.status(400).json({ error: 'Todo title is required' });
    }

    const todo = await prisma.todo.create({
      data: {
        userId: req.user?.id,
        title: title.trim(),
        completed: false,
        priority: priority || 'Medium',
        dueDate: dueDate || (category === 'Today' ? 'Today' : 'Upcoming'),
        category: category || 'Today',
        tags: tags ? JSON.stringify(tags) : JSON.stringify([category || 'Today']),
        notes
      }
    });

    res.status(201).json({
      ...todo,
      tags: todo.tags ? JSON.parse(todo.tags) : []
    });
  } catch (error: any) {
    res.status(500).json({ error: error.message || 'Failed to create todo' });
  }
});

// Update Todo
router.put('/:id', authenticate, async (req: AuthRequest, res: Response) => {
  try {
    const { id } = req.params;
    const { title, completed, priority, dueDate, category, notes } = req.body;

    const todo = await prisma.todo.update({
      where: { id },
      data: {
        ...(title && { title }),
        ...(completed !== undefined && { completed: !!completed }),
        ...(priority && { priority }),
        ...(dueDate && { dueDate }),
        ...(category && { category }),
        ...(notes !== undefined && { notes })
      }
    });

    res.json(todo);
  } catch (error: any) {
    res.status(500).json({ error: error.message || 'Failed to update todo' });
  }
});

// Toggle Complete
router.patch('/:id/toggle', authenticate, async (req: AuthRequest, res: Response) => {
  try {
    const { id } = req.params;
    const current = await prisma.todo.findUnique({ where: { id } });
    if (!current) return res.status(404).json({ error: 'Todo not found' });

    const todo = await prisma.todo.update({
      where: { id },
      data: { completed: !current.completed }
    });

    res.json(todo);
  } catch (error: any) {
    res.status(500).json({ error: error.message || 'Failed to toggle complete status' });
  }
});

router.patch('/:id/complete', authenticate, async (req: AuthRequest, res: Response) => {
  try {
    const { id } = req.params;
    const current = await prisma.todo.findUnique({ where: { id } });
    if (!current) return res.status(404).json({ error: 'Todo not found' });

    const todo = await prisma.todo.update({
      where: { id },
      data: { completed: !current.completed }
    });

    res.json(todo);
  } catch (error: any) {
    res.status(500).json({ error: error.message || 'Failed to toggle complete status' });
  }
});

// Delete Todo
router.delete('/:id', authenticate, async (req: AuthRequest, res: Response) => {
  try {
    const { id } = req.params;
    await prisma.todo.delete({ where: { id } });
    res.json({ message: 'Todo deleted successfully' });
  } catch (error: any) {
    res.status(500).json({ error: error.message || 'Failed to delete todo' });
  }
});

export default router;
