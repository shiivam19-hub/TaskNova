import React, { useState } from 'react';
import {
  Video,
  Users,
  Calendar,
  Clock,
  ExternalLink,
  MessageSquare,
  CheckCircle2,
  Settings,
  Link,
  Zap,
  Globe
} from 'lucide-react';
import { initialTeamsMeetings } from '../../data/mockData';
import { useToast } from '../../context/ToastContext';

export const TeamsIntegrationView: React.FC = () => {
  const { showToast } = useToast();
  const [isConnected, setIsConnected] = useState(true);
  const [meetings, setMeetings] = useState(initialTeamsMeetings);

  const channels = [
    { name: '#general', team: 'TASKNOVA Development', membersCount: 14, lastActive: '5m ago' },
    { name: '#website-redesign-sprint', team: 'Design & Frontend', membersCount: 6, lastActive: '12m ago' },
    { name: '#banking-security-audit', team: 'Infra & Core', membersCount: 8, lastActive: '1h ago' },
    { name: '#ai-analytics-research', team: 'Data Science', membersCount: 5, lastActive: '3h ago' }
  ];

  const handleJoinMeeting = (meetingTitle: string, joinUrl: string) => {
    showToast('Launching Microsoft Teams', `Connecting to "${meetingTitle}" room...`, 'info');
    window.open(joinUrl, '_blank');
  };

  const handleToggleConnection = () => {
    setIsConnected(prev => !prev);
    if (!isConnected) {
      showToast('Microsoft Graph Connected', 'Synced calendars and channels via Azure AD tenant.', 'success');
    } else {
      showToast('Disconnected', 'Microsoft Teams integration token cleared.', 'warning');
    }
  };

  return (
    <div className="space-y-6 animate-fade-in pb-16">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-white flex items-center gap-2.5">
            <Video className="w-6 h-6 text-indigo-400" />
            Microsoft Teams Collaboration Hub
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Enterprise video sync, channel conversations, and Microsoft Graph API bridging.
          </p>
        </div>

        <button
          onClick={handleToggleConnection}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-semibold transition-all ${
            isConnected
              ? 'bg-emerald-950/60 border border-emerald-500/40 text-emerald-300 hover:bg-emerald-900/60'
              : 'bg-indigo-600 hover:bg-indigo-500 text-white'
          }`}
        >
          <Zap className="w-4 h-4" />
          {isConnected ? 'Connected to Microsoft Graph ✅' : 'Connect Microsoft Teams'}
        </button>
      </div>

      {/* Header Banner */}
      <div className="p-6 bg-gradient-to-r from-indigo-950/40 via-[#111827] to-slate-900 border border-slate-800 rounded-2xl space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-600/20 border border-indigo-500/30 text-indigo-400 flex items-center justify-center font-bold text-base">
              T
            </div>
            <div>
              <h3 className="text-sm font-bold text-white">Azure Active Directory / Microsoft 365 Tenant</h3>
              <p className="text-xs text-slate-400">tasknova-campus.onmicrosoft.com • Status: {isConnected ? 'Active & Synchronized' : 'Inactive'}</p>
            </div>
          </div>

          <span className="text-[11px] px-2.5 py-1 rounded-full bg-slate-800 border border-slate-700 text-slate-300 self-start md:self-auto">
            API: Microsoft Graph v1.0
          </span>
        </div>

        <p className="text-xs text-slate-300 leading-relaxed">
          TASKNOVA connects seamlessly with Microsoft Graph REST endpoints (<code className="font-mono text-indigo-300">/me/onlineMeetings</code>, <code className="font-mono text-indigo-300">/teams/&#123;id&#125;/channels</code>).
          Start instant sync sessions or launch scheduled project reviews directly from your dashboard.
        </p>
      </div>

      {/* Upcoming Teams Meetings (Section 14) */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-base font-bold text-white flex items-center gap-2">
            <Clock className="w-4 h-4 text-cyan-400" />
            Upcoming Scheduled Team Meetings
          </h2>
          <span className="text-xs text-slate-400">All times in local time</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {meetings.map(m => (
            <div
              key={m.id}
              className="bg-[#111827] border border-slate-800 hover:border-indigo-500/40 rounded-2xl p-5 shadow-sm space-y-4 flex flex-col justify-between interactive-card"
            >
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-indigo-500/15 text-indigo-300 border border-indigo-500/30">
                    {m.teamName}
                  </span>
                  <span className="text-xs font-semibold text-cyan-400">
                    {m.date} • {m.time}
                  </span>
                </div>

                <h3 className="text-sm font-bold text-white pt-1">
                  "{m.title}"
                </h3>
                <p className="text-xs text-slate-400">
                  Channel: <strong className="text-slate-300">#{m.channel}</strong>
                </p>
                <p className="text-[11px] text-slate-500">
                  Organized by {m.organizer} • {m.attendeesCount} attendees
                </p>
              </div>

              <div className="pt-3 border-t border-slate-800/80">
                <button
                  onClick={() => handleJoinMeeting(m.title, m.joinUrl)}
                  className="w-full py-2.5 bg-gradient-to-r from-indigo-600 to-indigo-500 hover:from-indigo-500 hover:to-indigo-400 text-white text-xs font-bold rounded-xl shadow-md shadow-indigo-950/40 transition-all flex items-center justify-center gap-2"
                >
                  <Video className="w-4 h-4" />
                  [Join Meeting]
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Team Channels & Recent Conversations */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Linked Channels */}
        <div className="bg-[#111827] border border-slate-800 rounded-2xl p-5 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <MessageSquare className="w-4 h-4 text-indigo-400" />
              Connected Microsoft Teams Channels
            </h3>
            <span className="text-xs text-slate-400">{channels.length} synchronized</span>
          </div>

          <div className="space-y-2.5 text-xs">
            {channels.map((ch, idx) => (
              <div
                key={idx}
                className="p-3 bg-slate-900/60 border border-slate-800 rounded-xl flex items-center justify-between hover:border-slate-700 transition-colors"
              >
                <div>
                  <span className="font-semibold text-slate-200 block">{ch.name}</span>
                  <span className="text-[11px] text-slate-400">{ch.team}</span>
                </div>
                <div className="text-right">
                  <span className="text-[10px] text-slate-400 block">{ch.membersCount} members</span>
                  <span className="text-[10px] text-emerald-400">{ch.lastActive}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Integration Credentials Blueprint */}
        <div className="bg-[#111827] border border-slate-800 rounded-2xl p-5 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Settings className="w-4 h-4 text-cyan-400" />
              Azure App Registration Settings
            </h3>
            <span className="text-[10px] text-indigo-400 font-mono">OAuth 2.0</span>
          </div>

          <div className="space-y-2 text-xs">
            <div>
              <span className="text-slate-400 text-[11px] block">Client Application ID</span>
              <input
                type="text"
                readOnly
                value="9f42b3a1-7c91-4c12-88ef-23d18294e019"
                className="w-full mt-1 px-3 py-1.5 bg-slate-900 border border-slate-700 rounded-lg text-slate-300 font-mono text-[11px]"
              />
            </div>
            <div>
              <span className="text-slate-400 text-[11px] block">Directory (Tenant) ID</span>
              <input
                type="text"
                readOnly
                value="tasknova-university-tenant-production"
                className="w-full mt-1 px-3 py-1.5 bg-slate-900 border border-slate-700 rounded-lg text-slate-300 font-mono text-[11px]"
              />
            </div>
            <div>
              <span className="text-slate-400 text-[11px] block">Required Permissions Granted</span>
              <div className="mt-1 flex flex-wrap gap-1.5 text-[10px]">
                {['OnlineMeetings.ReadWrite', 'Calendars.Read', 'User.Read', 'ChannelMessage.Send'].map(p => (
                  <span key={p} className="px-2 py-0.5 rounded bg-slate-800 border border-slate-700 text-slate-300 font-mono">
                    {p}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
