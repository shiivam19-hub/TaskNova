import React, { useState } from 'react';
import {
  ArrowLeft,
  Calendar,
  CheckCircle2,
  Clock,
  Plus,
  Lock,
  FileText,
  MessageSquare,
  BarChart2,
  Columns,
  ListFilter,
  Users,
  Paperclip,
  Share2,
  AlertCircle,
  MoreHorizontal,
  ChevronRight,
  Shield,
  Download,
  Eye,
  Trash2
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { Avatar } from '../common/Avatar';
import { Task, TaskStatus, Priority } from '../../types';
import { useToast } from '../../context/ToastContext';

export const ProjectDetailsView: React.FC = () => {
  const {
    projects,
    selectedProjectId,
    projectDetailsSubTab,
    setProjectDetailsSubTab,
    setActiveTab,
    tasks,
    moveTaskStatus,
    toggleTaskCompletion,
    deleteTask,
    comments,
    addComment,
    addReply,
    addReaction,
    files,
    uploadFile,
    deleteFile,
    teamMembers,
    openQuickCreate,
    updateProject
  } = useApp();

  const { showToast } = useToast();

  const project = projects.find(p => p.id === selectedProjectId) || projects[0];

  const [privateNoteInput, setPrivateNoteInput] = useState('');
  const [newCommentInput, setNewCommentInput] = useState('');
  const [replyInputId, setReplyInputId] = useState<string | null>(null);
  const [replyText, setReplyText] = useState('');

  if (!project) {
    return (
      <div className="p-8 text-center text-slate-400">
        <p>Project not found.</p>
        <button onClick={() => setActiveTab('projects')} className="mt-2 text-indigo-400">
          Back to projects
        </button>
      </div>
    );
  }

  const projectTasks = tasks.filter(t => t.projectId === project.id);
  const projectComments = comments.filter(c => c.projectId === project.id);
  const projectFiles = files.filter(f => f.projectId === project.id);
  const projectMembers = teamMembers.filter(m => project.team.includes(m.name));

  const tabs = ['Overview', 'Tasks', 'Kanban', 'Timeline', 'Team', 'Files', 'Comments', 'Analytics'];

  const kanbanColumns: TaskStatus[] = ['TO DO', 'IN PROGRESS', 'IN REVIEW', 'COMPLETED'];

  const handleAddPrivateNote = (e: React.FormEvent) => {
    e.preventDefault();
    if (!privateNoteInput.trim()) return;
    const currentNotes = project.privateNotes || [];
    updateProject(project.id, {
      privateNotes: [privateNoteInput.trim(), ...currentNotes]
    });
    setPrivateNoteInput('');
    showToast('Private Note Saved', 'Only you can see this note.', 'info');
  };

  const handlePostComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCommentInput.trim()) return;
    addComment(project.id, newCommentInput.trim());
    setNewCommentInput('');
    showToast('Comment Posted', 'Your message has been shared with the project team.', 'success');
  };

  const handlePostReply = (commentId: string) => {
    if (!replyText.trim()) return;
    addReply(commentId, replyText.trim());
    setReplyText('');
    setReplyInputId(null);
    showToast('Reply Added', 'Thread updated.', 'success');
  };

  const getPriorityBadge = (priority: Priority) => {
    switch (priority) {
      case 'Urgent':
        return 'bg-rose-500/15 text-rose-400 border border-rose-500/30';
      case 'High':
        return 'bg-amber-500/15 text-amber-400 border border-amber-500/30';
      case 'Medium':
        return 'bg-cyan-500/15 text-cyan-400 border border-cyan-500/30';
      default:
        return 'bg-slate-800 text-slate-400 border border-slate-700';
    }
  };

  return (
    <div className="space-y-6 animate-fade-in pb-16">
      {/* Back Navigation Bar */}
      <div className="flex items-center justify-between">
        <button
          onClick={() => setActiveTab('projects')}
          className="flex items-center gap-2 text-xs font-medium text-slate-400 hover:text-white transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to all projects
        </button>

        <div className="flex items-center gap-2">
          <button
            onClick={() => {
              navigator.clipboard.writeText(window.location.href);
              showToast('Link Copied', 'Project link copied to clipboard.', 'info');
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-900 border border-slate-800 hover:border-slate-700 text-xs text-slate-300 rounded-xl transition-colors"
          >
            <Share2 className="w-3.5 h-3.5" />
            Share
          </button>
          <button
            onClick={() => openQuickCreate('task')}
            className="flex items-center gap-1.5 px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold rounded-xl transition-all shadow-md shadow-indigo-950/40"
          >
            <Plus className="w-3.5 h-3.5" />
            Add Task
          </button>
        </div>
      </div>

      {/* Project Header Banner */}
      <div className="bg-[#111827] border border-slate-800/90 rounded-2xl p-6 shadow-sm">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="space-y-2 max-w-2xl">
            <div className="flex flex-wrap items-center gap-2.5">
              <span className="text-xs font-semibold px-2.5 py-0.5 rounded-full bg-indigo-500/15 text-indigo-400 border border-indigo-500/30">
                {project.status}
              </span>
              <span className="text-xs font-medium px-2 py-0.5 rounded-full bg-slate-800 text-slate-300">
                {project.category}
              </span>
              <span className="text-xs text-slate-400">
                Priority: <strong className="text-slate-200">{project.priority}</strong>
              </span>
            </div>

            <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-white">
              {project.name}
            </h1>
            <p className="text-xs sm:text-sm text-slate-400 leading-relaxed">
              {project.description}
            </p>
          </div>

          {/* Quick Metrics Stack */}
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 lg:border-l lg:border-slate-800 lg:pl-6 shrink-0">
            <div>
              <span className="text-[11px] text-slate-400 block">Progress</span>
              <span className="text-2xl font-bold text-white">{project.progress}%</span>
              <div className="w-24 h-1.5 rounded-full bg-slate-800 mt-1 overflow-hidden">
                <div
                  className="h-full bg-indigo-500 rounded-full"
                  style={{ width: `${project.progress}%` }}
                />
              </div>
            </div>

            <div>
              <span className="text-[11px] text-slate-400 block">Target Deadline</span>
              <span className="text-sm font-semibold text-slate-200 flex items-center gap-1 mt-1">
                <Calendar className="w-3.5 h-3.5 text-indigo-400" />
                {project.deadline}
              </span>
              <span className="text-[10px] text-slate-500 block mt-0.5">Sprint 14</span>
            </div>

            <div>
              <span className="text-[11px] text-slate-400 block">Project Owner</span>
              <div className="flex items-center gap-2 mt-1">
                <Avatar name={project.owner} size="xs" color="bg-indigo-600" />
                <span className="text-xs font-medium text-slate-200 truncate">{project.owner}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Sub-Navigation Tabs */}
        <div className="mt-6 pt-4 border-t border-slate-800/80 flex items-center gap-2 overflow-x-auto">
          {tabs.map(tab => (
            <button
              key={tab}
              onClick={() => setProjectDetailsSubTab(tab)}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold tracking-wide transition-all shrink-0 ${
                projectDetailsSubTab === tab
                  ? 'bg-indigo-600 text-white shadow-md shadow-indigo-950/40'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
              }`}
            >
              {tab}
            </button>
          ))}
        </div>
      </div>

      {/* SUB-TAB CONTENT */}

      {/* 1. OVERVIEW TAB */}
      {projectDetailsSubTab === 'Overview' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left 2 Cols: Progress, Milestones, Team */}
          <div className="lg:col-span-2 space-y-6">
            {/* Milestones Card */}
            <div className="bg-[#111827] border border-slate-800 rounded-2xl p-5 space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-indigo-400" />
                  Key Milestones
                </h3>
                <span className="text-xs text-slate-400">
                  {project.milestones.filter(m => m.completed).length} of {project.milestones.length} Reached
                </span>
              </div>

              <div className="space-y-2.5">
                {project.milestones.map((m, i) => (
                  <div
                    key={m.id}
                    className="p-3 bg-slate-900/80 border border-slate-800 rounded-xl flex items-center justify-between gap-3 text-xs"
                  >
                    <div className="flex items-center gap-3">
                      <span className={`w-5 h-5 rounded-full flex items-center justify-center font-bold text-[10px] ${
                        m.completed ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' : 'bg-slate-800 text-slate-400'
                      }`}>
                        {i + 1}
                      </span>
                      <span className={`font-medium ${m.completed ? 'line-through text-slate-400' : 'text-slate-200'}`}>
                        {m.title}
                      </span>
                    </div>
                    <span className="text-[11px] text-slate-400 shrink-0">Due {m.dueDate}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Team Allocation Card */}
            <div className="bg-[#111827] border border-slate-800 rounded-2xl p-5 space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <Users className="w-4 h-4 text-cyan-400" />
                  Assigned Team ({projectMembers.length})
                </h3>
                <button
                  onClick={() => setActiveTab('team')}
                  className="text-xs text-indigo-400 hover:text-indigo-300 font-medium"
                >
                  Manage Roles
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {projectMembers.map(member => (
                  <div
                    key={member.id}
                    className="p-3 bg-slate-900/60 border border-slate-800 rounded-xl flex items-center gap-3 text-xs"
                  >
                    <Avatar name={member.name} initials={member.initials} size="sm" status={member.status} showStatus />
                    <div className="min-w-0 flex-1">
                      <div className="font-semibold text-slate-200 truncate">{member.name}</div>
                      <div className="text-[11px] text-slate-400 truncate">{member.role}</div>
                    </div>
                    <span className="text-[10px] font-medium px-2 py-0.5 rounded bg-slate-800 text-slate-300">
                      {member.roleType}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Right Col: 🔒 Private Notes & Activity */}
          <div className="space-y-6">
            {/* Private Notes Widget (Section 27) */}
            <div className="bg-[#111827] border border-indigo-500/30 rounded-2xl p-5 space-y-3 relative overflow-hidden">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-indigo-300 flex items-center gap-1.5">
                  <Lock className="w-3.5 h-3.5 text-indigo-400" />
                  🔒 Private Note
                </span>
                <span className="text-[10px] px-2 py-0.5 rounded bg-indigo-950 text-indigo-300 border border-indigo-500/20">
                  Encrypted • Only Me
                </span>
              </div>
              <p className="text-[11px] text-slate-400">
                Private notes never appear in team views or exports unless explicitly shared.
              </p>

              <form onSubmit={handleAddPrivateNote} className="space-y-2">
                <textarea
                  rows={2}
                  value={privateNoteInput}
                  onChange={e => setPrivateNoteInput(e.target.value)}
                  placeholder="e.g. Ask professor about API architecture or check sandbox keys..."
                  className="w-full px-3 py-2 bg-slate-900/90 border border-slate-700/80 rounded-xl text-xs text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-indigo-500"
                />
                <button
                  type="submit"
                  className="w-full py-1.5 bg-indigo-600/30 hover:bg-indigo-600 text-indigo-200 hover:text-white border border-indigo-500/40 rounded-xl text-xs font-medium transition-colors"
                >
                  Save Private Note
                </button>
              </form>

              {project.privateNotes && project.privateNotes.length > 0 && (
                <div className="mt-3 space-y-2">
                  {project.privateNotes.map((note, idx) => (
                    <div
                      key={idx}
                      className="p-2.5 bg-slate-900/70 border border-slate-800 rounded-xl text-xs text-slate-300 italic"
                    >
                      "{note}"
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Quick Files Summary */}
            <div className="bg-[#111827] border border-slate-800 rounded-2xl p-5 space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
                  <FileText className="w-3.5 h-3.5 text-amber-400" />
                  Project Files ({projectFiles.length})
                </h4>
                <button
                  onClick={() => setProjectDetailsSubTab('Files')}
                  className="text-xs text-indigo-400 hover:text-indigo-300 font-medium"
                >
                  View All
                </button>
              </div>

              <div className="space-y-2 text-xs">
                {projectFiles.slice(0, 3).map(f => (
                  <div
                    key={f.id}
                    className="p-2.5 bg-slate-900/60 border border-slate-800 rounded-xl flex items-center justify-between"
                  >
                    <span className="font-medium text-slate-200 truncate">{f.name}</span>
                    <span className="text-[10px] text-slate-400">{f.size}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 2. TASKS TAB */}
      {projectDetailsSubTab === 'Tasks' && (
        <div className="bg-[#111827] border border-slate-800 rounded-2xl p-5 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-white">Tasks List</h3>
              <p className="text-xs text-slate-400">All deliverables and user stories for {project.name}</p>
            </div>
            <button
              onClick={() => openQuickCreate('task')}
              className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold rounded-xl"
            >
              + Add Task
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="border-b border-slate-800 text-slate-400 uppercase text-[10px] tracking-wider">
                <tr>
                  <th className="py-2.5 px-3">Status</th>
                  <th className="py-2.5 px-3">Title</th>
                  <th className="py-2.5 px-3">Priority</th>
                  <th className="py-2.5 px-3">Assignee</th>
                  <th className="py-2.5 px-3">Due Date</th>
                  <th className="py-2.5 px-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {projectTasks.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="py-8 text-center text-slate-400">
                      No tasks yet. Create your first task.
                    </td>
                  </tr>
                ) : (
                  projectTasks.map(task => (
                    <tr key={task.id} className="hover:bg-slate-900/40 transition-colors">
                      <td className="py-3 px-3">
                        <button
                          onClick={() => toggleTaskCompletion(task.id)}
                          className={`w-5 h-5 rounded-md border flex items-center justify-center transition-colors ${
                            task.status === 'COMPLETED'
                              ? 'bg-emerald-500 border-emerald-500 text-white'
                              : 'border-slate-700 hover:border-indigo-500'
                          }`}
                        >
                          {task.status === 'COMPLETED' && <CheckCircle2 className="w-3.5 h-3.5" />}
                        </button>
                      </td>
                      <td className="py-3 px-3">
                        <span className={`font-medium ${
                          task.status === 'COMPLETED' ? 'line-through text-slate-500' : 'text-slate-200'
                        }`}>
                          {task.title}
                        </span>
                        {task.description && (
                          <p className="text-[11px] text-slate-400 line-clamp-1">{task.description}</p>
                        )}
                      </td>
                      <td className="py-3 px-3">
                        <span className={`text-[10px] font-semibold px-2 py-0.5 rounded ${getPriorityBadge(task.priority)}`}>
                          {task.priority}
                        </span>
                      </td>
                      <td className="py-3 px-3">
                        <div className="flex items-center gap-1.5">
                          <Avatar name={task.assignee.name} size="xs" color={task.assignee.avatarColor} />
                          <span className="text-slate-300">{task.assignee.name}</span>
                        </div>
                      </td>
                      <td className="py-3 px-3 text-slate-400">{task.dueDate}</td>
                      <td className="py-3 px-3 text-right">
                        <button
                          onClick={() => deleteTask(task.id)}
                          className="p-1 text-slate-500 hover:text-rose-400 rounded-lg hover:bg-slate-800 transition-colors"
                          title="Delete task"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 3. KANBAN BOARD TAB */}
      {projectDetailsSubTab === 'Kanban' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-xs text-slate-400">
              Drag & move tasks across columns or use the column shift controls.
            </span>
            <button
              onClick={() => openQuickCreate('task')}
              className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold rounded-xl flex items-center gap-1.5"
            >
              <Plus className="w-3.5 h-3.5" /> New Task
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4">
            {kanbanColumns.map(column => {
              const colTasks = projectTasks.filter(t => t.status === column);
              return (
                <div
                  key={column}
                  className="bg-[#111827] border border-slate-800 rounded-2xl p-4 flex flex-col min-h-[500px]"
                >
                  <div className="flex items-center justify-between pb-3 mb-3 border-b border-slate-800">
                    <div className="flex items-center gap-2">
                      <span className={`w-2 h-2 rounded-full ${
                        column === 'TO DO' ? 'bg-slate-400' :
                        column === 'IN PROGRESS' ? 'bg-indigo-400' :
                        column === 'IN REVIEW' ? 'bg-amber-400' : 'bg-emerald-400'
                      }`} />
                      <h4 className="text-xs font-bold text-white uppercase tracking-wider">
                        {column}
                      </h4>
                    </div>
                    <span className="text-xs px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 font-mono">
                      {colTasks.length}
                    </span>
                  </div>

                  {/* Tasks in column */}
                  <div className="flex-1 space-y-3 overflow-y-auto">
                    {colTasks.length === 0 ? (
                      <div className="h-32 border-2 border-dashed border-slate-800/80 rounded-xl flex items-center justify-center text-xs text-slate-500">
                        No tasks in this lane
                      </div>
                    ) : (
                      colTasks.map(task => (
                        <div
                          key={task.id}
                          className="p-3.5 bg-slate-900/90 border border-slate-800/90 hover:border-indigo-500/40 rounded-xl shadow-xs space-y-2.5 transition-all group"
                        >
                          <div className="flex items-start justify-between gap-2">
                            <span className={`text-[10px] font-semibold px-2 py-0.5 rounded ${getPriorityBadge(task.priority)}`}>
                              {task.priority}
                            </span>
                            <span className="text-[10px] text-slate-400">{task.dueDate}</span>
                          </div>

                          <h5 className="text-xs font-semibold text-slate-100 group-hover:text-indigo-400 transition-colors">
                            {task.title}
                          </h5>

                          {task.description && (
                            <p className="text-[11px] text-slate-400 line-clamp-2 leading-relaxed">
                              {task.description}
                            </p>
                          )}

                          <div className="pt-2 border-t border-slate-800/60 flex items-center justify-between text-xs text-slate-400">
                            <div className="flex items-center gap-1.5">
                              <Avatar name={task.assignee.name} size="xs" color={task.assignee.avatarColor} />
                              <span className="text-[11px] truncate">{task.assignee.name.split(' ')[0]}</span>
                            </div>

                            <div className="flex items-center gap-2">
                              {task.attachmentIndicator && (
                                <Paperclip className="w-3.5 h-3.5 text-slate-400" />
                              )}
                              <span className="flex items-center gap-0.5 text-[11px]">
                                <MessageSquare className="w-3 h-3 text-slate-500" />
                                {task.commentsCount}
                              </span>
                            </div>
                          </div>

                          {/* Quick Column Shift Selector */}
                          <div className="pt-1 flex items-center justify-end gap-1">
                            <span className="text-[10px] text-slate-500 mr-1">Move:</span>
                            {kanbanColumns.filter(c => c !== column).map(targetCol => (
                              <button
                                key={targetCol}
                                onClick={() => moveTaskStatus(task.id, targetCol)}
                                className="px-1.5 py-0.5 text-[9px] font-medium bg-slate-800 hover:bg-indigo-600 hover:text-white rounded text-slate-400 transition-colors"
                                title={`Move to ${targetCol}`}
                              >
                                {targetCol === 'TO DO' ? 'Todo' : targetCol === 'IN PROGRESS' ? 'Prog' : targetCol === 'IN REVIEW' ? 'Rev' : 'Done'}
                              </button>
                            ))}
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* 4. TIMELINE TAB */}
      {projectDetailsSubTab === 'Timeline' && (
        <div className="bg-[#111827] border border-slate-800 rounded-2xl p-6 space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-white">Project Schedule & Gantt Roadmap</h3>
              <p className="text-xs text-slate-400">Chronological milestone phases and sprint delivery timelines</p>
            </div>
            <span className="text-xs font-mono text-indigo-400 bg-indigo-950/60 px-3 py-1 rounded-full border border-indigo-500/30">
              Sprint 14 • Q3/Q4
            </span>
          </div>

          <div className="space-y-4">
            {project.milestones.map((m, idx) => (
              <div key={m.id} className="space-y-1.5">
                <div className="flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2">
                    <span className={`w-2.5 h-2.5 rounded-full ${m.completed ? 'bg-emerald-400' : 'bg-indigo-500'}`} />
                    <span className="font-semibold text-slate-200">{m.title}</span>
                  </div>
                  <span className="text-slate-400">{m.dueDate}</span>
                </div>
                {/* Timeline Bar */}
                <div className="w-full h-4 bg-slate-900 rounded-lg p-0.5 border border-slate-800 overflow-hidden relative">
                  <div
                    className={`h-full rounded-md transition-all ${
                      m.completed ? 'bg-emerald-500/80' : 'bg-gradient-to-r from-indigo-500 to-cyan-500'
                    }`}
                    style={{
                      width: `${Math.max(25, 100 - idx * 22)}%`,
                      marginLeft: `${idx * 15}%`
                    }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 5. TEAM TAB */}
      {projectDetailsSubTab === 'Team' && (
        <div className="bg-[#111827] border border-slate-800 rounded-2xl p-6 space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-white">Project Contributors & Permissions</h3>
              <p className="text-xs text-slate-400">Team members assigned with operational roles and security tiers</p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {projectMembers.map(member => (
              <div
                key={member.id}
                className="p-4 bg-slate-900/80 border border-slate-800 rounded-xl space-y-3"
              >
                <div className="flex items-center gap-3">
                  <Avatar name={member.name} initials={member.initials} size="md" status={member.status} showStatus />
                  <div className="min-w-0 flex-1">
                    <h5 className="font-semibold text-slate-100 truncate text-xs">{member.name}</h5>
                    <p className="text-[11px] text-slate-400 truncate">{member.role}</p>
                    <span className="text-[10px] text-indigo-400 font-mono">{member.department}</span>
                  </div>
                </div>

                <div className="pt-2 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
                  <span>Productivity: <strong className="text-slate-200">{member.productivity}%</strong></span>
                  <span className="text-[10px] px-2 py-0.5 rounded bg-slate-800 text-slate-300 font-medium">
                    {member.roleType}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 6. FILES TAB */}
      {projectDetailsSubTab === 'Files' && (
        <div className="bg-[#111827] border border-slate-800 rounded-2xl p-6 space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-white">Project Assets & Documents</h3>
              <p className="text-xs text-slate-400">Specifications, Figma layouts, design artifacts, and report documentation</p>
            </div>
            <button
              onClick={() => openQuickCreate('file')}
              className="px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold rounded-xl flex items-center gap-1.5"
            >
              <Plus className="w-3.5 h-3.5" /> Upload Asset
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {projectFiles.length === 0 ? (
              <div className="col-span-full py-8 text-center text-slate-500 text-xs">
                No files uploaded to this project yet.
              </div>
            ) : (
              projectFiles.map(file => (
                <div
                  key={file.id}
                  className="p-4 bg-slate-900/80 border border-slate-800 rounded-xl space-y-3 flex flex-col justify-between group hover:border-slate-700 transition-colors"
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-center gap-2.5">
                      <div className="w-8 h-8 rounded-lg bg-indigo-950/60 border border-indigo-500/20 text-indigo-400 flex items-center justify-center font-bold text-xs">
                        {file.type.toUpperCase()}
                      </div>
                      <div className="min-w-0">
                        <h5 className="font-semibold text-slate-200 text-xs truncate max-w-[140px]">
                          {file.name}
                        </h5>
                        <span className="text-[10px] text-slate-400">{file.size}</span>
                      </div>
                    </div>
                  </div>

                  <div className="pt-2 border-t border-slate-800 flex items-center justify-between text-[11px] text-slate-400">
                    <span>Uploaded by {file.uploadedBy.split(' ')[0]}</span>
                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => showToast('File Previewing', `Opening preview for ${file.name}`, 'info')}
                        className="p-1 text-slate-400 hover:text-white rounded hover:bg-slate-800 transition-colors"
                        title="Preview"
                      >
                        <Eye className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => showToast('Download Started', `Downloading ${file.name}`, 'success')}
                        className="p-1 text-slate-400 hover:text-white rounded hover:bg-slate-800 transition-colors"
                        title="Download"
                      >
                        <Download className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => deleteFile(file.id)}
                        className="p-1 text-slate-500 hover:text-rose-400 rounded hover:bg-slate-800 transition-colors"
                        title="Delete"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* 7. COMMENTS TAB */}
      {projectDetailsSubTab === 'Comments' && (
        <div className="bg-[#111827] border border-slate-800 rounded-2xl p-6 space-y-6">
          <div>
            <h3 className="text-sm font-bold text-white">Project Discussion Thread</h3>
            <p className="text-xs text-slate-400">Collaborative comments, feedback exchanges, and design critiques</p>
          </div>

          {/* New Comment Input */}
          <form onSubmit={handlePostComment} className="space-y-2">
            <textarea
              rows={3}
              value={newCommentInput}
              onChange={e => setNewCommentInput(e.target.value)}
              placeholder="Share an update or mention @team member..."
              className="w-full px-3.5 py-2.5 bg-slate-900 border border-slate-700/80 rounded-xl text-xs text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-indigo-500"
            />
            <div className="flex items-center justify-between">
              <span className="text-[11px] text-slate-500">Supports @mentions, code snippets, and emoji reactions</span>
              <button
                type="submit"
                className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold rounded-xl"
              >
                Post Comment
              </button>
            </div>
          </form>

          {/* Comment Threads */}
          <div className="space-y-4 pt-4 border-t border-slate-800">
            {projectComments.length === 0 ? (
              <div className="py-6 text-center text-slate-500 text-xs">
                No comments yet. Start the conversation!
              </div>
            ) : (
              projectComments.map(comment => (
                <div key={comment.id} className="p-4 bg-slate-900/60 border border-slate-800 rounded-xl space-y-3 text-xs">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2.5">
                      <Avatar name={comment.authorName} size="sm" color="bg-indigo-600" />
                      <div>
                        <span className="font-semibold text-slate-200">{comment.authorName}</span>
                        <span className="text-[10px] text-slate-400 ml-2">{comment.authorRole}</span>
                      </div>
                    </div>
                    <span className="text-[10px] text-slate-400">{comment.timestamp}</span>
                  </div>

                  <p className="text-slate-300 leading-relaxed pl-10">{comment.content}</p>

                  {/* Emoji Reactions & Reply Trigger */}
                  <div className="pl-10 flex flex-wrap items-center gap-2">
                    {comment.reactions.map(r => (
                      <button
                        key={r.emoji}
                        onClick={() => addReaction(comment.id, r.emoji)}
                        className="px-2 py-0.5 rounded-lg bg-slate-800/80 border border-slate-700 text-slate-300 hover:border-indigo-500 text-[11px] flex items-center gap-1"
                      >
                        <span>{r.emoji}</span>
                        <span>{r.count}</span>
                      </button>
                    ))}
                    {['👍', '🚀', '❤️', '🔥'].map(emoji => (
                      <button
                        key={emoji}
                        onClick={() => addReaction(comment.id, emoji)}
                        className="p-1 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-white text-xs"
                      >
                        {emoji}
                      </button>
                    ))}

                    <button
                      onClick={() => setReplyInputId(replyInputId === comment.id ? null : comment.id)}
                      className="text-[11px] text-indigo-400 hover:text-indigo-300 font-medium ml-2"
                    >
                      Reply
                    </button>
                  </div>

                  {/* Replies List */}
                  {comment.replies.length > 0 && (
                    <div className="pl-10 space-y-2 mt-2 pt-2 border-t border-slate-800/60">
                      {comment.replies.map(reply => (
                        <div key={reply.id} className="p-2.5 bg-slate-900 rounded-lg space-y-1">
                          <div className="flex items-center justify-between text-[11px]">
                            <span className="font-semibold text-slate-200">{reply.authorName}</span>
                            <span className="text-[10px] text-slate-400">{reply.timestamp}</span>
                          </div>
                          <p className="text-slate-300 text-xs">{reply.content}</p>
                        </div>
                      ))}
                    </div>
                  )}

                  {/* Inline Reply Input */}
                  {replyInputId === comment.id && (
                    <div className="pl-10 pt-2 flex items-center gap-2">
                      <input
                        type="text"
                        value={replyText}
                        onChange={e => setReplyText(e.target.value)}
                        placeholder="Write a reply..."
                        className="flex-1 px-3 py-1.5 bg-slate-900 border border-slate-700 rounded-lg text-xs text-slate-100 focus:outline-none focus:border-indigo-500"
                      />
                      <button
                        onClick={() => handlePostReply(comment.id)}
                        className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-medium"
                      >
                        Send
                      </button>
                    </div>
                  )}
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* 8. ANALYTICS TAB */}
      {projectDetailsSubTab === 'Analytics' && (
        <div className="bg-[#111827] border border-slate-800 rounded-2xl p-6 space-y-6">
          <div>
            <h3 className="text-sm font-bold text-white">Project Velocity & Task Analytics</h3>
            <p className="text-xs text-slate-400">Burndown status, resolution time, and workload distribution</p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="p-4 bg-slate-900/80 border border-slate-800 rounded-xl">
              <span className="text-xs text-slate-400 uppercase tracking-wider block">Completion Rate</span>
              <span className="text-2xl font-bold text-white mt-1 block">{project.progress}%</span>
              <p className="text-[11px] text-emerald-400 mt-0.5">On schedule for target release</p>
            </div>
            <div className="p-4 bg-slate-900/80 border border-slate-800 rounded-xl">
              <span className="text-xs text-slate-400 uppercase tracking-wider block">Active Tasks</span>
              <span className="text-2xl font-bold text-white mt-1 block">{projectTasks.length}</span>
              <p className="text-[11px] text-slate-400 mt-0.5">{projectTasks.filter(t => t.status === 'COMPLETED').length} resolved</p>
            </div>
            <div className="p-4 bg-slate-900/80 border border-slate-800 rounded-xl">
              <span className="text-xs text-slate-400 uppercase tracking-wider block">Average Resolution</span>
              <span className="text-2xl font-bold text-white mt-1 block">2.4 Days</span>
              <p className="text-[11px] text-slate-400 mt-0.5">Across sprint deliverables</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
