import React, { useState } from 'react';
import {
  ShieldCheck,
  Lock,
  Eye,
  Key,
  Smartphone,
  AlertTriangle,
  Download,
  Trash2,
  CheckCircle2,
  Clock,
  Shield,
  FileSpreadsheet,
  AlertCircle
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { useToast } from '../../context/ToastContext';
import { Modal } from '../common/Modal';

export const PrivacySecurityView: React.FC = () => {
  const {
    userProfile,
    updatePrivacySetting,
    toggle2FA,
    auditLogs,
    setIsSuspiciousLoginOpen,
    resetAllData,
    projects,
    tasks,
    activities
  } = useApp();

  const { showToast } = useToast();

  const [activeSubTab, setActiveSubTab] = useState<'Privacy' | 'Security' | 'AuditLog' | 'DataControl'>('Privacy');
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [deleteConfirmText, setDeleteConfirmText] = useState('');

  // Export Data Handlers (Section 26)
  const handleExportData = (type: 'all' | 'projects' | 'tasks' | 'activity') => {
    let exportData: any = {};
    if (type === 'all') exportData = { userProfile, projects, tasks, activities, auditLogs };
    else if (type === 'projects') exportData = projects;
    else if (type === 'tasks') exportData = tasks;
    else if (type === 'activity') exportData = activities;

    const jsonStr = JSON.stringify(exportData, null, 2);
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `tasknova-${type}-export-${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
    showToast('Export Complete', `Downloaded ${type} dataset as JSON.`, 'success');
  };

  const handleDeleteAccount = () => {
    if (deleteConfirmText !== 'DELETE') {
      showToast('Confirmation Required', 'Please type DELETE to confirm.', 'error');
      return;
    }
    resetAllData();
    setIsDeleteModalOpen(false);
    showToast('Account Reset', 'All user data has been scrubbed from local memory.', 'info');
  };

  return (
    <div className="space-y-6 animate-fade-in pb-16 max-w-5xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-white flex items-center gap-2.5">
            <ShieldCheck className="w-6 h-6 text-emerald-400" />
            Privacy & Security Center
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Data sovereignty controls, 2FA enforcement, audit logs, and granular visibility preferences.
          </p>
        </div>

        {/* Suspicious login test button */}
        <button
          onClick={() => setIsSuspiciousLoginOpen(true)}
          className="flex items-center gap-2 px-3.5 py-2 bg-amber-950/40 hover:bg-amber-950/80 border border-amber-500/40 text-amber-300 rounded-xl text-xs font-semibold transition-colors"
        >
          <AlertTriangle className="w-3.5 h-3.5" />
          Test Suspicious Login Alert
        </button>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-2 bg-[#111827] border border-slate-800 p-2 rounded-2xl overflow-x-auto text-xs font-semibold">
        {[
          { id: 'Privacy', label: 'Visibility & Privacy' },
          { id: 'Security', label: '2FA & Access Security' },
          { id: 'AuditLog', label: 'Security Audit Log' },
          { id: 'DataControl', label: 'Data Sovereignty & Export' }
        ].map(t => (
          <button
            key={t.id}
            onClick={() => setActiveSubTab(t.id as any)}
            className={`px-4 py-2 rounded-xl transition-all shrink-0 ${
              activeSubTab === t.id
                ? 'bg-indigo-600 text-white shadow-md shadow-indigo-950/40'
                : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {/* 1. VISIBILITY & PRIVACY (Section 21) */}
      {activeSubTab === 'Privacy' && (
        <div className="space-y-6">
          {/* Profile Privacy Card */}
          <div className="bg-[#111827] border border-slate-800 rounded-2xl p-6 space-y-4">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Eye className="w-4 h-4 text-indigo-400" />
              Profile Privacy
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
              <div className="p-3.5 bg-slate-900/70 border border-slate-800 rounded-xl flex items-center justify-between">
                <div>
                  <span className="font-semibold text-slate-200 block">Profile Visibility</span>
                  <span className="text-[11px] text-slate-400">Controls who can discover your profile card</span>
                </div>
                <select
                  value={userProfile.privacy.profileVisibility}
                  onChange={e => updatePrivacySetting('profileVisibility', e.target.value)}
                  className="px-2.5 py-1.5 bg-slate-800 border border-slate-700 rounded-lg text-slate-200 text-xs focus:outline-none"
                >
                  <option value="Private">Private</option>
                  <option value="Team">Team</option>
                  <option value="Public">Public</option>
                </select>
              </div>

              <div className="p-3.5 bg-slate-900/70 border border-slate-800 rounded-xl flex items-center justify-between">
                <div>
                  <span className="font-semibold text-slate-200 block">Email Visibility</span>
                  <span className="text-[11px] text-slate-400">Display email to teammates and collaborators</span>
                </div>
                <select
                  value={userProfile.privacy.emailVisibility}
                  onChange={e => updatePrivacySetting('emailVisibility', e.target.value)}
                  className="px-2.5 py-1.5 bg-slate-800 border border-slate-700 rounded-lg text-slate-200 text-xs focus:outline-none"
                >
                  <option value="Only Me">Only Me</option>
                  <option value="Team">Team</option>
                  <option value="Public">Public</option>
                </select>
              </div>

              <div className="p-3.5 bg-slate-900/70 border border-slate-800 rounded-xl flex items-center justify-between">
                <div>
                  <span className="font-semibold text-slate-200 block">Activity Status</span>
                  <span className="text-[11px] text-slate-400">Broadcast recent completions to team feed</span>
                </div>
                <button
                  onClick={() => updatePrivacySetting('activityStatus', !userProfile.privacy.activityStatus)}
                  className={`px-3 py-1 rounded-lg text-xs font-semibold transition-colors ${
                    userProfile.privacy.activityStatus
                      ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                      : 'bg-slate-800 text-slate-400'
                  }`}
                >
                  {userProfile.privacy.activityStatus ? 'ON ✅' : 'OFF'}
                </button>
              </div>

              <div className="p-3.5 bg-slate-900/70 border border-slate-800 rounded-xl flex items-center justify-between">
                <div>
                  <span className="font-semibold text-slate-200 block">Online Status</span>
                  <span className="text-[11px] text-slate-400">Display live presence dot (Green/Away)</span>
                </div>
                <button
                  onClick={() => updatePrivacySetting('onlineStatus', !userProfile.privacy.onlineStatus)}
                  className={`px-3 py-1 rounded-lg text-xs font-semibold transition-colors ${
                    userProfile.privacy.onlineStatus
                      ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                      : 'bg-slate-800 text-slate-400'
                  }`}
                >
                  {userProfile.privacy.onlineStatus ? 'ON ✅' : 'OFF'}
                </button>
              </div>
            </div>
          </div>

          {/* Study Privacy Card */}
          <div className="bg-[#111827] border border-slate-800 rounded-2xl p-6 space-y-4">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Lock className="w-4 h-4 text-purple-400" />
              Academic & Study Privacy
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
              <div className="p-3.5 bg-slate-900/70 border border-slate-800 rounded-xl space-y-2">
                <span className="font-semibold text-slate-200 block">Study Progress</span>
                <p className="text-[11px] text-slate-400">Share exam schedules and weak topics with mentors</p>
                <select
                  value={userProfile.privacy.studyProgress}
                  onChange={e => updatePrivacySetting('studyProgress', e.target.value)}
                  className="w-full px-2.5 py-1.5 bg-slate-800 border border-slate-700 rounded-lg text-slate-200 text-xs focus:outline-none"
                >
                  <option value="Private">Private (Only Me)</option>
                  <option value="Team">Team Mentors</option>
                </select>
              </div>

              <div className="p-3.5 bg-slate-900/70 border border-slate-800 rounded-xl space-y-2">
                <span className="font-semibold text-slate-200 block">Study Notes</span>
                <p className="text-[11px] text-slate-400">Visibility defaults for newly saved markdown notes</p>
                <select
                  value={userProfile.privacy.studyNotes}
                  onChange={e => updatePrivacySetting('studyNotes', e.target.value)}
                  className="w-full px-2.5 py-1.5 bg-slate-800 border border-slate-700 rounded-lg text-slate-200 text-xs focus:outline-none"
                >
                  <option value="Only Me">Only Me 🔒</option>
                  <option value="Shared">Shared</option>
                </select>
              </div>

              <div className="p-3.5 bg-slate-900/70 border border-slate-800 rounded-xl space-y-2">
                <span className="font-semibold text-slate-200 block">Saved Research</span>
                <p className="text-[11px] text-slate-400">Crossref and Open Library bookmarks access</p>
                <select
                  value={userProfile.privacy.savedResearch}
                  onChange={e => updatePrivacySetting('savedResearch', e.target.value)}
                  className="w-full px-2.5 py-1.5 bg-slate-800 border border-slate-700 rounded-lg text-slate-200 text-xs focus:outline-none"
                >
                  <option value="Only Me">Only Me 🔒</option>
                  <option value="Shared">Shared</option>
                </select>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 2. TWO-FACTOR AUTHENTICATION & ACCESS (Section 23) */}
      {activeSubTab === 'Security' && (
        <div className="bg-[#111827] border border-slate-800 rounded-2xl p-6 space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-800">
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 rounded-xl bg-emerald-500/15 text-emerald-400 flex items-center justify-center font-bold text-sm shrink-0">
                <ShieldCheck className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-white">Two-Factor Authentication (2FA)</h3>
                <p className="text-xs text-emerald-400 font-semibold mt-0.5">
                  "Your account is protected."
                </p>
                <p className="text-[11px] text-slate-400 mt-1">
                  Requires TOTP time-based code or Email OTP during sign-in attempts.
                </p>
              </div>
            </div>

            <button
              onClick={toggle2FA}
              className={`px-4 py-2 rounded-xl text-xs font-semibold transition-all ${
                userProfile.security.twoFactorEnabled
                  ? 'bg-rose-950/60 border border-rose-500/40 text-rose-300 hover:bg-rose-900/60'
                  : 'bg-emerald-600 hover:bg-emerald-500 text-white'
              }`}
            >
              {userProfile.security.twoFactorEnabled ? 'Disable 2FA' : 'Enable 2FA'}
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            <div className="p-4 bg-slate-900/70 border border-slate-800 rounded-xl space-y-2">
              <span className="font-semibold text-slate-200 block flex items-center gap-1.5">
                <Smartphone className="w-4 h-4 text-indigo-400" /> Authenticator App (TOTP)
              </span>
              <p className="text-[11px] text-slate-400">
                Google Authenticator, Microsoft Authenticator, or 1Password.
              </p>
              <span className="inline-block text-[10px] px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                Configured & Active
              </span>
            </div>

            <div className="p-4 bg-slate-900/70 border border-slate-800 rounded-xl space-y-2">
              <span className="font-semibold text-slate-200 block flex items-center gap-1.5">
                <Key className="w-4 h-4 text-cyan-400" /> Email One-Time Password (OTP)
              </span>
              <p className="text-[11px] text-slate-400">
                Send 6-digit security codes to {userProfile.email} as fallback.
              </p>
              <span className="inline-block text-[10px] px-2 py-0.5 rounded bg-slate-800 text-slate-400">
                Secondary Method
              </span>
            </div>
          </div>

          {/* Auth Provider Architecture */}
          <div className="p-4 bg-slate-900/40 border border-slate-800 rounded-xl space-y-2 text-xs">
            <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">
              Identity Provider Architecture
            </span>
            <p className="text-slate-300 leading-relaxed">
              Engineered with pluggable identity providers: <strong>Firebase Auth</strong> / <strong>Supabase Auth</strong> / <strong>Auth0</strong> with JWT verification and session rotation safeguards.
            </p>
          </div>
        </div>
      )}

      {/* 3. SECURITY AUDIT LOG (Section 24) */}
      {activeSubTab === 'AuditLog' && (
        <div className="bg-[#111827] border border-slate-800 rounded-2xl p-6 space-y-5">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Clock className="w-4 h-4 text-cyan-400" />
                Security Activity & Administrative Audit Trail
              </h3>
              <p className="text-xs text-slate-400">Chronological ledger of user authentications and administrative mutations</p>
            </div>
          </div>

          <div className="space-y-3 text-xs">
            {auditLogs.map(log => (
              <div
                key={log.id}
                className="p-3.5 bg-slate-900/70 border border-slate-800 rounded-xl flex items-start justify-between gap-3"
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className={`w-2 h-2 rounded-full ${
                      log.severity === 'danger' ? 'bg-rose-500' :
                      log.severity === 'warning' ? 'bg-amber-500' : 'bg-emerald-500'
                    }`} />
                    <span className="font-bold text-slate-200">{log.title}</span>
                  </div>
                  <p className="text-slate-400">{log.description}</p>
                  <div className="flex items-center gap-3 text-[11px] text-slate-500 pt-0.5">
                    <span>User: <strong className="text-slate-400">{log.user}</strong></span>
                    {log.device && <span>• {log.device}</span>}
                    {log.browser && <span>• {log.browser}</span>}
                  </div>
                </div>
                <span className="text-[10px] text-slate-500 shrink-0 font-mono">{log.timestamp}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 4. DATA CONTROL (Section 26) */}
      {activeSubTab === 'DataControl' && (
        <div className="bg-[#111827] border border-slate-800 rounded-2xl p-6 space-y-6">
          <div className="space-y-1">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Download className="w-4 h-4 text-indigo-400" />
              Data Sovereignty & Export Controls
            </h3>
            <p className="text-xs text-slate-400">Export your project portfolios, tasks, and audit histories in portable JSON/CSV schemas</p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 text-xs">
            <button
              onClick={() => handleExportData('all')}
              className="p-4 bg-slate-900 border border-slate-800 hover:border-indigo-500/50 rounded-xl text-left space-y-2 transition-colors"
            >
              <Download className="w-4 h-4 text-indigo-400" />
              <div className="font-semibold text-slate-100">Download My Data</div>
              <p className="text-[11px] text-slate-400">Full archive of personal profile, tasks, and study records.</p>
            </button>

            <button
              onClick={() => handleExportData('projects')}
              className="p-4 bg-slate-900 border border-slate-800 hover:border-indigo-500/50 rounded-xl text-left space-y-2 transition-colors"
            >
              <FileSpreadsheet className="w-4 h-4 text-cyan-400" />
              <div className="font-semibold text-slate-100">Export Projects</div>
              <p className="text-[11px] text-slate-400">Milestones, schedules, and deliverables in JSON.</p>
            </button>

            <button
              onClick={() => handleExportData('tasks')}
              className="p-4 bg-slate-900 border border-slate-800 hover:border-indigo-500/50 rounded-xl text-left space-y-2 transition-colors"
            >
              <FileSpreadsheet className="w-4 h-4 text-emerald-400" />
              <div className="font-semibold text-slate-100">Export Tasks</div>
              <p className="text-[11px] text-slate-400">Backlogs, subtasks, priorities, and deadlines.</p>
            </button>

            <button
              onClick={() => handleExportData('activity')}
              className="p-4 bg-slate-900 border border-slate-800 hover:border-indigo-500/50 rounded-xl text-left space-y-2 transition-colors"
            >
              <Clock className="w-4 h-4 text-amber-400" />
              <div className="font-semibold text-slate-100">Export Activity History</div>
              <p className="text-[11px] text-slate-400">Audit logs and collaboration timestamps.</p>
            </button>
          </div>

          {/* Danger Zone: Delete Account (Section 26) */}
          <div className="pt-6 border-t border-slate-800/80 space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-rose-400">Danger Zone</h4>
            <div className="p-4 bg-rose-950/20 border border-rose-500/30 rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-4 text-xs">
              <div>
                <span className="font-semibold text-rose-200 block">Delete Account & Scrub Data</span>
                <p className="text-[11px] text-rose-300/80 mt-0.5">
                  Deleting your account permanently removes your projects, tasks, files, comments and personal data.
                </p>
              </div>
              <button
                onClick={() => setIsDeleteModalOpen(true)}
                className="px-4 py-2 bg-rose-600 hover:bg-rose-500 text-white font-semibold rounded-xl text-xs shrink-0 shadow-sm"
              >
                Delete Account
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal (Section 26) */}
      {isDeleteModalOpen && (
        <Modal
          isOpen={true}
          onClose={() => setIsDeleteModalOpen(false)}
          title="Confirm Permanent Deletion"
          subtitle="This action cannot be undone."
        >
          <div className="space-y-4 text-xs">
            <div className="p-3.5 bg-rose-950/40 border border-rose-500/30 rounded-xl text-rose-200">
              "Deleting your account permanently removes your projects, tasks, files, comments and personal data."
            </div>

            <p className="text-slate-300">
              To verify deletion, please type <strong className="text-white font-mono">DELETE</strong> in the box below:
            </p>

            <input
              type="text"
              value={deleteConfirmText}
              onChange={e => setDeleteConfirmText(e.target.value)}
              placeholder="Type DELETE"
              className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-white font-mono focus:outline-none focus:border-rose-500"
            />

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setIsDeleteModalOpen(false)}
                className="px-4 py-2 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleDeleteAccount}
                disabled={deleteConfirmText !== 'DELETE'}
                className="px-4 py-2 bg-rose-600 hover:bg-rose-500 disabled:opacity-40 text-white font-semibold rounded-xl"
              >
                Permanently Delete Account
              </button>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
};
