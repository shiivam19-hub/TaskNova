import React, { useState } from 'react';
import {
  BarChart3,
  TrendingUp,
  CheckCircle2,
  Clock,
  AlertTriangle,
  BookOpen,
  Timer,
  Filter,
  Users
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { Avatar } from '../common/Avatar';

export const AnalyticsView: React.FC = () => {
  const { projects, teamMembers } = useApp();
  const [timeRange, setTimeRange] = useState<'This Week' | 'This Month' | 'Quarter'>('This Month');

  // Weekly Workload Data (Mon - Sun)
  const weeklyWorkload = [
    { day: 'Mon', tasks: 12, studyHours: 3.5, height: '65%' },
    { day: 'Tue', tasks: 16, studyHours: 4.0, height: '85%' },
    { day: 'Wed', tasks: 14, studyHours: 3.0, height: '75%' },
    { day: 'Thu', tasks: 19, studyHours: 4.5, height: '95%' },
    { day: 'Fri', tasks: 15, studyHours: 3.5, height: '80%' },
    { day: 'Sat', tasks: 8, studyHours: 5.0, height: '45%' },
    { day: 'Sun', tasks: 6, studyHours: 4.0, height: '35%' }
  ];

  return (
    <div className="space-y-6 animate-fade-in pb-16">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-white flex items-center gap-2.5">
            <BarChart3 className="w-6 h-6 text-indigo-400" />
            Performance & Productivity Intelligence
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Real-time telemetry on task burnup, team velocity, academic revision hours, and focus sessions.
          </p>
        </div>

        {/* Time Filter */}
        <div className="flex items-center gap-1.5 bg-[#111827] border border-slate-800 p-1.5 rounded-2xl text-xs font-semibold">
          {(['This Week', 'This Month', 'Quarter'] as const).map(range => (
            <button
              key={range}
              onClick={() => setTimeRange(range)}
              className={`px-3 py-1.5 rounded-xl transition-all ${
                timeRange === range
                  ? 'bg-indigo-600 text-white shadow-md shadow-indigo-950/40'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              {range}
            </button>
          ))}
        </div>
      </div>

      {/* Metrics Row (Section 19) */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        <div className="bg-[#111827] border border-slate-800 rounded-2xl p-4">
          <span className="text-[10px] text-slate-400 uppercase tracking-wider block">Completed Tasks</span>
          <span className="text-2xl font-bold text-white mt-1 block">142</span>
          <span className="text-[10px] text-emerald-400 flex items-center mt-1">
            <TrendingUp className="w-3 h-3 mr-0.5" /> +18.2%
          </span>
        </div>

        <div className="bg-[#111827] border border-slate-800 rounded-2xl p-4">
          <span className="text-[10px] text-slate-400 uppercase tracking-wider block">Pending Tasks</span>
          <span className="text-2xl font-bold text-cyan-400 mt-1 block">38</span>
          <span className="text-[10px] text-slate-400 block mt-1">across sprints</span>
        </div>

        <div className="bg-[#111827] border border-slate-800 rounded-2xl p-4">
          <span className="text-[10px] text-slate-400 uppercase tracking-wider block">Overdue Tasks</span>
          <span className="text-2xl font-bold text-rose-400 mt-1 block">7</span>
          <span className="text-[10px] text-rose-300/80 block mt-1">Urgent attention</span>
        </div>

        <div className="bg-[#111827] border border-slate-800 rounded-2xl p-4">
          <span className="text-[10px] text-slate-400 uppercase tracking-wider block">Avg Completion</span>
          <span className="text-2xl font-bold text-amber-400 mt-1 block">2.8 Days</span>
          <span className="text-[10px] text-slate-400 block mt-1">-0.4d faster</span>
        </div>

        <div className="bg-[#111827] border border-slate-800 rounded-2xl p-4">
          <span className="text-[10px] text-slate-400 uppercase tracking-wider block">Study Hours</span>
          <span className="text-2xl font-bold text-purple-400 mt-1 block">18.5h</span>
          <span className="text-[10px] text-purple-300 block mt-1">Academic streak</span>
        </div>

        <div className="bg-[#111827] border border-slate-800 rounded-2xl p-4">
          <span className="text-[10px] text-slate-400 uppercase tracking-wider block">Focus Sessions</span>
          <span className="text-2xl font-bold text-indigo-400 mt-1 block">42</span>
          <span className="text-[10px] text-emerald-400 block mt-1">94% on-time</span>
        </div>
      </div>

      {/* Visual Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Chart 1: Weekly Workload & Study Hours Bar Chart */}
        <div className="bg-[#111827] border border-slate-800 rounded-2xl p-5 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-white">Weekly Workload & Study Velocity</h3>
              <p className="text-xs text-slate-400">Tasks closed (blue) vs study hours dedicated (purple)</p>
            </div>
            <div className="flex items-center gap-3 text-[11px]">
              <span className="flex items-center gap-1 text-slate-300">
                <span className="w-2.5 h-2.5 rounded-sm bg-indigo-500" /> Tasks
              </span>
              <span className="flex items-center gap-1 text-slate-300">
                <span className="w-2.5 h-2.5 rounded-sm bg-purple-400" /> Study Hours
              </span>
            </div>
          </div>

          {/* Bar chart canvas visualization */}
          <div className="h-60 pt-6 flex items-end justify-between gap-3 px-2 border-b border-slate-800">
            {weeklyWorkload.map(bar => (
              <div key={bar.day} className="flex-1 flex flex-col items-center gap-1 h-full justify-end group">
                <span className="text-[10px] text-slate-400 opacity-0 group-hover:opacity-100 transition-opacity">
                  {bar.tasks}t / {bar.studyHours}h
                </span>
                <div className="w-full flex items-end gap-1 justify-center h-full max-h-[180px]">
                  {/* Tasks bar */}
                  <div
                    className="w-3.5 bg-indigo-500 rounded-t-md transition-all hover:bg-indigo-400 shadow-md shadow-indigo-950/40"
                    style={{ height: bar.height }}
                  />
                  {/* Study hours bar */}
                  <div
                    className="w-3.5 bg-purple-500 rounded-t-md transition-all hover:bg-purple-400 shadow-md shadow-purple-950/40"
                    style={{ height: `${parseFloat(bar.height) * 0.7}%` }}
                  />
                </div>
                <span className="text-xs font-semibold text-slate-300 mt-2">{bar.day}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Chart 2: Project Completion Comparison */}
        <div className="bg-[#111827] border border-slate-800 rounded-2xl p-5 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-white">Project Deliverable Completion</h3>
              <p className="text-xs text-slate-400">Milestone attainment rate across core active projects</p>
            </div>
          </div>

          <div className="space-y-4 pt-2">
            {projects.map(p => (
              <div key={p.id} className="space-y-1.5">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-semibold text-slate-200">{p.name}</span>
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] text-slate-400">{p.taskCount} tasks</span>
                    <span className="font-bold text-white">{p.progress}%</span>
                  </div>
                </div>
                <div className="w-full h-2.5 bg-slate-800 rounded-full overflow-hidden">
                  <div
                    className={`h-full rounded-full transition-all duration-500 ${
                      p.progress >= 80 ? 'bg-emerald-500' : p.progress >= 50 ? 'bg-indigo-500' : 'bg-rose-500'
                    }`}
                    style={{ width: `${p.progress}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Team Productivity Leaderboard */}
      <div className="bg-[#111827] border border-slate-800 rounded-2xl p-5 space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Users className="w-4 h-4 text-cyan-400" />
              Team Velocity & Contribution Metrics
            </h3>
            <p className="text-xs text-slate-400">Task turnaround time and productivity ranking</p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {teamMembers.map((m, idx) => (
            <div
              key={m.id}
              className="p-4 bg-slate-900/60 border border-slate-800 rounded-xl flex items-center justify-between"
            >
              <div className="flex items-center gap-3">
                <span className="font-bold text-xs text-slate-500 font-mono">#{idx + 1}</span>
                <Avatar name={m.name} initials={m.initials} size="sm" color={m.avatarColor} status={m.status} showStatus />
                <div>
                  <h4 className="text-xs font-bold text-slate-200">{m.name}</h4>
                  <p className="text-[11px] text-slate-400">{m.role}</p>
                </div>
              </div>
              <div className="text-right">
                <span className="text-xs font-bold text-emerald-400">{m.productivity}%</span>
                <span className="text-[10px] text-slate-500 block">{m.tasksCompleted} tasks</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
