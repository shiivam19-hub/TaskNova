import React, { useState } from 'react';
import {
  Calendar,
  Flame,
  Clock,
  AlertCircle,
  CheckCircle2,
  Sparkles,
  RefreshCw,
  Plus,
  BookOpen,
  ArrowRight
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { useToast } from '../../context/ToastContext';
import { StudyPlan } from '../../types';

export const StudyPlannerView: React.FC = () => {
  const {
    studyPlan,
    toggleStudyDayCompleted,
    generateNewPlan,
    setActiveTab
  } = useApp();

  const { showToast } = useToast();

  const [subject, setSubject] = useState(studyPlan.subject);
  const [examDate, setExamDate] = useState(studyPlan.examDate);
  const [hoursPerDay, setHoursPerDay] = useState(studyPlan.availableHoursPerDay);
  const [difficulty, setDifficulty] = useState<StudyPlan['difficulty']>(studyPlan.difficulty);

  const completedDaysCount = studyPlan.days.filter(d => d.completed).length;
  const totalDays = studyPlan.days.length;
  const hoursStudied = studyPlan.days.filter(d => d.completed).reduce((acc, curr) => acc + curr.durationHours, 0);

  const handleGenerate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!subject.trim()) return;
    generateNewPlan(subject.trim(), examDate, hoursPerDay, difficulty);
    showToast('Plan Generated', `New 7-day study roadmap for ${subject} is ready.`, 'success');
  };

  return (
    <div className="space-y-6 animate-fade-in pb-16">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-white flex items-center gap-2.5">
            <Calendar className="w-6 h-6 text-purple-400" />
            AI Study Planner & Exam Blueprint
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Dynamic milestone generator adapting to exam dates, available daily hours, and weak topic reinforcement.
          </p>
        </div>

        <button
          onClick={() => setActiveTab('timer')}
          className="flex items-center gap-2 px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold rounded-xl shadow-lg shadow-indigo-950/40 transition-all self-start sm:self-auto"
        >
          <Clock className="w-4 h-4" />
          Start Focus Timer
        </button>
      </div>

      {/* Metrics Row: Progress, Streak, Remaining Days, Hours Studied (Section 16) */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="bg-[#111827] border border-slate-800 rounded-2xl p-4">
          <span className="text-xs text-slate-400 uppercase tracking-wider block">Progress</span>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold text-white">{studyPlan.progress}%</span>
            <span className="text-xs text-slate-400">({completedDaysCount}/{totalDays} Days)</span>
          </div>
          <div className="w-full h-1.5 bg-slate-800 rounded-full mt-2 overflow-hidden">
            <div className="h-full bg-purple-500 rounded-full" style={{ width: `${studyPlan.progress}%` }} />
          </div>
        </div>

        <div className="bg-[#111827] border border-slate-800 rounded-2xl p-4">
          <span className="text-xs text-slate-400 uppercase tracking-wider block">Study Streak</span>
          <div className="mt-2 flex items-center gap-2">
            <span className="text-2xl font-bold text-amber-400">7 Days</span>
            <Flame className="w-5 h-5 text-amber-400 animate-pulse" />
          </div>
          <span className="text-[11px] text-slate-400 mt-1 block">Active momentum 🔥</span>
        </div>

        <div className="bg-[#111827] border border-slate-800 rounded-2xl p-4">
          <span className="text-xs text-slate-400 uppercase tracking-wider block">Remaining Days</span>
          <div className="mt-2 flex items-baseline gap-1">
            <span className="text-2xl font-bold text-cyan-400">{totalDays - completedDaysCount}</span>
            <span className="text-xs text-slate-400">Days to Exam</span>
          </div>
          <span className="text-[11px] text-slate-400 mt-1 block">Exam: {studyPlan.examDate}</span>
        </div>

        <div className="bg-[#111827] border border-slate-800 rounded-2xl p-4">
          <span className="text-xs text-slate-400 uppercase tracking-wider block">Hours Studied</span>
          <div className="mt-2 flex items-baseline gap-1">
            <span className="text-2xl font-bold text-emerald-400">{hoursStudied}h</span>
            <span className="text-xs text-slate-400">completed</span>
          </div>
          <span className="text-[11px] text-slate-400 mt-1 block">Avg {studyPlan.availableHoursPerDay}h/day</span>
        </div>
      </div>

      {/* Weak Topics Warning Banner (Section 16) */}
      <div className="p-4 bg-amber-950/30 border border-amber-500/30 rounded-2xl flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-start gap-3">
          <AlertCircle className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
          <div>
            <span className="text-xs font-bold text-amber-200 uppercase tracking-wider block">
              Flagged Weak Topics for Revision
            </span>
            <div className="flex flex-wrap gap-2 mt-1.5">
              {studyPlan.weakTopics.map(topic => (
                <span
                  key={topic}
                  className="px-2.5 py-0.5 rounded-lg bg-amber-500/15 border border-amber-500/30 text-amber-300 text-xs font-medium"
                >
                  ⚠️ {topic}
                </span>
              ))}
            </div>
          </div>
        </div>

        <button
          onClick={() => setActiveTab('ai-assistant')}
          className="px-3 py-1.5 bg-amber-500/20 hover:bg-amber-500/30 text-amber-200 border border-amber-500/40 rounded-xl text-xs font-semibold shrink-0 transition-colors"
        >
          Ask AI to Explain Weak Topics
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: 7-Day Structured Schedule (Section 16) */}
        <div className="lg:col-span-2 bg-[#111827] border border-slate-800 rounded-2xl p-5 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-white uppercase tracking-wider">
                {studyPlan.subject} — 7-Day Sprint
              </h3>
              <p className="text-xs text-slate-400">Click checkboxes to mark curriculum chapters as mastered</p>
            </div>
            <span className="text-xs font-bold px-2.5 py-1 rounded-full bg-purple-500/15 text-purple-300 border border-purple-500/30">
              Difficulty: {studyPlan.difficulty}
            </span>
          </div>

          <div className="space-y-3">
            {studyPlan.days.map(day => (
              <div
                key={day.dayNumber}
                className={`p-4 rounded-xl border flex items-center justify-between gap-3 transition-all ${
                  day.completed
                    ? 'bg-slate-900/40 border-slate-800/80 opacity-70'
                    : 'bg-slate-900/90 border-slate-800 hover:border-purple-500/40'
                }`}
              >
                <div className="flex items-center gap-3.5 min-w-0">
                  <button
                    onClick={() => toggleStudyDayCompleted(day.dayNumber)}
                    className={`w-6 h-6 rounded-lg border flex items-center justify-center transition-colors shrink-0 ${
                      day.completed
                        ? 'bg-emerald-500 border-emerald-500 text-white'
                        : 'border-slate-700 hover:border-purple-500'
                    }`}
                  >
                    {day.completed && <CheckCircle2 className="w-4 h-4" />}
                  </button>

                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-purple-400 font-mono">
                        DAY {day.dayNumber}
                      </span>
                      {day.weakArea && (
                        <span className="text-[9px] font-bold px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30">
                          PRIORITY TOPIC
                        </span>
                      )}
                    </div>
                    <h4 className={`text-sm font-semibold mt-0.5 truncate ${
                      day.completed ? 'line-through text-slate-500' : 'text-slate-100'
                    }`}>
                      {day.topic}
                    </h4>
                  </div>
                </div>

                <div className="text-right shrink-0">
                  <span className="text-xs font-medium text-slate-300 block">{day.durationHours}h Session</span>
                  <span className="text-[10px] text-slate-500">
                    {day.completed ? 'Mastered ✅' : 'Pending'}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right Col: Custom Schedule Generator Form */}
        <div className="bg-[#111827] border border-slate-800 rounded-2xl p-5 space-y-4">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-purple-400" />
            <h3 className="text-sm font-bold text-white">Generate Study Roadmap</h3>
          </div>

          <form onSubmit={handleGenerate} className="space-y-3.5 text-xs">
            <div>
              <label className="block text-slate-400 mb-1 font-semibold uppercase text-[10px]">
                Target Subject / Course
              </label>
              <input
                type="text"
                required
                value={subject}
                onChange={e => setSubject(e.target.value)}
                placeholder="e.g. Computer Networks & TCP/IP"
                className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-slate-100 focus:outline-none focus:border-purple-500"
              />
            </div>

            <div>
              <label className="block text-slate-400 mb-1 font-semibold uppercase text-[10px]">
                Exam / Deadline Date
              </label>
              <input
                type="text"
                value={examDate}
                onChange={e => setExamDate(e.target.value)}
                placeholder="October 15, 2026"
                className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-slate-100 focus:outline-none focus:border-purple-500"
              />
            </div>

            <div>
              <label className="block text-slate-400 mb-1 font-semibold uppercase text-[10px]">
                Daily Study Hours: <strong className="text-purple-400">{hoursPerDay}h</strong>
              </label>
              <input
                type="range"
                min={1}
                max={8}
                step={0.5}
                value={hoursPerDay}
                onChange={e => setHoursPerDay(Number(e.target.value))}
                className="w-full accent-purple-500"
              />
            </div>

            <div>
              <label className="block text-slate-400 mb-1 font-semibold uppercase text-[10px]">
                Difficulty Tier
              </label>
              <select
                value={difficulty}
                onChange={e => setDifficulty(e.target.value as any)}
                className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-slate-100 focus:outline-none focus:border-purple-500"
              >
                <option value="Easy">Easy (Conceptual Overview)</option>
                <option value="Medium">Medium (Balanced Theory & Code)</option>
                <option value="Hard">Hard (Deep Dive & Mock Exams)</option>
                <option value="Intense">Intense (Competitive Prep)</option>
              </select>
            </div>

            <button
              type="submit"
              className="w-full py-2.5 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-semibold rounded-xl shadow-md shadow-purple-950/40 transition-all flex items-center justify-center gap-2"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              Re-Calculate 7-Day Plan
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
