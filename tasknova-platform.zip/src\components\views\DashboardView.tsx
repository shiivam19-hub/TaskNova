import React from 'react';
import {
  FolderKanban,
  CheckCircle2,
  Clock,
  TrendingUp,
  AlertTriangle,
  Flame,
  Timer,
  ArrowUpRight,
  Calendar,
  Sparkles,
  Users,
  CheckSquare,
  FileText,
  MessageSquare,
  ChevronRight
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { Avatar } from '../common/Avatar';
import { Project, Task } from '../../types';

export const DashboardView: React.FC = () => {
  const {
    userProfile,
    projects,
    tasks,
    activities,
    openProjectDetails,
    setActiveTab,
    openQuickCreate,
    toggleTaskCompletion,
    studyPlan,
    openDailyBriefing
  } = useApp();

  const activeProjectsCount = projects.filter(p => p.status !== 'Completed').length;
  const activeTasks = tasks.filter(t => t.status !== 'COMPLETED');
  const completedTasks = tasks.filter(t => t.status === 'COMPLETED');
  const overdueTasks = tasks.filter(t => t.dueDate.toLowerCase().includes('tomorrow') || t.priority === 'Urgent');

  const getStatusColor = (status: Project['status']) => {
    switch (status) {
      case 'Near Completion':
        return 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30';
      case 'In Progress':
        return 'bg-indigo-500/15 text-indigo-400 border-indigo-500/30';
      case 'At Risk':
        return 'bg-rose-500/15 text-rose-400 border-rose-500/30';
      default:
        return 'bg-slate-700/30 text-slate-300 border-slate-600/30';
    }
  };

  const getPriorityBadgeClass = (priority: string) => {
    switch (priority) {
      case 'Urgent':
      case 'Critical':
        return 'bg-rose-500/10 text-rose-400 border-rose-500/20';
      case 'High':
        return 'bg-amber-500/10 text-amber-400 border-amber-500/20';
      case 'Medium':
        return 'bg-blue-500/10 text-blue-400 border-blue-500/20';
      default:
        return 'bg-slate-500/10 text-slate-400 border-slate-500/20';
    }
  };

  const getPriorityColor = (priority: Task['priority']) => {
    switch (priority) {
      case 'Urgent':
        return 'bg-rose-500/15 text-rose-400 border-rose-500/30';
      case 'High':
        return 'bg-amber-500/15 text-amber-400 border-amber-500/30';
      case 'Medium':
        return 'bg-cyan-500/15 text-cyan-400 border-cyan-500/30';
      default:
        return 'bg-slate-700/30 text-slate-400 border-slate-600/30';
    }
  };

  return (
    <div className="space-y-6 animate-fade-in pb-12">
      {/* Header Greeting & Action */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-white flex items-center gap-2.5">
            Good morning, {userProfile.name} 👋
          </h1>
          <p className="text-sm text-slate-400 mt-1">
            Here's what's happening across your projects and study goals today.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <button
            onClick={openDailyBriefing}
            className="flex items-center gap-2 px-3.5 py-2 bg-gradient-to-r from-indigo-600/25 via-indigo-500/20 to-cyan-500/20 hover:from-indigo-600/35 hover:to-cyan-500/30 border border-indigo-500/40 hover:border-indigo-400/60 text-indigo-200 hover:text-white text-xs font-semibold rounded-xl shadow-lg shadow-indigo-950/40 transition-all group cursor-pointer"
          >
            <Sparkles className="w-4 h-4 text-cyan-400 group-hover:rotate-12 transition-transform" />
            <span>✨ What should I work on today?</span>
          </button>
          <button
            onClick={() => setActiveTab('timer')}
            className="flex items-center gap-2 px-3.5 py-2 bg-slate-900 border border-slate-800 hover:border-slate-700 text-slate-200 text-xs font-medium rounded-xl transition-colors"
          >
            <Timer className="w-4 h-4 text-cyan-400" />
            Focus Session
          </button>
          <button
            onClick={() => openQuickCreate('task')}
            className="flex items-center gap-2 px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold rounded-xl shadow-lg shadow-indigo-950/40 transition-all"
          >
            + Add Task
          </button>
        </div>
      </div>

      {/* KPI Overview Cards (Section 4) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* TOTAL PROJECTS */}
        <div className="bg-[#111827] border border-slate-800/90 rounded-2xl p-4 sm:p-5 shadow-sm interactive-card">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
              Total Projects
            </span>
            <div className="w-8 h-8 rounded-lg bg-indigo-500/10 text-indigo-400 flex items-center justify-center">
              <FolderKanban className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl sm:text-3xl font-bold text-white">24</span>
            <span className="text-xs font-medium text-emerald-400 flex items-center">
              <TrendingUp className="w-3 h-3 mr-0.5" /> +12.5%
            </span>
          </div>
          <p className="text-[11px] text-slate-400 mt-1">this month</p>
        </div>

        {/* ACTIVE TASKS */}
        <div className="bg-[#111827] border border-slate-800/90 rounded-2xl p-4 sm:p-5 shadow-sm interactive-card">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
              Active Tasks
            </span>
            <div className="w-8 h-8 rounded-lg bg-cyan-500/10 text-cyan-400 flex items-center justify-center">
              <Clock className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl sm:text-3xl font-bold text-white">86</span>
            <span className="text-xs font-medium text-emerald-400 flex items-center">
              <TrendingUp className="w-3 h-3 mr-0.5" /> +8.4%
            </span>
          </div>
          <p className="text-[11px] text-slate-400 mt-1">this week</p>
        </div>

        {/* COMPLETED TASKS */}
        <div className="bg-[#111827] border border-slate-800/90 rounded-2xl p-4 sm:p-5 shadow-sm interactive-card">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
              Completed Tasks
            </span>
            <div className="w-8 h-8 rounded-lg bg-emerald-500/10 text-emerald-400 flex items-center justify-center">
              <CheckCircle2 className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl sm:text-3xl font-bold text-white">142</span>
            <span className="text-xs font-medium text-emerald-400 flex items-center">
              <TrendingUp className="w-3 h-3 mr-0.5" /> +18.2%
            </span>
          </div>
          <p className="text-[11px] text-slate-400 mt-1">this month</p>
        </div>

        {/* TEAM PRODUCTIVITY */}
        <div className="bg-[#111827] border border-slate-800/90 rounded-2xl p-4 sm:p-5 shadow-sm interactive-card">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
              Team Productivity
            </span>
            <div className="w-8 h-8 rounded-lg bg-purple-500/10 text-purple-400 flex items-center justify-center">
              <Sparkles className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl sm:text-3xl font-bold text-white">87%</span>
            <span className="text-xs font-medium text-emerald-400 flex items-center">
              <TrendingUp className="w-3 h-3 mr-0.5" /> +5.6%
            </span>
          </div>
          <p className="text-[11px] text-slate-400 mt-1">this week</p>
        </div>
      </div>

      {/* Secondary Quick Metrics: Overdue, Upcoming Deadlines, Study Streak, Focus Time */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="p-3 bg-rose-950/20 border border-rose-500/30 rounded-xl flex items-center gap-3">
          <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
          <div>
            <div className="text-xs font-bold text-rose-200">7 Overdue Tasks</div>
            <div className="text-[10px] text-rose-300/80">Immediate attention</div>
          </div>
        </div>

        <div className="p-3 bg-indigo-950/20 border border-indigo-500/30 rounded-xl flex items-center gap-3">
          <Calendar className="w-4 h-4 text-indigo-400 shrink-0" />
          <div>
            <div className="text-xs font-bold text-indigo-200">3 Upcoming Deadlines</div>
            <div className="text-[10px] text-indigo-300/80">Next 48 hours</div>
          </div>
        </div>

        <div className="p-3 bg-amber-950/20 border border-amber-500/30 rounded-xl flex items-center gap-3">
          <Flame className="w-4 h-4 text-amber-400 shrink-0" />
          <div>
            <div className="text-xs font-bold text-amber-200">7-Day Study Streak 🔥</div>
            <div className="text-[10px] text-amber-300/80">Keep the momentum</div>
          </div>
        </div>

        <div className="p-3 bg-cyan-950/20 border border-cyan-500/30 rounded-xl flex items-center gap-3">
          <Timer className="w-4 h-4 text-cyan-400 shrink-0" />
          <div>
            <div className="text-xs font-bold text-cyan-200">1h 45m Focus Time</div>
            <div className="text-[10px] text-cyan-300/80">3 sessions today</div>
          </div>
        </div>
      </div>

      {/* Project Overview Section (Section 5) */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg font-bold text-white tracking-tight">Project Overview</h2>
            <p className="text-xs text-slate-400">Current progress and operational health across active projects</p>
          </div>
          <button
            onClick={() => setActiveTab('projects')}
            className="text-xs font-medium text-indigo-400 hover:text-indigo-300 flex items-center gap-1 transition-colors"
          >
            View all ({projects.length})
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {projects.map(project => (
            <div
              key={project.id}
              onClick={() => openProjectDetails(project.id)}
              className="bg-[#111827] border border-slate-800/90 hover:border-indigo-500/50 rounded-2xl p-5 shadow-sm interactive-card cursor-pointer group"
            >
              <div className="flex items-start justify-between gap-3">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full border ${getStatusColor(project.status)}`}>
                      {project.status}
                    </span>
                    <span className="text-[10px] text-slate-400">
                      {project.category}
                    </span>
                  </div>
                  <h3 className="text-base font-semibold text-slate-100 group-hover:text-indigo-400 transition-colors truncate">
                    {project.name}
                  </h3>
                  <p className="text-xs text-slate-400 mt-1 line-clamp-2 leading-relaxed">
                    {project.description}
                  </p>
                </div>
                <ArrowUpRight className="w-4 h-4 text-slate-500 group-hover:text-indigo-400 transition-colors shrink-0 mt-1" />
              </div>

              {/* Progress bar */}
              <div className="mt-4 space-y-1.5">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-slate-400">Progress</span>
                  <span className="font-semibold text-slate-200">{project.progress}%</span>
                </div>
                <div className="w-full h-2 rounded-full bg-slate-800 overflow-hidden">
                  <div
                    className={`h-full rounded-full transition-all duration-500 ${
                      project.progress >= 80
                        ? 'bg-emerald-500'
                        : project.progress >= 50
                        ? 'bg-indigo-500'
                        : 'bg-rose-500'
                    }`}
                    style={{ width: `${project.progress}%` }}
                  />
                </div>
              </div>

              {/* Meta details footer */}
              <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between text-xs text-slate-400">
                <div className="flex items-center gap-1.5">
                  <Calendar className="w-3.5 h-3.5 text-slate-500" />
                  <span>Due {project.deadline}</span>
                </div>

                <div className="flex items-center gap-2">
                  <span className="text-[11px] text-slate-400">{project.taskCount} tasks</span>
                  {/* Team avatars stack */}
                  <div className="flex -space-x-1.5 overflow-hidden">
                    {project.team.slice(0, 3).map((member, i) => (
                      <Avatar
                        key={i}
                        name={member}
                        size="xs"
                        color="bg-slate-700 text-slate-300"
                        className="ring-2 ring-[#111827]"
                      />
                    ))}
                    {project.team.length > 3 && (
                      <div className="w-6 h-6 rounded-full bg-slate-800 border border-slate-700 text-[9px] font-bold text-slate-300 flex items-center justify-center ring-2 ring-[#111827]">
                        +{project.team.length - 3}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Split Columns: High Priority Tasks & Recent Activity (Section 11) */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Active & High Priority Tasks */}
        <div className="lg:col-span-2 bg-[#111827] border border-slate-800/90 rounded-2xl p-5 shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <CheckSquare className="w-4 h-4 text-indigo-400" />
              <h3 className="text-sm font-bold text-white tracking-tight">Focus Tasks Today</h3>
            </div>
            <button
              onClick={() => setActiveTab('tasks')}
              className="text-xs text-indigo-400 hover:text-indigo-300 font-medium"
            >
              View all ({tasks.length})
            </button>
          </div>

          <div className="space-y-2.5">
            {tasks.slice(0, 4).map(task => (
              <div
                key={task.id}
                className="p-3 bg-slate-900/70 border border-slate-800/80 hover:border-slate-700 rounded-xl flex items-center justify-between gap-3 transition-colors"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <button
                    onClick={() => toggleTaskCompletion(task.id)}
                    className={`w-5 h-5 rounded-lg border flex items-center justify-center transition-colors shrink-0 ${
                      task.status === 'COMPLETED'
                        ? 'bg-emerald-500 border-emerald-500 text-white'
                        : 'border-slate-700 hover:border-indigo-500'
                    }`}
                  >
                    {task.status === 'COMPLETED' && <CheckCircle2 className="w-3.5 h-3.5" />}
                  </button>
                  <div className="min-w-0">
                    <span className={`text-xs font-semibold block truncate ${
                      task.status === 'COMPLETED' ? 'line-through text-slate-500' : 'text-slate-200'
                    }`}>
                      {task.title}
                    </span>
                    <span className="text-[11px] text-slate-400 truncate block mt-0.5">
                      {task.projectName} • Due {task.dueDate}
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <span className={`text-[10px] font-semibold px-2 py-0.5 rounded border ${getPriorityColor(task.priority)}`}>
                    {task.priority}
                  </span>
                  <Avatar name={task.assignee.name} size="xs" color={task.assignee.avatarColor} />
                </div>
              </div>
            ))}
          </div>

          {/* Mini Study Hub Goal Banner */}
          <div className="p-4 rounded-xl bg-gradient-to-r from-indigo-950/60 to-cyan-950/40 border border-indigo-500/20 flex items-center justify-between gap-3">
            <div className="space-y-1">
              <span className="text-[10px] font-bold uppercase tracking-wider text-indigo-400">
                Study Goal: {studyPlan.subject}
              </span>
              <p className="text-xs text-slate-200 font-medium">
                Day 5: Trees, BST Traversals & LCA (Target Exam: {studyPlan.examDate})
              </p>
            </div>
            <button
              onClick={() => setActiveTab('study-planner')}
              className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-medium rounded-lg shrink-0 transition-colors"
            >
              Open Schedule
            </button>
          </div>
        </div>

        {/* Right Col: Recent Activity Timeline (Section 11) */}
        <div className="bg-[#111827] border border-slate-800/90 rounded-2xl p-5 shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4 text-cyan-400" />
              <h3 className="text-sm font-bold text-white tracking-tight">Recent Activity</h3>
            </div>
            <span className="text-[11px] text-slate-400">Live stream</span>
          </div>

          <div className="relative pl-5 space-y-4 before:absolute before:left-2 before:top-2 before:bottom-2 before:w-0.5 before:bg-slate-800">
            {activities.slice(0, 5).map(act => (
              <div key={act.id} className="relative text-xs">
                {/* Node dot */}
                <span className="absolute -left-5 top-1 w-2.5 h-2.5 rounded-full bg-indigo-500 ring-4 ring-[#111827]" />
                <div>
                  <span className="font-semibold text-slate-200">{act.authorName}</span>{' '}
                  <span className="text-slate-400">{act.action}</span>{' '}
                  <span className="text-indigo-300 font-medium">{act.target}</span>
                </div>
                <span className="text-[10px] text-slate-500 mt-0.5 block">{act.timestamp}</span>
              </div>
            ))}
          </div>

          <div className="pt-2 border-t border-slate-800">
            <button
              onClick={() => setActiveTab('comments')}
              className="w-full py-2 bg-slate-900 hover:bg-slate-800/80 border border-slate-800 rounded-xl text-xs font-medium text-slate-300 hover:text-white transition-colors flex items-center justify-center gap-2"
            >
              <MessageSquare className="w-3.5 h-3.5 text-indigo-400" />
              Join Team Discussion
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
