import React, { useState } from 'react';
import {
  Calendar as CalendarIcon,
  Plus,
  ChevronLeft,
  ChevronRight,
  Clock,
  MapPin,
  Trash2,
  Bell,
  Share2,
  ExternalLink,
  CheckCircle2
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { CalendarEvent } from '../../types';
import { useToast } from '../../context/ToastContext';
import { Modal } from '../common/Modal';

export const CalendarView: React.FC = () => {
  const {
    events,
    addEvent,
    deleteEvent
  } = useApp();

  const { showToast } = useToast();

  const [currentView, setCurrentView] = useState<'Month' | 'Week' | 'Day'>('Month');
  const [isAddEventOpen, setIsAddEventOpen] = useState(false);

  // New Event Form
  const [eventTitle, setEventTitle] = useState('');
  const [eventDate, setEventDate] = useState('2026-09-15');
  const [eventTime, setEventTime] = useState('10:00 AM - 11:30 AM');
  const [eventType, setEventType] = useState<CalendarEvent['type']>('meeting');
  const [eventLocation, setEventLocation] = useState('Microsoft Teams / Room 402');
  const [eventReminder, setEventReminder] = useState(15);

  const handleCreateEvent = (e: React.FormEvent) => {
    e.preventDefault();
    if (!eventTitle.trim()) return;
    addEvent({
      title: eventTitle.trim(),
      date: eventDate,
      time: eventTime,
      type: eventType,
      location: eventLocation,
      reminderMinutes: eventReminder
    });
    showToast('Event Scheduled', `"${eventTitle}" added to calendar.`, 'success');
    setIsAddEventOpen(false);
    setEventTitle('');
  };

  const getEventTypeBadge = (type: CalendarEvent['type']) => {
    switch (type) {
      case 'meeting':
        return 'bg-cyan-500/15 text-cyan-300 border-cyan-500/30';
      case 'deadline':
        return 'bg-rose-500/15 text-rose-300 border-rose-500/30';
      case 'exam':
        return 'bg-purple-500/15 text-purple-300 border-purple-500/30';
      case 'study':
        return 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30';
      case 'milestone':
        return 'bg-amber-500/15 text-amber-300 border-amber-500/30';
      default:
        return 'bg-indigo-500/15 text-indigo-300 border-indigo-500/30';
    }
  };

  // 30 days grid simulation for September 2026
  const daysInSeptember = Array.from({ length: 30 }, (_, i) => i + 1);

  return (
    <div className="space-y-6 animate-fade-in pb-16">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-white flex items-center gap-2.5">
            <CalendarIcon className="w-6 h-6 text-indigo-400" />
            Calendar & Schedule
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Track sprints, project milestones, team syncs, classes, and study deadlines.
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={() => {
              showToast('Google Calendar Sync', 'Synced 5 upcoming events with Google Calendar API architecture.', 'success');
            }}
            className="flex items-center gap-1.5 px-3 py-2 bg-slate-900 border border-slate-800 hover:border-slate-700 text-xs text-slate-300 rounded-xl transition-colors"
            title="Export to Google Calendar"
          >
            <ExternalLink className="w-3.5 h-3.5 text-indigo-400" />
            Google Calendar Sync
          </button>
          <button
            onClick={() => setIsAddEventOpen(true)}
            className="flex items-center gap-2 px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold rounded-xl shadow-lg shadow-indigo-950/40 transition-all"
          >
            <Plus className="w-4 h-4" />
            New Event
          </button>
        </div>
      </div>

      {/* View Switcher & Month Navigation */}
      <div className="bg-[#111827] border border-slate-800 rounded-2xl p-4 flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <h2 className="text-lg font-bold text-white">September 2026</h2>
          <div className="flex items-center gap-1">
            <button className="p-1 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-white transition-colors">
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button className="p-1 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-white transition-colors">
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>

        <div className="flex items-center gap-1 bg-slate-900 p-1 rounded-xl border border-slate-800 text-xs font-medium">
          {(['Month', 'Week', 'Day'] as const).map(view => (
            <button
              key={view}
              onClick={() => setCurrentView(view)}
              className={`px-3 py-1 rounded-lg transition-colors ${
                currentView === view
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {view}
            </button>
          ))}
        </div>
      </div>

      {/* Main Calendar View: Month Grid */}
      {currentView === 'Month' && (
        <div className="bg-[#111827] border border-slate-800 rounded-2xl p-4 overflow-hidden shadow-sm">
          {/* Weekday headers */}
          <div className="grid grid-cols-7 gap-px text-center text-[11px] font-bold uppercase tracking-wider text-slate-400 pb-2 border-b border-slate-800">
            {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(day => (
              <div key={day} className="py-1">
                {day}
              </div>
            ))}
          </div>

          {/* Month Days Grid */}
          <div className="grid grid-cols-7 gap-1.5 pt-2">
            {/* September 2026 starts on Tuesday (2 offset spaces) */}
            <div className="h-24 p-1 rounded-xl bg-slate-900/20 opacity-30 text-slate-600 text-xs">30</div>
            <div className="h-24 p-1 rounded-xl bg-slate-900/20 opacity-30 text-slate-600 text-xs">31</div>

            {daysInSeptember.map(day => {
              const dateStr = `2026-09-${String(day).padStart(2, '0')}`;
              const dayEvents = events.filter(e => e.date === dateStr);
              const isToday = day === 11; // Current local simulation date Friday Sept 11, 2026

              return (
                <div
                  key={day}
                  className={`h-24 p-1.5 rounded-xl border flex flex-col justify-between transition-colors overflow-hidden ${
                    isToday
                      ? 'bg-indigo-950/30 border-indigo-500/50 shadow-xs'
                      : 'bg-slate-900/50 border-slate-800/80 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className={`text-xs font-bold ${
                      isToday ? 'w-5 h-5 rounded-full bg-indigo-500 text-white flex items-center justify-center text-[10px]' : 'text-slate-300'
                    }`}>
                      {day}
                    </span>
                    {dayEvents.length > 0 && (
                      <span className="w-1.5 h-1.5 rounded-full bg-cyan-400" />
                    )}
                  </div>

                  <div className="space-y-1 overflow-y-auto">
                    {dayEvents.slice(0, 2).map(ev => (
                      <div
                        key={ev.id}
                        className={`text-[9px] px-1 py-0.5 rounded truncate border font-medium ${getEventTypeBadge(ev.type)}`}
                        title={`${ev.title} (${ev.time})`}
                      >
                        {ev.title}
                      </div>
                    ))}
                    {dayEvents.length > 2 && (
                      <div className="text-[8px] text-slate-400 pl-1 font-semibold">
                        +{dayEvents.length - 2} more
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Week & Day Views (Detailed List) */}
      {(currentView === 'Week' || currentView === 'Day') && (
        <div className="bg-[#111827] border border-slate-800 rounded-2xl p-5 space-y-4">
          <h3 className="text-sm font-bold text-white">Scheduled Timeline Events</h3>
          <div className="space-y-3">
            {events.map(ev => (
              <div
                key={ev.id}
                className="p-4 bg-slate-900/80 border border-slate-800 rounded-xl flex items-start justify-between gap-3 text-xs"
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className={`text-[10px] font-semibold px-2 py-0.5 rounded border ${getEventTypeBadge(ev.type)}`}>
                      {ev.type.toUpperCase()}
                    </span>
                    <span className="font-bold text-slate-100 text-sm">{ev.title}</span>
                  </div>
                  <div className="flex flex-wrap items-center gap-3 text-slate-400 text-xs pt-1">
                    <span className="flex items-center gap-1">
                      <Clock className="w-3.5 h-3.5 text-indigo-400" /> {ev.date} • {ev.time}
                    </span>
                    {ev.location && (
                      <span className="flex items-center gap-1">
                        <MapPin className="w-3.5 h-3.5 text-slate-500" /> {ev.location}
                      </span>
                    )}
                    {ev.reminderMinutes && (
                      <span className="flex items-center gap-1 text-indigo-300">
                        <Bell className="w-3.5 h-3.5" /> Reminder: {ev.reminderMinutes}m prior
                      </span>
                    )}
                  </div>
                </div>

                <button
                  onClick={() => deleteEvent(ev.id)}
                  className="p-1.5 text-slate-500 hover:text-rose-400 rounded-lg hover:bg-slate-800 transition-colors"
                  title="Remove event"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Upcoming Events Agenda List */}
      <div className="bg-[#111827] border border-slate-800 rounded-2xl p-5 space-y-4">
        <h3 className="text-sm font-bold text-white flex items-center gap-2">
          <Clock className="w-4 h-4 text-cyan-400" />
          Upcoming Agenda & Sync Deadlines
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {events.map(ev => (
            <div
              key={ev.id}
              className="p-3.5 bg-slate-900/60 border border-slate-800 rounded-xl flex items-start justify-between gap-3 text-xs"
            >
              <div>
                <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded border ${getEventTypeBadge(ev.type)}`}>
                  {ev.type}
                </span>
                <h4 className="font-semibold text-slate-200 mt-1">{ev.title}</h4>
                <p className="text-[11px] text-slate-400 mt-0.5">{ev.time} • {ev.location || 'Online'}</p>
              </div>
              <span className="text-[10px] text-slate-400 shrink-0 font-mono">{ev.date}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Add Event Modal */}
      {isAddEventOpen && (
        <Modal
          isOpen={true}
          onClose={() => setIsAddEventOpen(false)}
          title="Schedule New Calendar Event"
          subtitle="Add deadlines, classes, meetings, or study milestones."
        >
          <form onSubmit={handleCreateEvent} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                Event Title *
              </label>
              <input
                type="text"
                required
                value={eventTitle}
                onChange={e => setEventTitle(e.target.value)}
                placeholder="e.g. Distributed Database Architecture Sync"
                className="w-full px-3.5 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-xs text-slate-100 focus:outline-none focus:border-indigo-500"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                  Date
                </label>
                <input
                  type="date"
                  value={eventDate}
                  onChange={e => setEventDate(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-xs text-slate-100 focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                  Time
                </label>
                <input
                  type="text"
                  value={eventTime}
                  onChange={e => setEventTime(e.target.value)}
                  placeholder="02:00 PM - 03:00 PM"
                  className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-xs text-slate-100 focus:outline-none focus:border-indigo-500"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                  Category
                </label>
                <select
                  value={eventType}
                  onChange={e => setEventType(e.target.value as any)}
                  className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-xs text-slate-100 focus:outline-none focus:border-indigo-500"
                >
                  <option value="meeting">Team Meeting</option>
                  <option value="deadline">Project Deadline</option>
                  <option value="exam">Academic Exam</option>
                  <option value="class">Class Lecture</option>
                  <option value="study">Study Session</option>
                  <option value="milestone">Milestone</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                  Reminder
                </label>
                <select
                  value={eventReminder}
                  onChange={e => setEventReminder(Number(e.target.value))}
                  className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-xs text-slate-100 focus:outline-none focus:border-indigo-500"
                >
                  <option value={10}>10 minutes before</option>
                  <option value={15}>15 minutes before</option>
                  <option value={30}>30 minutes before</option>
                  <option value={60}>1 hour before</option>
                  <option value={120}>2 hours before</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                Location / Virtual Link
              </label>
              <input
                type="text"
                value={eventLocation}
                onChange={e => setEventLocation(e.target.value)}
                placeholder="Microsoft Teams Channel / Hall B"
                className="w-full px-3.5 py-2 bg-slate-900 border border-slate-700 rounded-xl text-xs text-slate-100 focus:outline-none focus:border-indigo-500"
              />
            </div>

            <div className="flex justify-end gap-2 pt-3">
              <button
                type="button"
                onClick={() => setIsAddEventOpen(false)}
                className="px-4 py-2 text-xs text-slate-400 hover:text-white rounded-xl hover:bg-slate-800"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold rounded-xl"
              >
                Schedule Event
              </button>
            </div>
          </form>
        </Modal>
      )}
    </div>
  );
};
