import React, { useState } from 'react';
import {
  FileText,
  UploadCloud,
  Download,
  Eye,
  Trash2,
  Edit2,
  Search,
  Filter,
  ArrowUpDown,
  Plus,
  Cloud,
  HardDrive
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { ProjectFile } from '../../types';
import { useToast } from '../../context/ToastContext';
import { Modal } from '../common/Modal';

export const FileManagementView: React.FC = () => {
  const { files, uploadFile, deleteFile, projects, userProfile } = useApp();
  const { showToast } = useToast();

  const [searchQuery, setSearchQuery] = useState('');
  const [typeFilter, setTypeFilter] = useState<string>('all');
  const [selectedProject, setSelectedProject] = useState<string>('all');
  const [previewingFile, setPreviewingFile] = useState<ProjectFile | null>(null);

  // Upload modal state
  const [isUploadOpen, setIsUploadOpen] = useState(false);
  const [uploadName, setUploadName] = useState('');
  const [uploadProjectId, setUploadProjectId] = useState(projects[0]?.id || 'p1');
  const [uploadSize, setUploadSize] = useState('2.4 MB');

  const filteredFiles = files.filter(f => {
    const matchesSearch = f.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (f.projectName && f.projectName.toLowerCase().includes(searchQuery.toLowerCase()));
    const matchesType = typeFilter === 'all' || f.type === typeFilter;
    const matchesProject = selectedProject === 'all' || f.projectId === selectedProject;
    return matchesSearch && matchesType && matchesProject;
  });

  const handleUploadSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!uploadName.trim()) return;
    const ext = uploadName.split('.').pop()?.toLowerCase() || 'pdf';
    uploadFile({
      projectId: uploadProjectId,
      projectName: projects.find(p => p.id === uploadProjectId)?.name || 'General',
      name: uploadName.includes('.') ? uploadName : `${uploadName}.pdf`,
      size: uploadSize,
      type: ext === 'fig' ? 'fig' : 'pdf',
      uploadedBy: userProfile.name
    });
    showToast('File Uploaded', `Successfully indexed "${uploadName}" to project storage.`, 'success');
    setIsUploadOpen(false);
    setUploadName('');
  };

  const handleDownload = (file: ProjectFile) => {
    showToast('Download Initiated', `Downloading ${file.name} (${file.size})...`, 'info');
  };

  return (
    <div className="space-y-6 animate-fade-in pb-16">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-white flex items-center gap-2.5">
            <FileText className="w-6 h-6 text-amber-400" />
            File & Document Management
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Centralized assets with multi-cloud storage drivers (Firebase / Supabase Storage / Google Drive).
          </p>
        </div>

        <button
          onClick={() => setIsUploadOpen(true)}
          className="flex items-center gap-2 px-4 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold rounded-xl shadow-lg shadow-indigo-950/40 transition-all self-start sm:self-auto"
        >
          <UploadCloud className="w-4 h-4" />
          Upload Document
        </button>
      </div>

      {/* Cloud Architecture Provider Strip */}
      <div className="bg-[#111827] border border-slate-800 rounded-2xl p-4 flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-3">
          <HardDrive className="w-4 h-4 text-indigo-400" />
          <span className="font-semibold text-slate-200">Active Storage Provider:</span>
          <span className="text-slate-400">Firebase Cloud Storage (Primary) • Supabase S3 (Failover)</span>
        </div>
        <div className="flex items-center gap-2 text-[11px] text-slate-500">
          <span className="w-2 h-2 rounded-full bg-emerald-500 inline-block" />
          <span>Object Versioning Enabled</span>
        </div>
      </div>

      {/* Search & Filter Bar */}
      <div className="bg-[#111827] border border-slate-800 rounded-2xl p-4 flex flex-col md:flex-row items-center justify-between gap-3">
        <div className="relative w-full md:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="text"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder="Search files by name..."
            className="w-full pl-9 pr-3 py-1.5 bg-slate-900 border border-slate-700 rounded-xl text-xs text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-indigo-500"
          />
        </div>

        <div className="flex flex-wrap items-center gap-2 w-full md:w-auto text-xs">
          <div className="flex items-center gap-1.5">
            <span className="text-slate-400">Project:</span>
            <select
              value={selectedProject}
              onChange={e => setSelectedProject(e.target.value)}
              className="px-2.5 py-1.5 bg-slate-900 border border-slate-700 rounded-xl text-slate-200 focus:outline-none"
            >
              <option value="all">All Projects</option>
              {projects.map(p => (
                <option key={p.id} value={p.id}>{p.name}</option>
              ))}
            </select>
          </div>

          <div className="flex items-center gap-1.5">
            <span className="text-slate-400">Type:</span>
            <select
              value={typeFilter}
              onChange={e => setTypeFilter(e.target.value)}
              className="px-2.5 py-1.5 bg-slate-900 border border-slate-700 rounded-xl text-slate-200 focus:outline-none"
            >
              <option value="all">All Types</option>
              <option value="pdf">PDF Documents</option>
              <option value="fig">Figma UI Assets</option>
              <option value="doc">Word / Text</option>
            </select>
          </div>
        </div>
      </div>

      {/* Files Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredFiles.map(file => (
          <div
            key={file.id}
            className="bg-[#111827] border border-slate-800 hover:border-slate-700 rounded-2xl p-5 shadow-sm space-y-4 flex flex-col justify-between transition-colors group"
          >
            <div className="space-y-3">
              <div className="flex items-start justify-between gap-2">
                <div className="flex items-center gap-3">
                  <div className={`w-10 h-10 rounded-xl flex items-center justify-center font-bold text-xs uppercase border ${
                    file.type === 'fig'
                      ? 'bg-purple-950/60 border-purple-500/30 text-purple-300'
                      : 'bg-indigo-950/60 border-indigo-500/30 text-indigo-300'
                  }`}>
                    {file.type}
                  </div>
                  <div>
                    <h3 className="font-bold text-slate-100 text-xs truncate max-w-[170px]" title={file.name}>
                      {file.name}
                    </h3>
                    <span className="text-[11px] text-slate-400 block">{file.size}</span>
                  </div>
                </div>
              </div>

              <div className="text-xs text-slate-400 space-y-1 pt-1">
                <div>Project: <strong className="text-slate-300">{file.projectName}</strong></div>
                <div>Uploaded by: <span className="text-slate-300">{file.uploadedBy}</span></div>
                <div className="text-[11px] text-slate-500">{file.uploadedAt}</div>
              </div>
            </div>

            {/* Actions */}
            <div className="pt-3 border-t border-slate-800 flex items-center justify-between text-xs">
              <button
                onClick={() => setPreviewingFile(file)}
                className="flex items-center gap-1 text-slate-400 hover:text-white transition-colors"
              >
                <Eye className="w-3.5 h-3.5" /> Preview
              </button>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => handleDownload(file)}
                  className="p-1.5 text-slate-400 hover:text-indigo-400 rounded-lg hover:bg-slate-800 transition-colors"
                  title="Download"
                >
                  <Download className="w-4 h-4" />
                </button>
                <button
                  onClick={() => deleteFile(file.id)}
                  className="p-1.5 text-slate-500 hover:text-rose-400 rounded-lg hover:bg-slate-800 transition-colors"
                  title="Delete"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Upload File Modal */}
      {isUploadOpen && (
        <Modal
          isOpen={true}
          onClose={() => setIsUploadOpen(false)}
          title="Upload Project Deliverable"
          subtitle="Cloud-replicated storage with access controls"
        >
          <form onSubmit={handleUploadSubmit} className="space-y-4 text-xs">
            <div>
              <label className="block text-slate-300 mb-1 font-semibold uppercase text-[10px]">
                File Name *
              </label>
              <input
                type="text"
                required
                value={uploadName}
                onChange={e => setUploadName(e.target.value)}
                placeholder="e.g. Architecture_Benchmark_Report.pdf"
                className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-slate-100 focus:outline-none focus:border-indigo-500"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-slate-300 mb-1 font-semibold uppercase text-[10px]">
                  Associated Project
                </label>
                <select
                  value={uploadProjectId}
                  onChange={e => setUploadProjectId(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-slate-100 focus:outline-none focus:border-indigo-500"
                >
                  {projects.map(p => (
                    <option key={p.id} value={p.id}>{p.name}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-slate-300 mb-1 font-semibold uppercase text-[10px]">
                  Estimated Size
                </label>
                <input
                  type="text"
                  value={uploadSize}
                  onChange={e => setUploadSize(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-slate-100 focus:outline-none focus:border-indigo-500"
                />
              </div>
            </div>

            <div className="p-4 border-2 border-dashed border-slate-700 rounded-xl text-center text-slate-400 bg-slate-900/40">
              Drop file here or browse from local disk
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setIsUploadOpen(false)}
                className="px-4 py-2 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-semibold rounded-xl"
              >
                Upload File
              </button>
            </div>
          </form>
        </Modal>
      )}

      {/* File Preview Modal */}
      {previewingFile && (
        <Modal
          isOpen={true}
          onClose={() => setPreviewingFile(null)}
          title={`Document Preview: ${previewingFile.name}`}
          subtitle={`${previewingFile.size} • Uploaded by ${previewingFile.uploadedBy}`}
          size="lg"
        >
          <div className="p-6 bg-slate-950 rounded-xl border border-slate-800 space-y-4 text-xs font-mono text-slate-300">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2 text-[11px] text-slate-400">
              <span>MIME: application/octet-stream</span>
              <span>SHA-256: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855</span>
            </div>
            <p>
              [FILE CONTENT PREVIEW: {previewingFile.name}]
            </p>
            <p className="text-slate-400">
              This document is indexed in the TASKNOVA project repository under project workspace "{previewingFile.projectName}".
              Integrations with Firebase Storage and Google Drive API allow instant direct viewing, cryptographic verification, and version rollbacks.
            </p>
            <div className="pt-4 flex justify-end">
              <button
                onClick={() => {
                  handleDownload(previewingFile);
                  setPreviewingFile(null);
                }}
                className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-sans font-semibold rounded-xl text-xs flex items-center gap-1.5"
              >
                <Download className="w-3.5 h-3.5" /> Download Full Document
              </button>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
};
