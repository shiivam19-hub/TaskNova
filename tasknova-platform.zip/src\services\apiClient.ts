/**
 * TASKNOVA API Client
 * Seamlessly interfaces the frontend UI with the Node.js/Express Prisma backend.
 */

const API_BASE_URL = '/api';

class ApiClient {
  private tokenKey = 'tasknova_auth_token';

  public getToken(): string | null {
    try {
      return localStorage.getItem(this.tokenKey);
    } catch {
      return null;
    }
  }

  public setToken(token: string): void {
    try {
      localStorage.setItem(this.tokenKey, token);
    } catch (e) {
      console.warn('Failed to persist token to localStorage', e);
    }
  }

  public clearToken(): void {
    try {
      localStorage.removeItem(this.tokenKey);
    } catch (e) {
      console.warn('Failed to clear token', e);
    }
  }

  private async request<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
    const token = this.getToken();
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
      ...(options.headers as Record<string, string> || {})
    };

    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }

    const response = await fetch(`${API_BASE_URL}${endpoint}`, {
      ...options,
      headers
    });

    if (!response.ok) {
      let errorMsg = `API Error ${response.status}`;
      try {
        const errorData = await response.json();
        errorMsg = errorData.error || errorData.message || errorMsg;
      } catch {
        // non-json response
      }
      throw new Error(errorMsg);
    }

    return response.json();
  }

  // AUTHENTICATION
  public auth = {
    login: async (email: string, password: string) => {
      const res = await this.request<{ token: string; user: any }>('/auth/login', {
        method: 'POST',
        body: JSON.stringify({ email, password })
      });
      if (res.token) {
        this.setToken(res.token);
      }
      return res;
    },
    signup: async (data: { name: string; email: string; password: string; role?: string }) => {
      const res = await this.request<{ token: string; user: any }>('/auth/signup', {
        method: 'POST',
        body: JSON.stringify(data)
      });
      if (res.token) {
        this.setToken(res.token);
      }
      return res;
    },
    getMe: () => this.request<{ user: any }>('/auth/me'),
    updateProfile: (data: any) => this.request<any>('/auth/profile', { method: 'PATCH', body: JSON.stringify(data) }),
    logout: () => {
      this.clearToken();
      return Promise.resolve();
    }
  };

  // PROJECTS
  public projects = {
    list: (query?: string) => this.request<any[]>(`/projects${query ? `?${query}` : ''}`),
    get: (id: string) => this.request<any>(`/projects/${id}`),
    create: (data: any) => this.request<any>('/projects', { method: 'POST', body: JSON.stringify(data) }),
    update: (id: string, data: any) => this.request<any>(`/projects/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
    delete: (id: string) => this.request<any>(`/projects/${id}`, { method: 'DELETE' })
  };

  // TASKS
  public tasks = {
    list: (params?: { projectId?: string; status?: string; search?: string }) => {
      const qs = new URLSearchParams(params as any).toString();
      return this.request<any[]>(`/tasks${qs ? `?${qs}` : ''}`);
    },
    create: (data: any) => this.request<any>('/tasks', { method: 'POST', body: JSON.stringify(data) }),
    update: (id: string, data: any) => this.request<any>(`/tasks/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
    updateStatus: (id: string, status: string) =>
      this.request<any>(`/tasks/${id}/status`, { method: 'PATCH', body: JSON.stringify({ status }) }),
    delete: (id: string) => this.request<any>(`/tasks/${id}`, { method: 'DELETE' })
  };

  // TODOS (Personal checklist)
  public todos = {
    list: (category?: string) => this.request<any[]>(`/todos${category ? `?category=${category}` : ''}`),
    create: (data: any) => this.request<any>('/todos', { method: 'POST', body: JSON.stringify(data) }),
    toggle: (id: string) => this.request<any>(`/todos/${id}/toggle`, { method: 'PATCH' }),
    delete: (id: string) => this.request<any>(`/todos/${id}`, { method: 'DELETE' })
  };

  // TEAM
  public team = {
    list: () => this.request<any[]>('/team'),
    invite: (data: any) => this.request<any>('/team/invite', { method: 'POST', body: JSON.stringify(data) }),
    updateRole: (id: string, role: string, roleType: string) =>
      this.request<any>(`/team/${id}/role`, { method: 'PATCH', body: JSON.stringify({ role, roleType }) }),
    remove: (id: string) => this.request<any>(`/team/${id}`, { method: 'DELETE' })
  };

  // COMMENTS & DISCUSSIONS
  public comments = {
    list: (projectId: string) => this.request<any[]>(`/comments?projectId=${projectId}`),
    create: (data: { projectId: string; content: string; pinned?: boolean; attachments?: string[] }) =>
      this.request<any>('/comments', { method: 'POST', body: JSON.stringify(data) }),
    reply: (id: string, content: string) =>
      this.request<any>(`/comments/${id}/reply`, { method: 'POST', body: JSON.stringify({ content }) }),
    toggleReaction: (id: string, emoji: string) =>
      this.request<any>(`/comments/${id}/reaction`, { method: 'POST', body: JSON.stringify({ emoji }) })
  };

  // ACTIVITY LOGS
  public activity = {
    list: (limit = 20, projectId?: string) =>
      this.request<any[]>(`/activity?limit=${limit}${projectId ? `&projectId=${projectId}` : ''}`)
  };

  // NOTIFICATIONS
  public notifications = {
    list: () => this.request<{ notifications: any[]; unreadCount: number }>('/notifications'),
    markRead: (id: string) => this.request<any>(`/notifications/${id}/read`, { method: 'PATCH' }),
    markAllRead: () => this.request<any>('/notifications/read-all', { method: 'PATCH' })
  };

  // CALENDAR
  public calendar = {
    list: (month?: string) => this.request<any[]>(`/calendar${month ? `?month=${month}` : ''}`),
    create: (data: any) => this.request<any>('/calendar', { method: 'POST', body: JSON.stringify(data) }),
    syncGoogle: () => this.request<any>('/calendar/sync-google', { method: 'POST' })
  };

  // STUDY HUB & RESEARCH
  public study = {
    getGoals: () => this.request<any[]>('/study/goals'),
    createGoal: (data: any) => this.request<any>('/study/goals', { method: 'POST', body: JSON.stringify(data) }),
    toggleGoal: (id: string) => this.request<any>(`/study/goals/${id}/toggle`, { method: 'PATCH' }),
    deleteGoal: (id: string) => this.request<any>(`/study/goals/${id}`, { method: 'DELETE' }),
    getPlans: () => this.request<any[]>('/study/plans'),
    createPlan: (data: any) => this.request<any>('/study/plans', { method: 'POST', body: JSON.stringify(data) }),
    getResources: () => this.request<any[]>('/study/resources'),
    saveResource: (data: any) => this.request<any>('/study/resources', { method: 'POST', body: JSON.stringify(data) }),
    deleteResource: (id: string) => this.request<any>(`/study/resources/${id}`, { method: 'DELETE' }),
    searchBooks: (query: string) => this.request<any[]>(`/study/search/books?q=${encodeURIComponent(query)}`),
    searchPapers: (query: string) => this.request<any[]>(`/study/search/papers?q=${encodeURIComponent(query)}`),
    searchVideos: (query: string) => this.request<any[]>(`/study/search/videos?q=${encodeURIComponent(query)}`),
    getWeather: () => this.request<any>('/study/environment/weather'),
    getFocusSessions: () => this.request<any>('/study/focus-sessions'),
    logFocusSession: (data: { durationMins: number; mode?: string; tasksResolved?: number }) =>
      this.request<any>('/study/focus-sessions', { method: 'POST', body: JSON.stringify(data) })
  };

  // AI INTELLIGENCE
  public ai = {
    chat: (message: string, conversationId?: string) =>
      this.request<{ conversationId: string; reply: string }>('/ai/chat', {
        method: 'POST',
        body: JSON.stringify({ message, conversationId })
      }),
    projectPlan: (data: { title: string; goal?: string; techStack?: string; timeline?: string }) =>
      this.request<any>('/ai/project-plan', { method: 'POST', body: JSON.stringify(data) }),
    createTasksFromPlan: (projectId: string, tasks: any[]) =>
      this.request<{ message: string; tasks: any[] }>('/ai/create-tasks-from-plan', {
        method: 'POST',
        body: JSON.stringify({ projectId, tasks })
      }),
    studyPlan: (data: { subject: string; examDate: string; availableHoursPerDay?: number; weakAreas?: string[] }) =>
      this.request<any>('/ai/study-plan', { method: 'POST', body: JSON.stringify(data) }),
    quiz: (topic: string, questionCount = 5) =>
      this.request<any>('/ai/quiz', { method: 'POST', body: JSON.stringify({ topic, questionCount }) }),
    dailyBriefing: () => this.request<any>('/ai/daily-briefing'),
    riskAnalysis: (projectId: string) =>
      this.request<any>('/ai/risk-analysis', { method: 'POST', body: JSON.stringify({ projectId }) }),
    summarize: (text: string, type = 'document') =>
      this.request<{ summary: string }>('/ai/summarize', { method: 'POST', body: JSON.stringify({ text, type }) })
  };

  // PRIVACY & SETTINGS
  public privacy = {
    getSettings: () => this.request<any>('/privacy'),
    updateSettings: (data: any) => this.request<any>('/privacy', { method: 'PUT', body: JSON.stringify(data) }),
    getSecurityEvents: () => this.request<any[]>('/privacy/security-events'),
    exportData: () => this.request<any>('/privacy/export-data')
  };
}

export const apiClient = new ApiClient();
