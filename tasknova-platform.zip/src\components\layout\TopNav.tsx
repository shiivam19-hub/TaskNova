import React, { useState, useEffect, useRef } from 'react';
import {
  Search,
  Bell,
  HelpCircle,
  Settings,
  CloudSun,
  MapPin,
  Clock,
  CheckCheck,
  ExternalLink,
  Filter,
  CheckCircle2,
  FileText,
  BookOpen,
  User,
  FolderKanban,
  CheckSquare,
  X
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { Avatar } from '../common/Avatar';
import { fetchCampusWeather, WeatherData } from '../../services/apiArchitecture';

interface TopNavProps {
  onToggleSidebar?: () => void;
}

export const TopNav: React.FC<TopNavProps> = () => {
  const {
    activeTab,
    setActiveTab,
    userProfile,
    updateUserProfile,
    notifications,
    markNotificationAsRead,
    markAllNotificationsAsRead,
    projects,
    tasks,
    teamMembers,
    files,
    studyResources,
    openProjectDetails,
    setIsHelpModalOpen
  } = useApp();

  // Dynamic live clock
  const [currentTimeStr, setCurrentTimeStr] = useState('');

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      // Format: Friday, September 11, 2026 • 11:47 AM
      const options: Intl.DateTimeFormatOptions = {
        weekday: 'long',
        year: 'numeric',
        month: 'long',
        day: 'numeric',
        hour: 'numeric',
        minute: '2-digit',
        hour12: true
      };
      const formatted = now.toLocaleDateString('en-US', options);
      // Clean up string representation
      // "Friday, September 11, 2026 at 11:47 AM" -> "Friday, September 11, 2026 • 11:47 AM"
      setCurrentTimeStr(formatted.replace(' at ', ' • '));
    };

    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  // Weather state
  const [weatherCity, setWeatherCity] = useState('Patna');
  const [weather, setWeather] = useState<WeatherData | null>(null);
  const [isWeatherOpen, setIsWeatherOpen] = useState(false);

  useEffect(() => {
    fetchCampusWeather(weatherCity).then(setWeather);
  }, [weatherCity]);

  // Global search state
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [searchFilter, setSearchFilter] = useState<'all' | 'projects' | 'tasks' | 'people' | 'files' | 'study'>('all');
  const searchContainerRef = useRef<HTMLDivElement>(null);

  // Notification dropdown state
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);
  const [isProfileMenuOpen, setIsProfileMenuOpen] = useState(false);

  const unreadCount = notifications.filter(n => !n.read).length;

  // Keyboard shortcut for search (Ctrl+K or ⌘K)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setIsSearchOpen(true);
      }
      if (e.key === 'Escape') {
        setIsSearchOpen(false);
        setIsNotificationsOpen(false);
        setIsProfileMenuOpen(false);
        setIsWeatherOpen(false);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Filtered search results grouped
  const q = searchQuery.trim().toLowerCase();
  const matchedProjects = q ? projects.filter(p => p.name.toLowerCase().includes(q) || p.description.toLowerCase().includes(q)) : [];
  const matchedTasks = q ? tasks.filter(t => t.title.toLowerCase().includes(q) || (t.description && t.description.toLowerCase().includes(q))) : [];
  const matchedPeople = q ? teamMembers.filter(m => m.name.toLowerCase().includes(q) || m.role.toLowerCase().includes(q) || m.department.toLowerCase().includes(q)) : [];
  const matchedFiles = q ? files.filter(f => f.name.toLowerCase().includes(q)) : [];
  const matchedStudy = q ? studyResources.filter(s => s.title.toLowerCase().includes(q) || s.authorsOrChannel.toLowerCase().includes(q)) : [];

  const totalResultsCount =
    (searchFilter === 'all' || searchFilter === 'projects' ? matchedProjects.length : 0) +
    (searchFilter === 'all' || searchFilter === 'tasks' ? matchedTasks.length : 0) +
    (searchFilter === 'all' || searchFilter === 'people' ? matchedPeople.length : 0) +
    (searchFilter === 'all' || searchFilter === 'files' ? matchedFiles.length : 0) +
    (searchFilter === 'all' || searchFilter === 'study' ? matchedStudy.length : 0);

  return (
    <header className="h-16 shrink-0 bg-[#0f172a]/95 border-b border-slate-800/80 px-4 sm:px-6 flex items-center justify-between gap-4 z-20">
      {/* Left Area: Global Search Input */}
      <div className="flex-1 max-w-xl relative" ref={searchContainerRef}>
        <div className="relative flex items-center">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 pointer-events-none" />
          <input
            type="text"
            value={searchQuery}
            onChange={e => {
              setSearchQuery(e.target.value);
              setIsSearchOpen(true);
            }}
            onFocus={() => setIsSearchOpen(true)}
            placeholder="Search projects, tasks, people, files, study resources... (Ctrl+K)"
            className="w-full pl-10 pr-20 py-2 bg-slate-900/90 border border-slate-700/80 hover:border-slate-600 focus:border-indigo-500 rounded-xl text-xs sm:text-sm text-slate-100 placeholder:text-slate-400 focus:outline-none focus:ring-1 focus:ring-indigo-500 transition-all shadow-inner"
          />
          <div className="absolute right-2.5 flex items-center gap-1.5 pointer-events-none">
            {searchQuery ? (
              <button
                type="button"
                onClick={() => setSearchQuery('')}
                className="pointer-events-auto p-1 text-slate-400 hover:text-white"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            ) : (
              <kbd className="hidden sm:inline-block px-1.5 py-0.5 text-[10px] font-mono text-slate-400 bg-slate-800 border border-slate-700 rounded shadow-xs">
                ⌘K
              </kbd>
            )}
          </div>
        </div>

        {/* Search Results Dropdown Overlay */}
        {isSearchOpen && searchQuery.trim().length > 0 && (
          <>
            <div
              className="fixed inset-0 z-40"
              onClick={() => setIsSearchOpen(false)}
            />
            <div className="absolute left-0 top-full mt-2 w-full max-h-[75vh] bg-[#161f30] border border-slate-700/90 rounded-2xl shadow-2xl z-50 overflow-hidden flex flex-col animate-pop-in">
              {/* Filter chips */}
              <div className="flex items-center gap-1.5 p-2.5 border-b border-slate-800 bg-slate-900/60 overflow-x-auto text-[11px]">
                <Filter className="w-3.5 h-3.5 text-slate-400 ml-1 mr-0.5 shrink-0" />
                {(['all', 'projects', 'tasks', 'people', 'files', 'study'] as const).map(f => (
                  <button
                    key={f}
                    onClick={() => setSearchFilter(f)}
                    className={`px-2.5 py-1 rounded-lg capitalize transition-colors shrink-0 ${
                      searchFilter === f
                        ? 'bg-indigo-600 text-white font-medium'
                        : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
                    }`}
                  >
                    {f}
                  </button>
                ))}
              </div>

              {/* Grouped results view */}
              <div className="flex-1 overflow-y-auto p-2 divide-y divide-slate-800/60 text-xs">
                {totalResultsCount === 0 ? (
                  <div className="py-8 text-center text-slate-400">
                    <p className="font-medium text-slate-300">No matching results found</p>
                    <p className="text-[11px] mt-1">Try querying a different task, author, or keyword.</p>
                  </div>
                ) : (
                  <>
                    {/* Projects */}
                    {(searchFilter === 'all' || searchFilter === 'projects') && matchedProjects.length > 0 && (
                      <div className="py-2">
                        <div className="px-3 py-1 text-[10px] font-semibold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                          <FolderKanban className="w-3 h-3 text-indigo-400" /> Projects ({matchedProjects.length})
                        </div>
                        {matchedProjects.map(p => (
                          <div
                            key={p.id}
                            onClick={() => {
                              openProjectDetails(p.id);
                              setIsSearchOpen(false);
                            }}
                            className="px-3 py-2 rounded-xl hover:bg-slate-800/70 cursor-pointer flex items-center justify-between transition-colors"
                          >
                            <div>
                              <span className="font-medium text-slate-200">{p.name}</span>
                              <p className="text-[11px] text-slate-400 line-clamp-1">{p.description}</p>
                            </div>
                            <span className="text-[10px] px-2 py-0.5 rounded-full bg-indigo-950 text-indigo-300 border border-indigo-500/20">
                              {p.progress}%
                            </span>
                          </div>
                        ))}
                      </div>
                    )}

                    {/* Tasks */}
                    {(searchFilter === 'all' || searchFilter === 'tasks') && matchedTasks.length > 0 && (
                      <div className="py-2">
                        <div className="px-3 py-1 text-[10px] font-semibold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                          <CheckSquare className="w-3 h-3 text-cyan-400" /> Tasks ({matchedTasks.length})
                        </div>
                        {matchedTasks.map(t => (
                          <div
                            key={t.id}
                            onClick={() => {
                              setActiveTab('tasks');
                              setIsSearchOpen(false);
                            }}
                            className="px-3 py-2 rounded-xl hover:bg-slate-800/70 cursor-pointer flex items-center justify-between transition-colors"
                          >
                            <div>
                              <span className="font-medium text-slate-200">{t.title}</span>
                              <p className="text-[11px] text-slate-400">{t.projectName} • Assigned to {t.assignee.name}</p>
                            </div>
                            <span className={`text-[10px] font-medium px-2 py-0.5 rounded ${
                              t.priority === 'High' || t.priority === 'Urgent'
                                ? 'bg-rose-950 text-rose-300'
                                : 'bg-slate-800 text-slate-300'
                            }`}>
                              {t.priority}
                            </span>
                          </div>
                        ))}
                      </div>
                    )}

                    {/* People */}
                    {(searchFilter === 'all' || searchFilter === 'people') && matchedPeople.length > 0 && (
                      <div className="py-2">
                        <div className="px-3 py-1 text-[10px] font-semibold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                          <User className="w-3 h-3 text-emerald-400" /> People ({matchedPeople.length})
                        </div>
                        {matchedPeople.map(m => (
                          <div
                            key={m.id}
                            onClick={() => {
                              setActiveTab('team');
                              setIsSearchOpen(false);
                            }}
                            className="px-3 py-2 rounded-xl hover:bg-slate-800/70 cursor-pointer flex items-center gap-3 transition-colors"
                          >
                            <Avatar name={m.name} initials={m.initials} size="sm" status={m.status} showStatus />
                            <div>
                              <span className="font-medium text-slate-200">{m.name}</span>
                              <p className="text-[11px] text-slate-400">{m.role} • {m.department}</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}

                    {/* Files */}
                    {(searchFilter === 'all' || searchFilter === 'files') && matchedFiles.length > 0 && (
                      <div className="py-2">
                        <div className="px-3 py-1 text-[10px] font-semibold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                          <FileText className="w-3 h-3 text-amber-400" /> Files ({matchedFiles.length})
                        </div>
                        {matchedFiles.map(f => (
                          <div
                            key={f.id}
                            onClick={() => {
                              setActiveTab('files');
                              setIsSearchOpen(false);
                            }}
                            className="px-3 py-2 rounded-xl hover:bg-slate-800/70 cursor-pointer flex items-center justify-between transition-colors"
                          >
                            <div>
                              <span className="font-medium text-slate-200">{f.name}</span>
                              <p className="text-[11px] text-slate-400">{f.projectName} • {f.size}</p>
                            </div>
                            <span className="text-[10px] text-slate-400">{f.uploadedAt}</span>
                          </div>
                        ))}
                      </div>
                    )}

                    {/* Study Resources */}
                    {(searchFilter === 'all' || searchFilter === 'study') && matchedStudy.length > 0 && (
                      <div className="py-2">
                        <div className="px-3 py-1 text-[10px] font-semibold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                          <BookOpen className="w-3 h-3 text-purple-400" /> Study Resources ({matchedStudy.length})
                        </div>
                        {matchedStudy.map(s => (
                          <div
                            key={s.id}
                            onClick={() => {
                              setActiveTab('study-hub');
                              setIsSearchOpen(false);
                            }}
                            className="px-3 py-2 rounded-xl hover:bg-slate-800/70 cursor-pointer flex items-center justify-between transition-colors"
                          >
                            <div>
                              <span className="font-medium text-slate-200">{s.title}</span>
                              <p className="text-[11px] text-slate-400">{s.authorsOrChannel} • {s.source}</p>
                            </div>
                            <span className="text-[10px] uppercase font-semibold text-indigo-400">{s.type}</span>
                          </div>
                        ))}
                      </div>
                    )}
                  </>
                )}
              </div>
            </div>
          </>
        )}
      </div>

      {/* Right Area: Dynamic Time, Weather, Notification Bell, Help, Quick Settings, User Profile */}
      <div className="flex items-center gap-2 sm:gap-3 shrink-0">
        {/* Live Dynamic Date + Time */}
        <div className="hidden xl:flex items-center gap-2 px-3 py-1.5 rounded-xl bg-slate-900/80 border border-slate-800 text-xs text-slate-300 shadow-inner">
          <Clock className="w-3.5 h-3.5 text-indigo-400" />
          <span className="font-medium tracking-tight whitespace-nowrap">{currentTimeStr}</span>
        </div>

        {/* Campus Weather Widget with location modal trigger */}
        <div className="relative">
          <button
            onClick={() => setIsWeatherOpen(prev => !prev)}
            className="flex items-center gap-2 px-2.5 py-1.5 rounded-xl bg-slate-900/80 border border-slate-800 hover:border-slate-700 text-xs text-slate-300 transition-colors"
            title="Campus Weather & Study Context"
          >
            <CloudSun className="w-4 h-4 text-amber-400 shrink-0" />
            <span className="hidden md:inline font-medium">
              {weather ? `${weather.temperature}°C ${weather.city}` : '28°C Patna'}
            </span>
          </button>

          {/* Weather Details Popover */}
          {isWeatherOpen && (
            <>
              <div className="fixed inset-0 z-40" onClick={() => setIsWeatherOpen(false)} />
              <div className="absolute right-0 top-full mt-2 w-72 bg-[#161f30] border border-slate-700/80 rounded-2xl shadow-2xl z-50 p-4 animate-pop-in">
                <div className="flex items-center justify-between border-b border-slate-800 pb-2 mb-3">
                  <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-200">
                    <MapPin className="w-3.5 h-3.5 text-indigo-400" />
                    Campus Context
                  </div>
                  <span className="text-[10px] text-slate-400">Open-Meteo API</span>
                </div>

                <div className="flex items-center justify-between mb-3">
                  <div>
                    <div className="text-2xl font-bold text-white">{weather?.temperature || 28}°C</div>
                    <div className="text-xs text-slate-400">{weather?.condition || 'Sunny & Clear'}</div>
                  </div>
                  <CloudSun className="w-10 h-10 text-amber-400" />
                </div>

                <div className="p-2.5 rounded-xl bg-indigo-950/40 border border-indigo-500/20 text-xs text-indigo-200 mb-3">
                  "{weather?.recommendation || 'Good weather for a study session ☀️'}"
                </div>

                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    value={weatherCity}
                    onChange={e => setWeatherCity(e.target.value)}
                    placeholder="Change campus city..."
                    className="flex-1 px-2.5 py-1.5 bg-slate-900 border border-slate-700 rounded-lg text-xs text-slate-200 focus:outline-none focus:border-indigo-500"
                  />
                  <button
                    onClick={() => {
                      fetchCampusWeather(weatherCity).then(setWeather);
                      setIsWeatherOpen(false);
                    }}
                    className="px-2.5 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-medium"
                  >
                    Set
                  </button>
                </div>
              </div>
            </>
          )}
        </div>

        {/* Notification Bell with interactive dropdown */}
        <div className="relative">
          <button
            onClick={() => setIsNotificationsOpen(prev => !prev)}
            className="p-2 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800/80 transition-colors relative"
            title="Notifications"
            aria-label="Notifications"
          >
            <Bell className="w-5 h-5" />
            {unreadCount > 0 && (
              <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-rose-500 ring-2 ring-slate-900" />
            )}
          </button>

          {isNotificationsOpen && (
            <>
              <div className="fixed inset-0 z-40" onClick={() => setIsNotificationsOpen(false)} />
              <div className="absolute right-0 top-full mt-2 w-80 sm:w-96 bg-[#161f30] border border-slate-700/80 rounded-2xl shadow-2xl z-50 overflow-hidden animate-pop-in">
                <div className="flex items-center justify-between px-4 py-3 border-b border-slate-800 bg-slate-900/60">
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-semibold text-slate-100">Notifications</span>
                    {unreadCount > 0 && (
                      <span className="text-[10px] font-bold px-1.5 py-0.5 rounded-full bg-rose-500/20 text-rose-300 border border-rose-500/30">
                        {unreadCount} new
                      </span>
                    )}
                  </div>
                  {unreadCount > 0 && (
                    <button
                      onClick={markAllNotificationsAsRead}
                      className="text-xs text-indigo-400 hover:text-indigo-300 flex items-center gap-1 font-medium"
                    >
                      <CheckCheck className="w-3.5 h-3.5" />
                      Mark all read
                    </button>
                  )}
                </div>

                <div className="max-h-80 overflow-y-auto divide-y divide-slate-800/60 text-xs">
                  {notifications.length === 0 ? (
                    <div className="py-8 text-center text-slate-400">
                      You're all caught up! 🎉
                    </div>
                  ) : (
                    notifications.map(n => (
                      <div
                        key={n.id}
                        onClick={() => {
                          markNotificationAsRead(n.id);
                          if (n.linkTo) setActiveTab(n.linkTo as any);
                          setIsNotificationsOpen(false);
                        }}
                        className={`p-3.5 hover:bg-slate-800/60 cursor-pointer flex items-start gap-3 transition-colors ${
                          !n.read ? 'bg-indigo-950/20' : ''
                        }`}
                      >
                        <div className="shrink-0 mt-0.5">
                          {n.type === 'deadline' && <span className="w-2.5 h-2.5 rounded-full bg-amber-400 block" />}
                          {n.type === 'comment' && <span className="w-2.5 h-2.5 rounded-full bg-cyan-400 block" />}
                          {n.type === 'file' && <span className="w-2.5 h-2.5 rounded-full bg-blue-400 block" />}
                          {n.type === 'assignment' && <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 block" />}
                          {n.type === 'security' && <span className="w-2.5 h-2.5 rounded-full bg-rose-400 block" />}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between">
                            <span className="font-semibold text-slate-200">{n.title}</span>
                            <span className="text-[10px] text-slate-400">{n.timestamp}</span>
                          </div>
                          <p className="text-slate-300 text-[11px] mt-0.5 line-clamp-2">{n.message}</p>
                        </div>
                      </div>
                    ))
                  )}
                </div>

                <div className="p-2.5 border-t border-slate-800 bg-slate-900/60 text-center">
                  <button
                    onClick={() => {
                      setActiveTab('notifications');
                      setIsNotificationsOpen(false);
                    }}
                    className="text-xs font-medium text-indigo-400 hover:text-indigo-300"
                  >
                    View All Notifications
                  </button>
                </div>
              </div>
            </>
          )}
        </div>

        {/* Help Button */}
        <button
          onClick={() => setIsHelpModalOpen(true)}
          className="p-2 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800/80 transition-colors hidden sm:inline-flex"
          title="Help & Documentation"
          aria-label="Help"
        >
          <HelpCircle className="w-5 h-5" />
        </button>

        {/* Quick Settings Button */}
        <button
          onClick={() => setActiveTab('settings')}
          className="p-2 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800/80 transition-colors"
          title="Quick Settings"
          aria-label="Quick Settings"
        >
          <Settings className="w-5 h-5" />
        </button>

        {/* User Profile Avatar with dropdown status toggle */}
        <div className="relative pl-1">
          <button
            onClick={() => setIsProfileMenuOpen(prev => !prev)}
            className="flex items-center gap-2 p-1 rounded-xl hover:bg-slate-800/60 transition-colors"
          >
            <Avatar
              name={userProfile.name}
              initials={userProfile.avatarInitials}
              size="sm"
              status={userProfile.status}
              showStatus={true}
            />
          </button>

          {isProfileMenuOpen && (
            <>
              <div className="fixed inset-0 z-40" onClick={() => setIsProfileMenuOpen(false)} />
              <div className="absolute right-0 top-full mt-2 w-64 bg-[#161f30] border border-slate-700/80 rounded-2xl shadow-2xl z-50 p-2 text-xs animate-pop-in">
                <div className="p-2.5 border-b border-slate-800">
                  <div className="font-semibold text-slate-100">{userProfile.name}</div>
                  <div className="text-[11px] text-slate-400 truncate">{userProfile.email}</div>
                  <div className="mt-1.5 flex items-center gap-1.5">
                    <span className="text-[10px] px-2 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                      {userProfile.roleType}
                    </span>
                    <span className="text-[10px] text-slate-400">{userProfile.role}</span>
                  </div>
                </div>

                <div className="py-2 border-b border-slate-800">
                  <div className="px-2.5 text-[10px] font-semibold text-slate-400 uppercase tracking-wider mb-1">
                    Presence Status
                  </div>
                  {(['online', 'busy', 'away', 'offline'] as const).map(st => (
                    <button
                      key={st}
                      onClick={() => {
                        updateUserProfile({ status: st });
                        setIsProfileMenuOpen(false);
                      }}
                      className="w-full flex items-center justify-between px-2.5 py-1.5 rounded-lg hover:bg-slate-800 capitalize text-slate-300 text-left transition-colors"
                    >
                      <span className="flex items-center gap-2">
                        <span className={`w-2 h-2 rounded-full ${
                          st === 'online' ? 'bg-emerald-500' :
                          st === 'busy' ? 'bg-rose-500' :
                          st === 'away' ? 'bg-amber-500' : 'bg-slate-500'
                        }`} />
                        {st}
                      </span>
                      {userProfile.status === st && <CheckCheck className="w-3.5 h-3.5 text-indigo-400" />}
                    </button>
                  ))}
                </div>

                <div className="pt-1.5 space-y-0.5">
                  <button
                    onClick={() => {
                      setActiveTab('settings');
                      setIsProfileMenuOpen(false);
                    }}
                    className="w-full px-2.5 py-1.5 text-left rounded-lg text-slate-300 hover:bg-slate-800 transition-colors"
                  >
                    Profile Settings
                  </button>
                  <button
                    onClick={() => {
                      setActiveTab('privacy');
                      setIsProfileMenuOpen(false);
                    }}
                    className="w-full px-2.5 py-1.5 text-left rounded-lg text-slate-300 hover:bg-slate-800 transition-colors"
                  >
                    Privacy & Security Center
                  </button>
                </div>
              </div>
            </>
          )}
        </div>
      </div>
    </header>
  );
};
