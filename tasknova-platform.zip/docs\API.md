# TASKNOVA REST API Documentation

Comprehensive specification for the TASKNOVA production backend API, including authentication schemes, request/response models, query parameters, error contracts, and external service integrations.

**Base URL**: `http://localhost:5000/api`  
**Frontend Proxy**: All `/api/*` and `/uploads/*` requests from Vite (`http://localhost:3000`) are proxied automatically to `http://localhost:5000`.

---

## 1. Authentication & Security

All protected routes require a valid JSON Web Token (JWT) supplied via the `Authorization` header:

```http
Authorization: Bearer <JWT_TOKEN>
```

### Response Codes & Error Envelope

All error responses adhere to a consistent JSON schema:

```json
{
  "error": "Descriptive error message",
  "code": "ERROR_CODE",
  "timestamp": "2026-09-11T12:00:00.000Z"
}
```

| HTTP Status | Meaning |
| :--- | :--- |
| `200 OK` | Successful retrieval, update, or deletion |
| `201 Created` | Successful resource creation |
| `400 Bad Request` | Validation failure, missing required fields |
| `401 Unauthorized` | Missing, invalid, or expired JWT |
| `403 Forbidden` | Authenticated user lacks required Role (RBAC) |
| `404 Not Found` | Target resource does not exist |
| `500 Server Error` | Unhandled backend exception |

---

## 2. Authentication Endpoints (`/api/auth`)

### `POST /api/auth/signup`
Creates a new user account with hashed password and default profile/settings.

**Request Body:**
```json
{
  "name": "SHIVAM SINGH",
  "email": "shivam.singh@tasknova.app",
  "password": "Password@123",
  "role": "Student & Project Contributor"
}
```

**Response (201 Created):**
```json
{
  "message": "User registered successfully",
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "user": {
    "id": "cuid...",
    "name": "SHIVAM SINGH",
    "email": "shivam.singh@tasknova.app",
    "role": "Student & Project Contributor",
    "roleType": "Editor"
  }
}
```

---

### `POST /api/auth/login`
Authenticates user credentials and issues a 7-day signed JWT.

**Request Body:**
```json
{
  "email": "shivam.singh@tasknova.app",
  "password": "Password@123"
}
```

**Response (200 OK):**
```json
{
  "message": "Login successful",
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "user": {
    "id": "cuid...",
    "name": "SHIVAM SINGH",
    "email": "shivam.singh@tasknova.app",
    "role": "Student & Project Contributor",
    "roleType": "Editor"
  }
}
```

---

### `GET /api/auth/me`
Fetches the profile, workspace settings, and privacy preferences for the authenticated session.

**Headers:** `Authorization: Bearer <TOKEN>`  
**Response (200 OK):** User record with profile, settings, and privacySettings relations.

---

### `PATCH /api/auth/profile`
Updates user profile fields (bio, workspace, timezone, preferences).

---

## 3. Project Management Endpoints (`/api/projects`)

### `GET /api/projects`
Retrieves all accessible projects with task counts, completed task tallies, team members, and milestones.

**Query Parameters:**
* `status` (optional): Filter by `Planning`, `In Progress`, `In Review`, `Completed`, `At Risk`.
* `category` (optional): Filter by `Engineering`, `Biotechnology`, `IoT & ML`, `Cybersecurity`, etc.
* `search` (optional): Full-text search across project title and description.

---

### `POST /api/projects`
Creates a new project and initializes permissions and activity logs.

**Request Body:**
```json
{
  "name": "Distributed Neural Cloud Engine",
  "description": "High-throughput model serving architecture",
  "category": "Engineering",
  "priority": "High",
  "deadline": "2026-10-20",
  "visibility": "Team"
}
```

---

### `PUT /api/projects/:id`
Updates existing project attributes.

### `DELETE /api/projects/:id`
Deletes a project and all associated tasks, files, and milestones (cascade deletion).

---

## 4. Task & Kanban Endpoints (`/api/tasks`)

### `GET /api/tasks`
Lists tasks with filters for Kanban column rendering.

**Query Parameters:**
* `projectId` (optional): Filter tasks belonging to a specific project.
* `status` (optional): `TO DO`, `IN PROGRESS`, `IN REVIEW`, `COMPLETED`.
* `priority` (optional): `Low`, `Medium`, `High`, `Critical`.
* `search` (optional): Text search.

---

### `POST /api/tasks`
Creates a new task. Updates the parent project's calculated progress and logs an activity event.

**Request Body:**
```json
{
  "projectId": "cuid...",
  "title": "Implement Raft Consensus State Machine",
  "description": "Formalize leader election timeout and heartbeat RPC",
  "priority": "Critical",
  "status": "IN PROGRESS",
  "assigneeName": "SHIVAM SINGH",
  "dueDate": "2026-09-22",
  "tags": ["Consensus", "Core"]
}
```

---

### `PATCH /api/tasks/:id/status` (or `PATCH /api/tasks/:id`)
Transitions a task across Kanban columns (`TO DO` -> `IN PROGRESS` -> `IN REVIEW` -> `COMPLETED`). Recalculates the parent project's completion percentage.

**Request Body:**
```json
{
  "status": "COMPLETED"
}
```

---

### `DELETE /api/tasks/:id`
Removes a task from the system and recalculates parent project progress.

---

## 5. Personal Checklist Endpoints (`/api/todos`)

* `GET /api/todos`: Returns the user's personal checklist items categorized by `Today`, `Upcoming`, `Personal`, `Study`, `Project`.
* `POST /api/todos`: Creates a checklist item.
* `PATCH /api/todos/:id/toggle`: Toggles completion status (`completed: true/false`).
* `DELETE /api/todos/:id`: Deletes a checklist item.

---

## 6. Team Collaboration Endpoints (`/api/team`)

* `GET /api/team`: Lists all active team members with department, role, productivity score, and online status.
* `POST /api/team/invite`: Invites a new member to the team.
* `PATCH /api/team/:id/role`: Modifies member role and RBAC permission level (`Owner`, `Admin`, `Editor`, `Contributor`, `Viewer`).
* `DELETE /api/team/:id`: Removes a member from the organization.

---

## 7. Comments & Discussions (`/api/comments`)

* `GET /api/comments?projectId=:id`: Fetches threaded discussions, nested replies, and emoji reactions.
* `POST /api/comments`: Posts a top-level discussion comment with optional attachments.
* `POST /api/comments/:id/reply`: Posts a threaded reply.
* `POST /api/comments/:id/reaction`: Toggles an emoji reaction (`🚀`, `🔥`, `👍`, `❤️`).
* `DELETE /api/comments/:id`: Removes a comment and nested replies.

---

## 8. AI Intelligence Endpoints (`/api/ai`)

Powered by Google Gemini models (`gemini-2.5-flash`) via the official `@google/genai` SDK, with built-in intelligent fallback for offline or unkeyed execution.

### `POST /api/ai/chat`
Multi-turn conversational assistant with memory persistence in `AIConversation` and `AIMessage`.

**Request Body:**
```json
{
  "message": "How do I implement an LRU cache with O(1) operations?",
  "conversationId": "optional-conv-id"
}
```

---

### `GET /api/ai/daily-briefing`
**"What should I work on today?" Engine**: Analyzes all active tasks, impending deadlines, and study goals, returning a prioritized action sequence tailored for **SHIVAM SINGH**.

**Response:**
```json
{
  "greeting": "HELLO, SHIVAM 👋",
  "date": "2026-09-11",
  "summaryMessage": "You have 3 active tasks and 1 study goal requiring your focus today.",
  "priorities": [
    {
      "id": "t1",
      "title": "Implement Raft Consensus State Machine",
      "type": "Task",
      "context": "Distributed Neural Cloud Engine • Priority: Critical",
      "action": "Immediate Focus"
    },
    {
      "id": "g1",
      "title": "Master Raft Consensus and Byzantine Fault Tolerance",
      "type": "Study Goal",
      "context": "Target: 2026-09-20",
      "action": "Dedicated Study Block (45 mins)"
    }
  ],
  "focusTip": "Start with your highest-priority engineering deliverable before checking email or chat notifications."
}
```

---

### `POST /api/ai/project-plan`
Generates a structured execution roadmap broken into phases, tasks with estimated hours, priorities, and risk factors.

---

### `POST /api/ai/create-tasks-from-plan`
**One-Click AI Task Import**: Persists tasks generated by the AI Project Planner directly into the database under a specified `projectId`.

**Request Body:**
```json
{
  "projectId": "cuid...",
  "tasks": [
    { "title": "Setup database schemas", "priority": "High", "estimatedHours": 6 }
  ]
}
```

---

### `POST /api/ai/quiz`
Generates 5 multiple-choice questions on any academic or technical subject with options, correct answer keys, and explanations.

---

### `POST /api/ai/risk-analysis`
Computes project velocity, critical path bottlenecks, and team bandwidth to yield an overall risk level (`Low`, `Medium`, `High`) and mitigations.

---

## 9. Academic Study Hub & External APIs (`/api/study`)

* `GET /api/study/goals`: List academic goals.
* `POST /api/study/goals`: Create a new study goal.
* `PATCH /api/study/goals/:id/toggle`: Mark goal complete.
* `GET /api/study/plans`: List study plans with day-by-day sessions.
* `POST /api/study/plans`: Generate or create a new study schedule.
* `POST /api/study/focus-sessions`: Log a Pomodoro focus sprint with duration and completed task count.
* `GET /api/study/search/books?q=:query`: Queries the **Open Library REST API** for textbooks, publications, and cover artwork.
* `GET /api/study/search/papers?q=:query`: Queries the **Crossref REST API** for peer-reviewed research papers and DOIs.
* `GET /api/study/search/videos?q=:query`: Searches university lectures and technical tutorials via **YouTube Data API** or curated library.
* `GET /api/study/environment/weather`: Fetches ambient temperature and humidity for optimal focus via **Open-Meteo REST API**.

---

## 10. File Management Endpoints (`/api/files`)

* `GET /api/files`: Lists uploaded documents, slides, and datasets.
* `POST /api/files/upload`: Multipart file upload with MIME whitelist and 25MB limit validation.
* `GET /api/files/:id/download`: Securely streams file to client.
* `DELETE /api/files/:id`: Deletes database metadata and deletes physical file from disk.

---

## 11. Privacy, Security & GDPR Portability (`/api/privacy`)

* `GET /api/privacy`: Returns privacy toggles (visibility, 2FA status, activity broadcast).
* `PUT /api/privacy`: Updates privacy settings.
* `GET /api/privacy/security-events`: Returns security audit logs (logins, 2FA verification, device history).
* `GET /api/privacy/export-data`: **GDPR Compliance Export** — compiles user profile, tasks, todos, comments, and study plans into a downloadable JSON file.
* `DELETE /api/privacy/delete-account`: Permanently deletes user account and cascade-removes personal records.
