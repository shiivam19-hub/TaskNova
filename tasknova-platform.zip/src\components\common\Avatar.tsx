import React from 'react';
import { User } from 'lucide-react';

interface AvatarProps {
  name?: string;
  initials?: string;
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl';
  status?: 'online' | 'offline' | 'busy' | 'away';
  color?: string;
  className?: string;
  showStatus?: boolean;
}

export const Avatar: React.FC<AvatarProps> = ({
  name = 'User',
  initials,
  size = 'md',
  status,
  color,
  className = '',
  showStatus = false
}) => {
  const sizeClasses = {
    xs: 'w-6 h-6 text-[10px]',
    sm: 'w-8 h-8 text-xs',
    md: 'w-9 h-9 text-xs',
    lg: 'w-11 h-11 text-sm font-semibold',
    xl: 'w-14 h-14 text-base font-bold'
  }[size];

  const statusSizeClasses = {
    xs: 'w-1.5 h-1.5 ring-1',
    sm: 'w-2 h-2 ring-1.5',
    md: 'w-2.5 h-2.5 ring-2',
    lg: 'w-3 h-3 ring-2',
    xl: 'w-3.5 h-3.5 ring-2'
  }[size];

  const statusColors = {
    online: 'bg-emerald-500',
    busy: 'bg-rose-500',
    away: 'bg-amber-500',
    offline: 'bg-slate-500'
  };

  const computedInitials = initials || name.split(' ').map(n => n[0]).slice(0, 2).join('').toUpperCase();

  // Neutral blank DP fallback with subtle gradient or sleek solid slate
  const defaultBg = color || 'bg-slate-800 text-slate-300 border border-slate-700/80';

  return (
    <div className={`relative inline-flex items-center justify-center shrink-0 ${className}`}>
      <div
        className={`${sizeClasses} ${defaultBg} rounded-full flex items-center justify-center font-medium shadow-inner select-none transition-transform`}
        title={name}
      >
        {computedInitials ? (
          <span>{computedInitials}</span>
        ) : (
          <User className="w-1/2 h-1/2 text-slate-400" />
        )}
      </div>

      {showStatus && status && (
        <span
          className={`absolute bottom-0 right-0 block ${statusSizeClasses} ${statusColors[status]} rounded-full ring-slate-900`}
          title={`Status: ${status}`}
        />
      )}
    </div>
  );
};
