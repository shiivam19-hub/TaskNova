import { Router, Response } from 'express';
import { PrismaClient } from '@prisma/client';
import { authenticate, AuthRequest, requireRole } from '../middleware/auth';

const router = Router();
const prisma = new PrismaClient();

// List all projects
router.get('/', authenticate, async (req: AuthRequest, res: Response) => {
  try {
    const { status, category, search } = req.query;

    const projects = await prisma.project.findMany({
      where: {
        ...(status && status !== 'All' ? { status: String(status) } : {}),
        ...(category && category !== 'All' ? { category: String(category) } : {}),
        ...(search ? {
          OR: [
            { name: { contains: String(search) } },
            { description: { contains: String(search) } }
          ]
        } : {})
      },
      include: {
        members: true,
        milestones: true,
        tasks: {
          select: { id: true, status: true, priority: true }
        },
        _count: {
          select: { tasks: true, files: true, comments: true }
        }
      },
      orderBy: { updatedAt: 'desc' }
    });

    const formatted = projects.map(p => {
      const completedTasks = p.tasks.filter(t => t.status === 'COMPLETED').length;
      return {
        id: p.id,
        name: p.name,
        description: p.description,
        category: p.category,
        status: p.status,
        priority: p.priority,
        progress: p.progress,
        deadline: p.deadline,
        owner: p.ownerName,
        visibility: p.visibility,
        taskCount: p._count.tasks,
        completedTaskCount: completedTasks,
        team: p.members.map(m => m.memberName),
        milestones: p.milestones,
        privateNotes: p.privateNotes ? JSON.parse(p.privateNotes) : [],
        createdAt: p.createdAt
      };
    });

    res.json(formatted);
  } catch (error: any) {
    res.status(500).json({ error: error.message || 'Failed to fetch projects' });
  }
});

// Create Project
router.post('/', authenticate, async (req: AuthRequest, res: Response) => {
  try {
    const { name, description, category, status, priority, deadline, team, milestones, privateNotes, visibility } = req.body;

    if (!name || !name.trim()) {
      return res.status(400).json({ error: 'Project name is required' });
    }

    const teamMembersList = Array.isArray(team) && team.length > 0 ? team : [req.user!.name];

    const project = await prisma.project.create({
      data: {
        name: name.trim(),
        description: description || 'Newly initiated project workspace.',
        category: category || 'Engineering',
        status: status || 'In Progress',
        priority: priority || 'High',
        progress: 0,
        deadline: deadline || 'October 30, 2026',
        ownerName: req.user!.name,
        visibility: visibility || 'Team',
        privateNotes: privateNotes ? JSON.stringify(privateNotes) : null,
        members: {
          create: teamMembersList.map((m: string) => ({
            memberName: m,
            role: m === req.user!.name ? req.user!.role : 'Contributor'
          }))
        },
        milestones: {
          create: Array.isArray(milestones) ? milestones.map((ms: any) => ({
            title: ms.title || 'Initial Milestone',
            dueDate: ms.dueDate || 'Next Week',
            completed: !!ms.completed
          })) : [
            { title: 'Project Kickoff & Scope Validation', dueDate: 'Day 3', completed: true },
            { title: 'Alpha Deliverable Release', dueDate: 'Day 10', completed: false }
          ]
        }
      },
      include: {
        members: true,
        milestones: true
      }
    });

    // Record activity
    await prisma.activity.create({
      data: {
        authorName: req.user!.name,
        action: 'created',
        target: `Project "${project.name}"`,
        type: 'create',
        projectId: project.id
      }
    });

    res.status(201).json(project);
  } catch (error: any) {
    res.status(500).json({ error: error.message || 'Failed to create project' });
  }
});

// Get Single Project Details
router.get('/:id', authenticate, async (req: AuthRequest, res: Response) => {
  try {
    const { id } = req.params;
    const project = await prisma.project.findUnique({
      where: { id },
      include: {
        members: true,
        milestones: true,
        tasks: {
          include: { subtasks: true },
          orderBy: { createdAt: 'desc' }
        },
        files: true,
        comments: {
          include: { replies: true, reactions: true },
          orderBy: { createdAt: 'desc' }
        }
      }
    });

    if (!project) {
      return res.status(404).json({ error: 'Project not found' });
    }

    const completedTasks = project.tasks.filter(t => t.status === 'COMPLETED').length;

    res.json({
      ...project,
      taskCount: project.tasks.length,
      completedTaskCount: completedTasks,
      team: project.members.map(m => m.memberName),
      privateNotes: project.privateNotes ? JSON.parse(project.privateNotes) : []
    });
  } catch (error: any) {
    res.status(500).json({ error: error.message || 'Failed to fetch project details' });
  }
});

// Update Project
router.put('/:id', authenticate, async (req: AuthRequest, res: Response) => {
  try {
    const { id } = req.params;
    const { name, description, category, status, priority, progress, deadline, privateNotes, visibility } = req.body;

    const project = await prisma.project.update({
      where: { id },
      data: {
        ...(name && { name }),
        ...(description && { description }),
        ...(category && { category }),
        ...(status && { status }),
        ...(priority && { priority }),
        ...(progress !== undefined && { progress: Number(progress) }),
        ...(deadline && { deadline }),
        ...(visibility && { visibility }),
        ...(privateNotes !== undefined && { privateNotes: JSON.stringify(privateNotes) })
      },
      include: {
        members: true,
        milestones: true
      }
    });

    await prisma.activity.create({
      data: {
        authorName: req.user!.name,
        action: 'updated',
        target: `Project "${project.name}"`,
        type: 'status_change',
        projectId: project.id
      }
    });

    res.json(project);
  } catch (error: any) {
    res.status(500).json({ error: error.message || 'Failed to update project' });
  }
});

// Patch status/progress
router.patch('/:id', authenticate, async (req: AuthRequest, res: Response) => {
  try {
    const { id } = req.params;
    const updates: any = {};
    if (req.body.status) updates.status = req.body.status;
    if (req.body.progress !== undefined) updates.progress = Number(req.body.progress);
    if (req.body.priority) updates.priority = req.body.priority;

    const project = await prisma.project.update({
      where: { id },
      data: updates
    });

    res.json(project);
  } catch (error: any) {
    res.status(500).json({ error: error.message || 'Failed to patch project' });
  }
});

// Delete Project (Owner / Admin permission)
router.delete('/:id', authenticate, requireRole(['Owner', 'Admin', 'Project Manager']), async (req: AuthRequest, res: Response) => {
  try {
    const { id } = req.params;
    const target = await prisma.project.findUnique({ where: { id } });
    if (!target) return res.status(404).json({ error: 'Project not found' });

    await prisma.project.delete({ where: { id } });

    await prisma.activity.create({
      data: {
        authorName: req.user!.name,
        action: 'deleted',
        target: `Project "${target.name}"`,
        type: 'complete'
      }
    });

    res.json({ message: `Project "${target.name}" deleted successfully` });
  } catch (error: any) {
    res.status(500).json({ error: error.message || 'Failed to delete project' });
  }
});

export default router;
