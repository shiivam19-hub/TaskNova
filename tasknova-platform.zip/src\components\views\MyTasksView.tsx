import React, { useState } from 'react';
import {
  CheckSquare,
  Plus,
  Search,
  Filter,
  CheckCircle2,
  Calendar,
  Clock,
  AlertTriangle,
  MoreVertical,
  Trash2,
  Tag,
  Paperclip,
  MessageSquare,
  Edit2
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { Avatar } from '../common/Avatar';
import { Task, TaskStatus, Priority } from '../../types';
import { useToast } from '../../context/ToastContext';
import { Modal } from '../common/Modal';

export const MyTasksView: React.FC = () => {
  const {
    tasks,
    updateTask,
    deleteTask,
    toggleTaskCompletion,
    openQuickCreate,
    projects
  } = useApp();

  const { showToast } = useToast();

  const [activeTab, setActiveTab] = useState<'All' | 'Today' | 'Upcoming' | 'Overdue' | 'Completed'>('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [priorityFilter, setPriorityFilter] = useState<string>('All');

  // Edit Task modal state
  const [editingTask, setEditingTask] = useState<Task | null>(null);
  const [editTitle, setEditTitle] = useState('');
  const [editPriority, setEditPriority] = useState<Priority>('Medium');
  const [editStatus, setEditStatus] = useState<TaskStatus>('TO DO');
  const [editDueDate, setEditDueDate] = useState('');
  const [editAssignee, setEditAssignee] = useState('');

  const openEditModal = (task: Task) => {
    setEditingTask(task);
    setEditTitle(task.title);
    setEditPriority(task.priority);
    setEditStatus(task.status);
    setEditDueDate(task.dueDate);
    setEditAssignee(task.assignee.name);
  };

  const handleSaveEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingTask) return;
    updateTask(editingTask.id, {
      title: editTitle,
      priority: editPriority,
      status: editStatus,
      dueDate: editDueDate,
      assignee: { name: editAssignee, avatarColor: editingTask.assignee.avatarColor }
    });
    setEditingTask(null);
    showToast('Task Updated', `Changes saved to "${editTitle}".`, 'success');
  };

  const filteredTasks = tasks.filter(task => {
    const matchesSearch = task.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (task.projectName && task.projectName.toLowerCase().includes(searchQuery.toLowerCase()));
    const matchesPriority = priorityFilter === 'All' || task.priority === priorityFilter;

    let matchesTab = true;
    if (activeTab === 'Today') {
      matchesTab = task.dueDate.toLowerCase().includes('today') || task.dueDate.toLowerCase().includes('tomorrow');
    } else if (activeTab === 'Upcoming') {
      matchesTab = task.status !== 'COMPLETED';
    } else if (activeTab === 'Overdue') {
      matchesTab = task.priority === 'Urgent' || task.dueDate.toLowerCase().includes('yesterday');
    } else if (activeTab === 'Completed') {
      matchesTab = task.status === 'COMPLETED';
    }

    return matchesSearch && matchesPriority && matchesTab;
  });

  const getPriorityBadge = (priority: Priority) => {
    switch (priority) {
      case 'Urgent':
        return 'bg-rose-500/15 text-rose-400 border border-rose-500/30';
      case 'High':
        return 'bg-amber-500/15 text-amber-400 border border-amber-500/30';
      case 'Medium':
        return 'bg-cyan-500/15 text-cyan-400 border border-cyan-500/30';
      default:
        return 'bg-slate-800 text-slate-400 border border-slate-700';
    }
  };

  return (
    <div className="space-y-6 animate-fade-in pb-16">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-white flex items-center gap-2.5">
            <CheckSquare className="w-6 h-6 text-cyan-400" />
            My Tasks
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Prioritize, track, and complete your assigned engineering and study deliverables.
          </p>
        </div>

        <button
          onClick={() => openQuickCreate('task')}
          className="flex items-center gap-2 px-4 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold rounded-xl shadow-lg shadow-indigo-950/40 transition-all self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          Add Task
        </button>
      </div>

      {/* Filter and Tab Bar */}
      <div className="bg-[#111827] border border-slate-800 rounded-2xl p-4 space-y-4">
        {/* Tabs */}
        <div className="flex items-center gap-2 border-b border-slate-800 pb-3 overflow-x-auto">
          {(['All', 'Today', 'Upcoming', 'Overdue', 'Completed'] as const).map(tab => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-all shrink-0 ${
                activeTab === tab
                  ? 'bg-indigo-600 text-white shadow-md shadow-indigo-950/40'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
              }`}
            >
              {tab}
            </button>
          ))}
        </div>

        {/* Search & Priority Filter Controls */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="relative w-full sm:w-80">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              placeholder="Search tasks..."
              className="w-full pl-9 pr-3 py-1.5 bg-slate-900 border border-slate-700 rounded-xl text-xs text-slate-100 placeholder:text-slate-400 focus:outline-none focus:border-indigo-500"
            />
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto">
            <span className="text-xs text-slate-400 flex items-center gap-1">
              <Filter className="w-3.5 h-3.5" /> Priority:
            </span>
            <select
              value={priorityFilter}
              onChange={e => setPriorityFilter(e.target.value)}
              className="px-2.5 py-1.5 bg-slate-900 border border-slate-700 rounded-xl text-xs text-slate-200 focus:outline-none focus:border-indigo-500"
            >
              <option value="All">All Priorities</option>
              <option value="Urgent">Urgent</option>
              <option value="High">High</option>
              <option value="Medium">Medium</option>
              <option value="Low">Low</option>
            </select>
          </div>
        </div>
      </div>

      {/* Task List Table */}
      <div className="bg-[#111827] border border-slate-800 rounded-2xl overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-900/60 border-b border-slate-800 text-slate-400 uppercase text-[10px] tracking-wider">
              <tr>
                <th className="py-3 px-4 w-12 text-center">Done</th>
                <th className="py-3 px-4">Task Details</th>
                <th className="py-3 px-4">Project</th>
                <th className="py-3 px-4">Priority</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4">Assignee</th>
                <th className="py-3 px-4">Due Date</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {filteredTasks.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-12 text-center text-slate-400">
                    <CheckSquare className="w-10 h-10 text-slate-600 mx-auto mb-2" />
                    <p className="font-semibold text-slate-300">No tasks found</p>
                    <p className="text-[11px] text-slate-500 mt-0.5">
                      Change the active tab or click "Add Task" to create one.
                    </p>
                  </td>
                </tr>
              ) : (
                filteredTasks.map(task => (
                  <tr
                    key={task.id}
                    className="hover:bg-slate-900/40 transition-colors group"
                  >
                    {/* Checkbox */}
                    <td className="py-3.5 px-4 text-center">
                      <button
                        onClick={() => toggleTaskCompletion(task.id)}
                        className={`w-5 h-5 rounded-md border flex items-center justify-center transition-colors mx-auto ${
                          task.status === 'COMPLETED'
                            ? 'bg-emerald-500 border-emerald-500 text-white'
                            : 'border-slate-700 hover:border-indigo-500'
                        }`}
                        title={task.status === 'COMPLETED' ? 'Mark incomplete' : 'Mark completed'}
                      >
                        {task.status === 'COMPLETED' && <CheckCircle2 className="w-3.5 h-3.5" />}
                      </button>
                    </td>

                    {/* Task Title & Tags */}
                    <td className="py-3.5 px-4">
                      <div className="space-y-1">
                        <span className={`font-semibold block ${
                          task.status === 'COMPLETED' ? 'line-through text-slate-500' : 'text-slate-100'
                        }`}>
                          {task.title}
                        </span>
                        {task.description && (
                          <p className="text-[11px] text-slate-400 line-clamp-1">{task.description}</p>
                        )}
                        <div className="flex items-center gap-1.5 pt-0.5">
                          {task.tags.map(tag => (
                            <span key={tag} className="text-[9px] px-1.5 py-0.5 rounded bg-slate-800 text-slate-400">
                              #{tag}
                            </span>
                          ))}
                        </div>
                      </div>
                    </td>

                    {/* Project */}
                    <td className="py-3.5 px-4 text-slate-300 font-medium">
                      {task.projectName}
                    </td>

                    {/* Priority Selector */}
                    <td className="py-3.5 px-4">
                      <select
                        value={task.priority}
                        onChange={e => updateTask(task.id, { priority: e.target.value as Priority })}
                        className={`text-[10px] font-semibold px-2 py-0.5 rounded border focus:outline-none bg-transparent cursor-pointer ${getPriorityBadge(task.priority)}`}
                      >
                        <option value="Urgent" className="bg-slate-900 text-slate-100">Urgent</option>
                        <option value="High" className="bg-slate-900 text-slate-100">High</option>
                        <option value="Medium" className="bg-slate-900 text-slate-100">Medium</option>
                        <option value="Low" className="bg-slate-900 text-slate-100">Low</option>
                      </select>
                    </td>

                    {/* Status Selector */}
                    <td className="py-3.5 px-4">
                      <select
                        value={task.status}
                        onChange={e => updateTask(task.id, { status: e.target.value as TaskStatus })}
                        className="px-2 py-0.5 rounded bg-slate-800 border border-slate-700 text-[11px] text-slate-200 focus:outline-none cursor-pointer"
                      >
                        <option value="TO DO">TO DO</option>
                        <option value="IN PROGRESS">IN PROGRESS</option>
                        <option value="IN REVIEW">IN REVIEW</option>
                        <option value="COMPLETED">COMPLETED</option>
                      </select>
                    </td>

                    {/* Assignee */}
                    <td className="py-3.5 px-4">
                      <div className="flex items-center gap-1.5">
                        <Avatar name={task.assignee.name} size="xs" color={task.assignee.avatarColor} />
                        <span className="text-slate-300 truncate">{task.assignee.name}</span>
                      </div>
                    </td>

                    {/* Due Date */}
                    <td className="py-3.5 px-4 text-slate-400 whitespace-nowrap">
                      {task.dueDate}
                    </td>

                    {/* Actions */}
                    <td className="py-3.5 px-4 text-right whitespace-nowrap">
                      <div className="flex items-center justify-end gap-1">
                        <button
                          onClick={() => openEditModal(task)}
                          className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
                          title="Edit task"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => deleteTask(task.id)}
                          className="p-1.5 text-slate-500 hover:text-rose-400 rounded-lg hover:bg-slate-800 transition-colors"
                          title="Delete task"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Edit Task Modal */}
      {editingTask && (
        <Modal
          isOpen={true}
          onClose={() => setEditingTask(null)}
          title="Edit Task Details"
          subtitle={`Editing deliverable #${editingTask.id}`}
        >
          <form onSubmit={handleSaveEdit} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                Task Title
              </label>
              <input
                type="text"
                value={editTitle}
                onChange={e => setEditTitle(e.target.value)}
                required
                className="w-full px-3.5 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-xs text-slate-100 focus:outline-none focus:border-indigo-500"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                  Priority
                </label>
                <select
                  value={editPriority}
                  onChange={e => setEditPriority(e.target.value as Priority)}
                  className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-xs text-slate-100 focus:outline-none focus:border-indigo-500"
                >
                  <option value="Urgent">Urgent</option>
                  <option value="High">High</option>
                  <option value="Medium">Medium</option>
                  <option value="Low">Low</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                  Status
                </label>
                <select
                  value={editStatus}
                  onChange={e => setEditStatus(e.target.value as TaskStatus)}
                  className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-xs text-slate-100 focus:outline-none focus:border-indigo-500"
                >
                  <option value="TO DO">TO DO</option>
                  <option value="IN PROGRESS">IN PROGRESS</option>
                  <option value="IN REVIEW">IN REVIEW</option>
                  <option value="COMPLETED">COMPLETED</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                  Due Date
                </label>
                <input
                  type="text"
                  value={editDueDate}
                  onChange={e => setEditDueDate(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-xs text-slate-100 focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                  Assignee Name
                </label>
                <input
                  type="text"
                  value={editAssignee}
                  onChange={e => setEditAssignee(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-xs text-slate-100 focus:outline-none focus:border-indigo-500"
                />
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-3">
              <button
                type="button"
                onClick={() => setEditingTask(null)}
                className="px-4 py-2 text-xs text-slate-400 hover:text-white rounded-xl hover:bg-slate-800"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold rounded-xl"
              >
                Save Changes
              </button>
            </div>
          </form>
        </Modal>
      )}
    </div>
  );
};
