export type ProjectStatus = 'In Progress' | 'Near Completion' | 'At Risk' | 'Completed' | 'Planning';
export type Priority = 'Urgent' | 'High' | 'Medium' | 'Low';
export type TaskStatus = 'TO DO' | 'IN PROGRESS' | 'IN REVIEW' | 'COMPLETED';
export type RoleType = 'Owner' | 'Admin' | 'Project Manager' | 'Editor' | 'Contributor' | 'Viewer';

export interface TeamMember {
  id: string;
  name: string;
  role: string;
  department: string;
  email: string;
  activeProjects: number;
  tasksCompleted: number;
  productivity: number; // e.g. 92%
  status: 'online' | 'offline' | 'busy' | 'away';
  roleType: RoleType;
  avatarColor?: string;
  initials?: string;
}

export interface Task {
  id: string;
  projectId: string;
  projectName?: string;
  title: string;
  description?: string;
  priority: Priority;
  status: TaskStatus;
  assignee: {
    name: string;
    avatarColor?: string;
  };
  dueDate: string; // ISO or human format
  commentsCount: number;
  attachmentIndicator: boolean;
  tags: string[];
  subtasks?: { id: string; title: string; completed: boolean }[];
  isPrivate?: boolean;
}

export interface Milestone {
  id: string;
  title: string;
  dueDate: string;
  completed: boolean;
}

export interface Project {
  id: string;
  name: string;
  description: string;
  progress: number; // 0 - 100
  status: ProjectStatus;
  priority: Priority;
  deadline: string;
  owner: string;
  team: string[]; // Member names or IDs
  tags: string[];
  taskCount: number;
  completedTaskCount: number;
  milestones: Milestone[];
  privateNotes?: string[];
  category: 'Engineering' | 'Design' | 'Marketing' | 'Academic' | 'Personal';
  visibility?: 'Private' | 'Team' | 'Public';
}

export interface ToDoItem {
  id: string;
  title: string;
  completed: boolean;
  priority: Priority;
  dueDate: string;
  category: 'Today' | 'Upcoming' | 'Personal' | 'Study' | 'Project';
  tags: string[];
  notes?: string;
}

export interface CommentReply {
  id: string;
  authorName: string;
  authorRole: string;
  content: string;
  timestamp: string;
}

export interface ProjectComment {
  id: string;
  projectId: string;
  projectName?: string;
  authorName: string;
  authorRole: string;
  content: string;
  timestamp: string;
  pinned: boolean;
  reactions: { emoji: string; count: number; users: string[] }[];
  replies: CommentReply[];
  attachments?: string[];
}

export interface ActivityItem {
  id: string;
  authorName: string;
  action: string;
  target: string;
  timestamp: string;
  type: 'complete' | 'status_change' | 'upload' | 'create' | 'comment' | 'permission';
  projectId?: string;
}

export interface NotificationItem {
  id: string;
  title: string;
  message: string;
  type: 'deadline' | 'comment' | 'file' | 'assignment' | 'security' | 'system';
  timestamp: string;
  read: boolean;
  linkTo?: string;
}

export interface CalendarEvent {
  id: string;
  title: string;
  date: string; // YYYY-MM-DD
  time: string; // e.g. "10:00 AM - 11:30 AM"
  type: 'deadline' | 'meeting' | 'class' | 'exam' | 'study' | 'milestone';
  projectId?: string;
  location?: string;
  reminderMinutes?: number;
}

export interface StudyResource {
  id: string;
  title: string;
  type: 'book' | 'paper' | 'video' | 'note';
  authorsOrChannel: string;
  source: string; // 'Open Library' | 'Crossref REST API' | 'YouTube Data API' | 'Personal'
  identifierOrUrl: string; // ISBN, DOI, YouTube URL, etc.
  saved: boolean;
  tags: string[];
  notes?: string;
  year?: string;
  isPrivate?: boolean;
}

export interface StudyScheduleDay {
  dayNumber: number;
  topic: string;
  durationHours: number;
  completed: boolean;
  weakArea?: boolean;
}

export interface StudyPlan {
  id: string;
  subject: string;
  examDate: string;
  availableHoursPerDay: number;
  progress: number;
  difficulty: 'Easy' | 'Medium' | 'Hard' | 'Intense';
  weakTopics: string[];
  days: StudyScheduleDay[];
}

export interface AuditLogItem {
  id: string;
  timestamp: string;
  title: string;
  description: string;
  user: string;
  device?: string;
  browser?: string;
  location?: string;
  severity: 'info' | 'warning' | 'danger';
}

export interface ProjectFile {
  id: string;
  projectId: string;
  projectName?: string;
  name: string;
  size: string;
  type: 'pdf' | 'fig' | 'doc' | 'archive' | 'code' | 'image';
  uploadedBy: string;
  uploadedAt: string;
  downloadUrl?: string;
}

export interface TeamsMeeting {
  id: string;
  title: string;
  date: string;
  time: string;
  teamName: string;
  channel: string;
  joinUrl: string;
  organizer: string;
  attendeesCount: number;
}

export interface UserProfile {
  name: string;
  role: string;
  email: string;
  workspace: string;
  avatarInitials: string;
  avatarColor: string;
  status: 'online' | 'busy' | 'away' | 'offline';
  roleType: RoleType;
  privacy: {
    profileVisibility: 'Private' | 'Team' | 'Public';
    emailVisibility: 'Only Me' | 'Team' | 'Public';
    activityStatus: boolean;
    onlineStatus: boolean;
    studyProgress: 'Private' | 'Team';
    studyNotes: 'Only Me' | 'Shared';
    savedResearch: 'Only Me' | 'Shared';
    defaultProjectPrivacy: 'Private' | 'Team' | 'Public';
  };
  security: {
    twoFactorEnabled: boolean;
    twoFactorMethod: 'Authenticator App' | 'Email OTP';
    sessionTimeoutMinutes: number;
    loginAlertsEnabled: boolean;
  };
  appearance: 'dark' | 'light' | 'system';
}
