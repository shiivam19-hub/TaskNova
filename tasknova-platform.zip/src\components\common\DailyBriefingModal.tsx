import React, { useEffect, useState } from 'react';
import { Sparkles, X, CheckCircle2, Clock, BookOpen, ListTodo, ArrowRight, Zap, RefreshCw } from 'lucide-react';
import { apiClient } from '../../services/apiClient';
import { useApp } from '../../context/AppContext';

interface PriorityItem {
  id: string;
  title: string;
  type: 'Task' | 'Study Goal' | 'Todo';
  context: string;
  action: string;
}

interface DailyBriefingData {
  greeting: string;
  date: string;
  summaryMessage: string;
  priorities: PriorityItem[];
  focusTip: string;
}

interface DailyBriefingModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const DailyBriefingModal: React.FC<DailyBriefingModalProps> = ({ isOpen, onClose }) => {
  const { setActiveTab, userProfile } = useApp();
  const [data, setData] = useState<DailyBriefingData | null>(null);
  const [loading, setLoading] = useState(false);

  const fetchBriefing = async () => {
    setLoading(true);
    try {
      const result = await apiClient.ai.dailyBriefing();
      setData(result);
    } catch (e) {
      // Fallback
      setData({
        greeting: `Good morning, ${userProfile.name} 👋`,
        date: new Date().toISOString().split('T')[0],
        summaryMessage: 'Here is your strategic high-impact roadmap for today to maximize velocity and focus.',
        priorities: [
          {
            id: 'p1',
            title: 'Implement Raft Consensus State Machine',
            type: 'Task',
            context: 'Distributed Neural Cloud Engine • Priority: Critical',
            action: 'Immediate Focus'
          },
          {
            id: 'p2',
            title: 'Master Raft Consensus & Byzantine Fault Tolerance',
            type: 'Study Goal',
            context: 'Target: 2026-09-20',
            action: 'Dedicated 45-min Study Block'
          },
          {
            id: 'p3',
            title: 'Review Transformer Attention paper for research seminar',
            type: 'Todo',
            context: 'Personal Checklist',
            action: 'Quick Win'
          }
        ],
        focusTip: 'Tackle the consensus state machine first before opening communications or low-priority items.'
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (isOpen) {
      fetchBriefing();
    }
  }, [isOpen]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-md animate-fade-in">
      <div className="relative w-full max-w-2xl bg-[#0f172a] border border-indigo-500/30 rounded-2xl shadow-2xl overflow-hidden animate-scale-up">
        {/* Glow accent */}
        <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-indigo-500 via-cyan-400 to-indigo-600" />

        {/* Header */}
        <div className="p-6 border-b border-slate-800/80 flex items-start justify-between bg-slate-900/40">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-500/20 border border-indigo-500/30 flex items-center justify-center text-indigo-400">
              <Sparkles className="w-5 h-5 animate-pulse text-indigo-300" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl font-bold text-white tracking-tight">
                  {data?.greeting || `Good morning, ${userProfile.name} 👋`}
                </h2>
                <span className="px-2 py-0.5 text-[10px] font-semibold tracking-wide uppercase bg-indigo-500/20 text-indigo-300 rounded-full border border-indigo-500/30">
                  TASKNOVA AI Briefing
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                {data?.date || new Date().toLocaleDateString('en-US', { weekday: 'long', month: 'short', day: 'numeric' })} • AI Work Prioritization
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              onClick={fetchBriefing}
              disabled={loading}
              title="Refresh Briefing"
              className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors"
            >
              <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
            </button>
            <button
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Content Body */}
        <div className="p-6 space-y-5 max-h-[70vh] overflow-y-auto custom-scrollbar">
          {loading ? (
            <div className="py-12 flex flex-col items-center justify-center text-center space-y-3">
              <div className="w-8 h-8 border-2 border-indigo-500 border-t-transparent rounded-full animate-spin" />
              <p className="text-xs text-slate-400">Consulting TASKNOVA AI to analyze your sprint deadlines & study goals...</p>
            </div>
          ) : (
            <>
              {/* Summary message */}
              <div className="p-3.5 bg-indigo-950/20 border border-indigo-500/20 rounded-xl text-sm text-slate-300 flex items-start gap-3">
                <Zap className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
                <span>{data?.summaryMessage}</span>
              </div>

              {/* Priorities List */}
              <div className="space-y-2.5">
                <h3 className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
                  Recommended Action Sequence for Today
                </h3>

                <div className="space-y-2">
                  {data?.priorities.map((item, idx) => (
                    <div
                      key={item.id || idx}
                      className="p-3.5 bg-slate-900/80 hover:bg-slate-900 border border-slate-800 hover:border-slate-700/80 rounded-xl transition-all flex items-center justify-between gap-3 group"
                    >
                      <div className="flex items-start gap-3">
                        <div className="w-6 h-6 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center text-xs font-bold text-indigo-400 shrink-0 mt-0.5">
                          {idx + 1}
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="text-sm font-semibold text-white group-hover:text-indigo-300 transition-colors">
                              {item.title}
                            </span>
                            <span className={`px-2 py-0.5 text-[10px] font-medium rounded-full ${
                              item.type === 'Task' ? 'bg-indigo-500/15 text-indigo-400 border border-indigo-500/20' :
                              item.type === 'Study Goal' ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/20' :
                              'bg-amber-500/15 text-amber-400 border border-amber-500/20'
                            }`}>
                              {item.type}
                            </span>
                          </div>
                          <p className="text-xs text-slate-400 mt-0.5">{item.context}</p>
                        </div>
                      </div>

                      <div className="text-right shrink-0">
                        <span className="text-xs font-medium text-cyan-400 block">
                          {item.action}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Focus Tip */}
              {data?.focusTip && (
                <div className="p-3 bg-slate-900/50 border border-slate-800 rounded-xl flex items-center gap-2.5 text-xs text-slate-300">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span>
                    <strong className="text-white">Pro Tip:</strong> {data.focusTip}
                  </span>
                </div>
              )}
            </>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-900/60 border-t border-slate-800/80 flex items-center justify-between">
          <div className="text-xs text-slate-400">
            Powered by TASKNOVA Intelligence
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                onClose();
                setActiveTab('timer');
              }}
              className="px-3.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium rounded-xl transition-colors flex items-center gap-1.5"
            >
              <Clock className="w-3.5 h-3.5 text-cyan-400" />
              Launch Focus Timer
            </button>
            <button
              onClick={() => {
                onClose();
                setActiveTab('tasks');
              }}
              className="px-4 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold rounded-xl shadow-md shadow-indigo-950/40 transition-colors flex items-center gap-1.5"
            >
              Go to Kanban
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
