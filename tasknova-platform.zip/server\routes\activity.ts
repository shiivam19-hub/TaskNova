import { Router, Response } from 'express';
import { PrismaClient } from '@prisma/client';
import { authenticate, AuthRequest } from '../middleware/auth';

const router = Router();
const prisma = new PrismaClient();

// Get recent activities
router.get('/', authenticate, async (req: AuthRequest, res: Response) => {
  try {
    const { limit = 20, projectId, type } = req.query;

    const activities = await prisma.activity.findMany({
      where: {
        ...(projectId ? { projectId: String(projectId) } : {}),
        ...(type && type !== 'all' ? { type: String(type) } : {})
      },
      orderBy: { createdAt: 'desc' },
      take: Number(limit)
    });

    res.json(activities);
  } catch (error) {
    console.error('Fetch activities error:', error);
    res.status(500).json({ error: 'Failed to fetch activity logs' });
  }
});

// Log a custom activity
router.post('/', authenticate, async (req: AuthRequest, res: Response) => {
  try {
    const { action, target, type = 'create', projectId } = req.body;
    const authorName = req.user?.name || 'Shivam Singh';

    const activity = await prisma.activity.create({
      data: {
        authorName,
        action,
        target,
        type,
        projectId: projectId || null
      }
    });

    res.status(201).json(activity);
  } catch (error) {
    console.error('Log activity error:', error);
    res.status(500).json({ error: 'Failed to log activity' });
  }
});

export default router;
