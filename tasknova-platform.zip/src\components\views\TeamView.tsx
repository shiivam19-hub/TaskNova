import React, { useState } from 'react';
import {
  Users,
  UserPlus,
  ShieldCheck,
  CheckCircle2,
  XCircle,
  Mail,
  FolderKanban,
  CheckSquare,
  TrendingUp,
  Search,
  Filter,
  Shield
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { Avatar } from '../common/Avatar';
import { RoleType, TeamMember } from '../../types';
import { useToast } from '../../context/ToastContext';
import { Modal } from '../common/Modal';

export const TeamView: React.FC = () => {
  const {
    teamMembers,
    updateMemberRole,
    addTeamMember
  } = useApp();

  const { showToast } = useToast();

  const [searchQuery, setSearchQuery] = useState('');
  const [departmentFilter, setDepartmentFilter] = useState('All');
  const [isInviteOpen, setIsInviteOpen] = useState(false);

  // Invite Member Form
  const [inviteName, setInviteName] = useState('');
  const [inviteRole, setInviteRole] = useState('');
  const [inviteDept, setInviteDept] = useState('Engineering');
  const [inviteEmail, setInviteEmail] = useState('');
  const [inviteRoleType, setInviteRoleType] = useState<RoleType>('Contributor');

  const filteredMembers = teamMembers.filter(m => {
    const matchesSearch = m.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      m.role.toLowerCase().includes(searchQuery.toLowerCase()) ||
      m.email.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesDept = departmentFilter === 'All' || m.department === departmentFilter;
    return matchesSearch && matchesDept;
  });

  const handleInvite = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inviteName.trim() || !inviteEmail.trim()) return;
    addTeamMember({
      name: inviteName.trim(),
      role: inviteRole.trim() || 'Software Engineer',
      department: inviteDept,
      email: inviteEmail.trim(),
      activeProjects: 1,
      tasksCompleted: 0,
      productivity: 90,
      status: 'online',
      roleType: inviteRoleType,
      avatarColor: 'bg-indigo-600',
      initials: inviteName.split(' ').map(n => n[0]).slice(0, 2).join('').toUpperCase()
    });
    showToast('Invitation Dispatched', `Invite email sent to ${inviteEmail}.`, 'success');
    setIsInviteOpen(false);
    setInviteName('');
    setInviteEmail('');
    setInviteRole('');
  };

  const departments = ['All', 'Product & Operations', 'Design Studio', 'Engineering', 'Infrastructure', 'AI Research', 'Quality Assurance'];

  const rbacMatrix: { role: RoleType; view: boolean; create: string; edit: string; delete: boolean; manageMembers: boolean }[] = [
    { role: 'Owner', view: true, create: 'Full', edit: 'Full', delete: true, manageMembers: true },
    { role: 'Admin', view: true, create: 'Full', edit: 'Full', delete: false, manageMembers: true },
    { role: 'Editor', view: true, create: 'Full', edit: 'Full', delete: false, manageMembers: false },
    { role: 'Contributor', view: true, create: 'Limited', edit: 'Assigned Only', delete: false, manageMembers: false },
    { role: 'Viewer', view: true, create: 'None', edit: 'None', delete: false, manageMembers: false }
  ];

  return (
    <div className="space-y-8 animate-fade-in pb-16">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-white flex items-center gap-2.5">
            <Users className="w-6 h-6 text-indigo-400" />
            Team Directory & Access Control
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Collaborators, roles, productivity metrics, and Role-Based Access Control (RBAC) governance.
          </p>
        </div>

        <button
          onClick={() => setIsInviteOpen(true)}
          className="flex items-center gap-2 px-4 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold rounded-xl shadow-lg shadow-indigo-950/40 transition-all self-start sm:self-auto"
        >
          <UserPlus className="w-4 h-4" />
          Invite Colleague
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 bg-[#111827] border border-slate-800 p-3 rounded-2xl">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="text"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder="Search member by name, role, or email..."
            className="w-full pl-9 pr-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-xs text-slate-100 placeholder:text-slate-400 focus:outline-none focus:border-indigo-500"
          />
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto">
          <Filter className="w-3.5 h-3.5 text-slate-400" />
          <span className="text-xs text-slate-400">Department:</span>
          <select
            value={departmentFilter}
            onChange={e => setDepartmentFilter(e.target.value)}
            className="px-2.5 py-1.5 bg-slate-900 border border-slate-700 rounded-xl text-xs text-slate-200 focus:outline-none focus:border-indigo-500"
          >
            {departments.map(d => (
              <option key={d} value={d}>{d}</option>
            ))}
          </select>
        </div>
      </div>

      {/* Members Cards Grid (Section 9) */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredMembers.map(member => (
          <div
            key={member.id}
            className="bg-[#111827] border border-slate-800 rounded-2xl p-5 shadow-sm space-y-4 hover:border-slate-700 transition-colors flex flex-col justify-between"
          >
            <div className="space-y-3">
              {/* Member Top Line: Neutral Avatar + Online Indicator + Role Badge */}
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-center gap-3">
                  <Avatar
                    name={member.name}
                    initials={member.initials}
                    size="lg"
                    status={member.status}
                    showStatus={true}
                    color={member.avatarColor}
                  />
                  <div>
                    <h3 className="text-sm font-bold text-slate-100">{member.name}</h3>
                    <p className="text-xs text-indigo-400 font-medium">{member.role}</p>
                    <span className="text-[11px] text-slate-400">{member.department}</span>
                  </div>
                </div>

                {/* Role Switcher */}
                <select
                  value={member.roleType}
                  onChange={e => updateMemberRole(member.id, e.target.value as RoleType)}
                  className="px-2 py-1 bg-slate-900 border border-slate-700 rounded-lg text-[11px] font-semibold text-slate-200 focus:outline-none cursor-pointer"
                >
                  <option value="Owner">Owner</option>
                  <option value="Admin">Admin</option>
                  <option value="Editor">Editor</option>
                  <option value="Contributor">Contributor</option>
                  <option value="Viewer">Viewer</option>
                </select>
              </div>

              {/* Email Contact Line */}
              <div className="flex items-center gap-1.5 text-xs text-slate-400 pt-1">
                <Mail className="w-3.5 h-3.5 text-slate-500 shrink-0" />
                <span className="truncate">{member.email}</span>
              </div>
            </div>

            {/* Performance Metrics Footer */}
            <div className="pt-3 border-t border-slate-800 grid grid-cols-3 gap-2 text-center text-xs">
              <div className="p-2 bg-slate-900/60 rounded-xl">
                <span className="text-[10px] text-slate-400 block">Projects</span>
                <span className="font-bold text-slate-200 mt-0.5 block">{member.activeProjects}</span>
              </div>
              <div className="p-2 bg-slate-900/60 rounded-xl">
                <span className="text-[10px] text-slate-400 block">Tasks Done</span>
                <span className="font-bold text-slate-200 mt-0.5 block">{member.tasksCompleted}</span>
              </div>
              <div className="p-2 bg-slate-900/60 rounded-xl">
                <span className="text-[10px] text-slate-400 block">Productivity</span>
                <span className="font-bold text-emerald-400 mt-0.5 block">{member.productivity}%</span>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Role-Based Access Control (RBAC) Matrix (Section 22) */}
      <div className="bg-[#111827] border border-slate-800 rounded-2xl p-6 space-y-4 shadow-sm">
        <div className="flex items-center gap-2.5">
          <Shield className="w-5 h-5 text-indigo-400" />
          <div>
            <h2 className="text-base font-bold text-white">Role-Based Access Control (RBAC) Policies</h2>
            <p className="text-xs text-slate-400">Enforced platform-wide across engineering workspaces and study repositories</p>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-900/60 border-b border-slate-800 text-slate-400 uppercase text-[10px] tracking-wider">
              <tr>
                <th className="py-3 px-4">Role Tier</th>
                <th className="py-3 px-4 text-center">View</th>
                <th className="py-3 px-4 text-center">Create</th>
                <th className="py-3 px-4 text-center">Edit</th>
                <th className="py-3 px-4 text-center">Delete</th>
                <th className="py-3 px-4 text-center">Manage Members</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {rbacMatrix.map(row => (
                <tr key={row.role} className="hover:bg-slate-900/30 transition-colors">
                  <td className="py-3 px-4 font-bold text-slate-200">
                    <span className="px-2.5 py-1 rounded-md bg-slate-800 border border-slate-700">
                      {row.role}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-center">
                    {row.view ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 mx-auto" />
                    ) : (
                      <XCircle className="w-4 h-4 text-rose-400 mx-auto" />
                    )}
                  </td>
                  <td className="py-3 px-4 text-center font-medium text-slate-300">
                    {row.create === 'Full' ? (
                      <span className="text-emerald-400 flex items-center justify-center gap-1">
                        <CheckCircle2 className="w-4 h-4" /> Full
                      </span>
                    ) : row.create === 'Limited' ? (
                      <span className="text-amber-400">Limited</span>
                    ) : (
                      <span className="text-rose-400">None ❌</span>
                    )}
                  </td>
                  <td className="py-3 px-4 text-center font-medium text-slate-300">
                    {row.edit === 'Full' ? (
                      <span className="text-emerald-400 flex items-center justify-center gap-1">
                        <CheckCircle2 className="w-4 h-4" /> Full
                      </span>
                    ) : row.edit === 'Assigned Only' ? (
                      <span className="text-amber-400">Assigned Tasks Only</span>
                    ) : (
                      <span className="text-rose-400">None ❌</span>
                    )}
                  </td>
                  <td className="py-3 px-4 text-center">
                    {row.delete ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 mx-auto" />
                    ) : (
                      <XCircle className="w-4 h-4 text-rose-400 mx-auto" />
                    )}
                  </td>
                  <td className="py-3 px-4 text-center">
                    {row.manageMembers ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 mx-auto" />
                    ) : (
                      <XCircle className="w-4 h-4 text-rose-400 mx-auto" />
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Invite Member Modal */}
      {isInviteOpen && (
        <Modal
          isOpen={true}
          onClose={() => setIsInviteOpen(false)}
          title="Invite New Contributor"
          subtitle="Grant project or workspace permissions to a team colleague."
        >
          <form onSubmit={handleInvite} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                Full Name *
              </label>
              <input
                type="text"
                required
                value={inviteName}
                onChange={e => setInviteName(e.target.value)}
                placeholder="e.g. Maya Lin"
                className="w-full px-3.5 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-xs text-slate-100 focus:outline-none focus:border-indigo-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                Email Address *
              </label>
              <input
                type="email"
                required
                value={inviteEmail}
                onChange={e => setInviteEmail(e.target.value)}
                placeholder="maya.lin@tasknova.app"
                className="w-full px-3.5 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-xs text-slate-100 focus:outline-none focus:border-indigo-500"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                  Job Role
                </label>
                <input
                  type="text"
                  value={inviteRole}
                  onChange={e => setInviteRole(e.target.value)}
                  placeholder="e.g. Cloud Architect"
                  className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-xs text-slate-100 focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                  Department
                </label>
                <select
                  value={inviteDept}
                  onChange={e => setInviteDept(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-xs text-slate-100 focus:outline-none focus:border-indigo-500"
                >
                  <option value="Engineering">Engineering</option>
                  <option value="Design Studio">Design Studio</option>
                  <option value="Product & Operations">Product & Operations</option>
                  <option value="AI Research">AI Research</option>
                  <option value="Quality Assurance">Quality Assurance</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                Role-Based Permission Tier
              </label>
              <select
                value={inviteRoleType}
                onChange={e => setInviteRoleType(e.target.value as RoleType)}
                className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-xs text-slate-100 focus:outline-none focus:border-indigo-500"
              >
                <option value="Admin">Admin</option>
                <option value="Editor">Editor</option>
                <option value="Contributor">Contributor</option>
                <option value="Viewer">Viewer</option>
              </select>
            </div>

            <div className="flex justify-end gap-2 pt-3">
              <button
                type="button"
                onClick={() => setIsInviteOpen(false)}
                className="px-4 py-2 text-xs text-slate-400 hover:text-white rounded-xl hover:bg-slate-800"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold rounded-xl"
              >
                Send Invite
              </button>
            </div>
          </form>
        </Modal>
      )}
    </div>
  );
};
