import React, { useState } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { ToastProvider } from './context/ToastContext';
import { Sidebar } from './components/layout/Sidebar';
import { TopNav } from './components/layout/TopNav';
import { MobileNav } from './components/layout/MobileNav';

// View Components
import { DashboardView } from './components/views/DashboardView';
import { MyTasksView } from './components/views/MyTasksView';
import { TodoListView } from './components/views/TodoListView';
import { ProjectsView } from './components/views/ProjectsView';
import { ProjectDetailsView } from './components/views/ProjectDetailsView';
import { TeamView } from './components/views/TeamView';
import { CommentsView } from './components/views/CommentsView';
import { CalendarView } from './components/views/CalendarView';
import { FocusTimerView } from './components/views/FocusTimerView';
import { StudyHubView } from './components/views/StudyHubView';
import { StudyPlannerView } from './components/views/StudyPlannerView';
import { AIAssistantView } from './components/views/AIAssistantView';
import { AnalyticsView } from './components/views/AnalyticsView';
import { NotificationsView } from './components/views/NotificationsView';
import { TeamsIntegrationView } from './components/views/TeamsIntegrationView';
import { FileManagementView } from './components/views/FileManagementView';
import { PrivacySecurityView } from './components/views/PrivacySecurityView';
import { SettingsView } from './components/views/SettingsView';

// Global Modals
import { QuickCreateModal } from './components/common/QuickCreateModal';
import { SuspiciousLoginModal } from './components/common/SuspiciousLoginModal';
import { HelpModal } from './components/common/HelpModal';
import { DailyBriefingModal } from './components/common/DailyBriefingModal';

const AppContent: React.FC = () => {
  const { activeTab, isDailyBriefingOpen, setIsDailyBriefingOpen } = useApp();
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);

  const renderActiveView = () => {
    switch (activeTab) {
      case 'dashboard':
        return <DashboardView />;
      case 'tasks':
        return <MyTasksView />;
      case 'todos':
        return <TodoListView />;
      case 'projects':
        return <ProjectsView />;
      case 'project-details':
        return <ProjectDetailsView />;
      case 'team':
        return <TeamView />;
      case 'comments':
        return <CommentsView />;
      case 'calendar':
        return <CalendarView />;
      case 'timer':
        return <FocusTimerView />;
      case 'study-hub':
        return <StudyHubView />;
      case 'study-planner':
        return <StudyPlannerView />;
      case 'ai-assistant':
        return <AIAssistantView />;
      case 'analytics':
        return <AnalyticsView />;
      case 'notifications':
        return <NotificationsView />;
      case 'teams-integration':
        return <TeamsIntegrationView />;
      case 'files':
        return <FileManagementView />;
      case 'privacy':
        return <PrivacySecurityView />;
      case 'settings':
        return <SettingsView />;
      default:
        return <DashboardView />;
    }
  };

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-[#0b0f17] text-slate-100 font-sans">
      {/* Left Sidebar (Desktop / Tablet) */}
      <div className="hidden md:flex shrink-0 h-full">
        <Sidebar
          isCollapsed={isSidebarCollapsed}
          setIsCollapsed={setIsSidebarCollapsed}
        />
      </div>

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0 h-full overflow-hidden">
        {/* Top Navigation Bar */}
        <TopNav />

        {/* Scrollable View Area */}
        <main className="flex-1 overflow-y-auto px-4 sm:px-6 lg:px-8 py-6 pb-20 md:pb-8">
          <div className="max-w-7xl mx-auto">
            {renderActiveView()}
          </div>
        </main>
      </div>

      {/* Mobile Bottom Navigation */}
      <MobileNav />

      {/* Global Modals */}
      <QuickCreateModal />
      <SuspiciousLoginModal />
      <HelpModal />
      <DailyBriefingModal
        isOpen={isDailyBriefingOpen}
        onClose={() => setIsDailyBriefingOpen(false)}
      />
    </div>
  );
};

export function App() {
  return (
    <ToastProvider>
      <AppProvider>
        <AppContent />
      </AppProvider>
    </ToastProvider>
  );
}

export default App;
