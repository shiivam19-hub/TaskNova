import React, { useState, useEffect } from 'react';
import { Modal } from './Modal';
import { FolderPlus, CheckSquare, ListPlus, CalendarPlus, Target, UploadCloud } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { useToast } from '../../context/ToastContext';
import { Priority, ProjectStatus, RoleType } from '../../types';

export const QuickCreateModal: React.FC = () => {
  const {
    isQuickCreateOpen,
    setIsQuickCreateOpen,
    quickCreateInitialType,
    projects,
    addProject,
    addTask,
    addToDo,
    addEvent,
    generateNewPlan,
    uploadFile,
    userProfile
  } = useApp();
  const { showToast } = useToast();

  const [activeType, setActiveType] = useState<'project' | 'task' | 'todo' | 'meeting' | 'goal' | 'file'>('project');

  useEffect(() => {
    if (isQuickCreateOpen) {
      setActiveType(quickCreateInitialType);
    }
  }, [isQuickCreateOpen, quickCreateInitialType]);

  // Project form
  const [projName, setProjName] = useState('');
  const [projDesc, setProjDesc] = useState('');
  const [projDeadline, setProjDeadline] = useState('October 30, 2026');
  const [projPriority, setProjPriority] = useState<Priority>('High');
  const [projCategory, setProjCategory] = useState<'Engineering' | 'Design' | 'Marketing' | 'Academic'>('Engineering');

  // Task form
  const [taskTitle, setTaskTitle] = useState('');
  const [taskDesc, setTaskDesc] = useState('');
  const [taskProjectId, setTaskProjectId] = useState('');
  const [taskPriority, setTaskPriority] = useState<Priority>('High');
  const [taskDueDate, setTaskDueDate] = useState('Tomorrow');
  const [taskAssignee, setTaskAssignee] = useState(userProfile.name || 'Shivam Singh');

  // ToDo form
  const [todoTitle, setTodoTitle] = useState('');
  const [todoCategory, setTodoCategory] = useState<'Today' | 'Upcoming' | 'Personal' | 'Study' | 'Project'>('Today');
  const [todoPriority, setTodoPriority] = useState<Priority>('Medium');

  // Meeting form
  const [meetingTitle, setMeetingTitle] = useState('');
  const [meetingDate, setMeetingDate] = useState('2026-09-15');
  const [meetingTime, setMeetingTime] = useState('02:00 PM - 03:00 PM');
  const [meetingLocation, setMeetingLocation] = useState('Microsoft Teams');

  // Goal/Study Plan form
  const [goalSubject, setGoalSubject] = useState('');
  const [goalExamDate, setGoalExamDate] = useState('October 15, 2026');
  const [goalHours, setGoalHours] = useState(3);
  const [goalDifficulty, setGoalDifficulty] = useState<'Easy' | 'Medium' | 'Hard'>('Medium');

  // File form
  const [fileName, setFileName] = useState('');
  const [fileProjectId, setFileProjectId] = useState('');
  const [fileSize, setFileSize] = useState('1.5 MB');

  useEffect(() => {
    if (projects.length > 0) {
      if (!taskProjectId) setTaskProjectId(projects[0].id);
      if (!fileProjectId) setFileProjectId(projects[0].id);
    }
  }, [projects, taskProjectId, fileProjectId]);

  const handleCreateProject = (e: React.FormEvent) => {
    e.preventDefault();
    if (!projName.trim()) return;
    addProject({
      name: projName,
      description: projDesc || 'Newly initiated project workspace.',
      progress: 5,
      status: 'In Progress',
      priority: projPriority,
      deadline: projDeadline,
      owner: userProfile.name,
      team: [userProfile.name, 'Aarav Sharma', 'Ananya Singh'],
      tags: [projCategory, 'Sprint 1'],
      taskCount: 0,
      category: projCategory,
      milestones: [
        { id: `ms-${Date.now()}`, title: 'Initial Sprint Planning', dueDate: 'Next Week', completed: false }
      ]
    });
    showToast('Project Created', `Project "${projName}" is now active.`, 'success');
    setIsQuickCreateOpen(false);
    setProjName('');
    setProjDesc('');
  };

  const handleCreateTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!taskTitle.trim()) return;
    addTask({
      projectId: taskProjectId,
      title: taskTitle,
      description: taskDesc,
      priority: taskPriority,
      status: 'TO DO',
      assignee: { name: taskAssignee, avatarColor: 'bg-indigo-600' },
      dueDate: taskDueDate,
      tags: ['Sprint'],
      subtasks: []
    });
    showToast('Task Created', `"${taskTitle}" added to project backlog.`, 'success');
    setIsQuickCreateOpen(false);
    setTaskTitle('');
    setTaskDesc('');
  };

  const handleCreateToDo = (e: React.FormEvent) => {
    e.preventDefault();
    if (!todoTitle.trim()) return;
    addToDo({
      title: todoTitle,
      priority: todoPriority,
      dueDate: todoCategory === 'Today' ? 'Today' : 'Upcoming',
      category: todoCategory,
      tags: [todoCategory]
    });
    showToast('To-Do Added', 'Personal item registered to your checklist.', 'success');
    setIsQuickCreateOpen(false);
    setTodoTitle('');
  };

  const handleScheduleMeeting = (e: React.FormEvent) => {
    e.preventDefault();
    if (!meetingTitle.trim()) return;
    addEvent({
      title: meetingTitle,
      date: meetingDate,
      time: meetingTime,
      type: 'meeting',
      location: meetingLocation,
      reminderMinutes: 15
    });
    showToast('Meeting Scheduled', `"${meetingTitle}" calendar entry created.`, 'success');
    setIsQuickCreateOpen(false);
    setMeetingTitle('');
  };

  const handleAddStudyGoal = (e: React.FormEvent) => {
    e.preventDefault();
    if (!goalSubject.trim()) return;
    generateNewPlan(goalSubject, goalExamDate, goalHours, goalDifficulty);
    showToast('Study Plan Generated', `7-day structured revision generated for ${goalSubject}.`, 'success');
    setIsQuickCreateOpen(false);
    setGoalSubject('');
  };

  const handleUploadFile = (e: React.FormEvent) => {
    e.preventDefault();
    if (!fileName.trim()) return;
    const ext = fileName.split('.').pop()?.toLowerCase() || 'pdf';
    uploadFile({
      projectId: fileProjectId || (projects[0]?.id ?? 'p1'),
      projectName: projects.find(p => p.id === fileProjectId)?.name || 'General',
      name: fileName.includes('.') ? fileName : `${fileName}.pdf`,
      size: fileSize,
      type: ext === 'fig' ? 'fig' : 'pdf',
      uploadedBy: userProfile.name
    });
    showToast('File Registered', `Uploaded "${fileName}" to project assets.`, 'success');
    setIsQuickCreateOpen(false);
    setFileName('');
  };

  return (
    <Modal
      isOpen={isQuickCreateOpen}
      onClose={() => setIsQuickCreateOpen(false)}
      title="Create New Item"
      subtitle="Select a category to quickly add to your workspace."
      size="lg"
    >
      {/* Category selector pills */}
      <div className="flex flex-wrap gap-2 pb-4 border-b border-slate-800">
        {[
          { id: 'project', label: 'New Project', icon: FolderPlus },
          { id: 'task', label: 'New Task', icon: CheckSquare },
          { id: 'todo', label: 'New To-Do', icon: ListPlus },
          { id: 'meeting', label: 'Schedule Meeting', icon: CalendarPlus },
          { id: 'goal', label: 'Study Goal', icon: Target },
          { id: 'file', label: 'Upload File', icon: UploadCloud }
        ].map(item => {
          const Icon = item.icon;
          const isSelected = activeType === item.id;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => setActiveType(item.id as any)}
              className={`flex items-center gap-2 px-3 py-1.5 rounded-xl text-xs font-medium transition-all ${
                isSelected
                  ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-950/40'
                  : 'bg-slate-800/80 text-slate-300 hover:bg-slate-700 hover:text-white'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              {item.label}
            </button>
          );
        })}
      </div>

      <div className="pt-4">
        {/* Project Form */}
        {activeType === 'project' && (
          <form onSubmit={handleCreateProject} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                Project Name *
              </label>
              <input
                type="text"
                required
                value={projName}
                onChange={e => setProjName(e.target.value)}
                placeholder="e.g. Distributed Database Engine"
                className="w-full px-3.5 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-slate-100 text-sm focus:outline-none focus:border-indigo-500"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                Description
              </label>
              <textarea
                rows={2}
                value={projDesc}
                onChange={e => setProjDesc(e.target.value)}
                placeholder="Brief summary of project objectives..."
                className="w-full px-3.5 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-slate-100 text-sm focus:outline-none focus:border-indigo-500"
              />
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                  Category
                </label>
                <select
                  value={projCategory}
                  onChange={e => setProjCategory(e.target.value as any)}
                  className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-slate-100 text-sm focus:outline-none focus:border-indigo-500"
                >
                  <option value="Engineering">Engineering</option>
                  <option value="Design">Design</option>
                  <option value="Marketing">Marketing</option>
                  <option value="Academic">Academic</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                  Priority
                </label>
                <select
                  value={projPriority}
                  onChange={e => setProjPriority(e.target.value as Priority)}
                  className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-slate-100 text-sm focus:outline-none focus:border-indigo-500"
                >
                  <option value="Urgent">Urgent</option>
                  <option value="High">High</option>
                  <option value="Medium">Medium</option>
                  <option value="Low">Low</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                  Target Deadline
                </label>
                <input
                  type="text"
                  value={projDeadline}
                  onChange={e => setProjDeadline(e.target.value)}
                  placeholder="e.g. October 30, 2026"
                  className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-slate-100 text-sm focus:outline-none focus:border-indigo-500"
                />
              </div>
            </div>
            <div className="flex justify-end gap-2.5 pt-3">
              <button
                type="button"
                onClick={() => setIsQuickCreateOpen(false)}
                className="px-4 py-2 text-sm text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition-colors"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-5 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-sm font-medium rounded-xl shadow-lg shadow-indigo-950/40 transition-all"
              >
                Create Project
              </button>
            </div>
          </form>
        )}

        {/* Task Form */}
        {activeType === 'task' && (
          <form onSubmit={handleCreateTask} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                Task Title *
              </label>
              <input
                type="text"
                required
                value={taskTitle}
                onChange={e => setTaskTitle(e.target.value)}
                placeholder="e.g. Implement OAuth2 token handshake"
                className="w-full px-3.5 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-slate-100 text-sm focus:outline-none focus:border-indigo-500"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                Target Project
              </label>
              <select
                value={taskProjectId}
                onChange={e => setTaskProjectId(e.target.value)}
                className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-slate-100 text-sm focus:outline-none focus:border-indigo-500"
              >
                {projects.map(p => (
                  <option key={p.id} value={p.id}>
                    {p.name}
                  </option>
                ))}
              </select>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                  Priority
                </label>
                <select
                  value={taskPriority}
                  onChange={e => setTaskPriority(e.target.value as Priority)}
                  className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-slate-100 text-sm focus:outline-none focus:border-indigo-500"
                >
                  <option value="Urgent">Urgent</option>
                  <option value="High">High</option>
                  <option value="Medium">Medium</option>
                  <option value="Low">Low</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                  Due Date
                </label>
                <input
                  type="text"
                  value={taskDueDate}
                  onChange={e => setTaskDueDate(e.target.value)}
                  placeholder="Tomorrow / Sept 18"
                  className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-slate-100 text-sm focus:outline-none focus:border-indigo-500"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                  Assignee
                </label>
                <input
                  type="text"
                  value={taskAssignee}
                  onChange={e => setTaskAssignee(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-slate-100 text-sm focus:outline-none focus:border-indigo-500"
                />
              </div>
            </div>
            <div className="flex justify-end gap-2.5 pt-3">
              <button
                type="button"
                onClick={() => setIsQuickCreateOpen(false)}
                className="px-4 py-2 text-sm text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition-colors"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-5 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-sm font-medium rounded-xl shadow-lg shadow-indigo-950/40 transition-all"
              >
                Add Task
              </button>
            </div>
          </form>
        )}

        {/* To-Do Form */}
        {activeType === 'todo' && (
          <form onSubmit={handleCreateToDo} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                To-Do Item *
              </label>
              <input
                type="text"
                required
                value={todoTitle}
                onChange={e => setTodoTitle(e.target.value)}
                placeholder="e.g. Review lecture slides on Dynamic Programming"
                className="w-full px-3.5 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-slate-100 text-sm focus:outline-none focus:border-indigo-500"
              />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                  Category
                </label>
                <select
                  value={todoCategory}
                  onChange={e => setTodoCategory(e.target.value as any)}
                  className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-slate-100 text-sm focus:outline-none focus:border-indigo-500"
                >
                  <option value="Today">Today</option>
                  <option value="Upcoming">Upcoming</option>
                  <option value="Study">Study</option>
                  <option value="Project">Project</option>
                  <option value="Personal">Personal</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                  Priority
                </label>
                <select
                  value={todoPriority}
                  onChange={e => setTodoPriority(e.target.value as Priority)}
                  className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-slate-100 text-sm focus:outline-none focus:border-indigo-500"
                >
                  <option value="Urgent">Urgent</option>
                  <option value="High">High</option>
                  <option value="Medium">Medium</option>
                  <option value="Low">Low</option>
                </select>
              </div>
            </div>
            <div className="flex justify-end gap-2.5 pt-3">
              <button
                type="button"
                onClick={() => setIsQuickCreateOpen(false)}
                className="px-4 py-2 text-sm text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition-colors"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-5 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-sm font-medium rounded-xl shadow-lg shadow-indigo-950/40 transition-all"
              >
                Save To-Do
              </button>
            </div>
          </form>
        )}

        {/* Meeting Form */}
        {activeType === 'meeting' && (
          <form onSubmit={handleScheduleMeeting} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                Meeting Title *
              </label>
              <input
                type="text"
                required
                value={meetingTitle}
                onChange={e => setMeetingTitle(e.target.value)}
                placeholder="e.g. Sprint Retrospective & Architecture Review"
                className="w-full px-3.5 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-slate-100 text-sm focus:outline-none focus:border-indigo-500"
              />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                  Date
                </label>
                <input
                  type="date"
                  value={meetingDate}
                  onChange={e => setMeetingDate(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-slate-100 text-sm focus:outline-none focus:border-indigo-500"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                  Time Slot
                </label>
                <input
                  type="text"
                  value={meetingTime}
                  onChange={e => setMeetingTime(e.target.value)}
                  placeholder="e.g. 04:00 PM - 05:00 PM"
                  className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-slate-100 text-sm focus:outline-none focus:border-indigo-500"
                />
              </div>
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                Platform / Location
              </label>
              <input
                type="text"
                value={meetingLocation}
                onChange={e => setMeetingLocation(e.target.value)}
                placeholder="Microsoft Teams Channel / Room 402"
                className="w-full px-3.5 py-2 bg-slate-900 border border-slate-700 rounded-xl text-slate-100 text-sm focus:outline-none focus:border-indigo-500"
              />
            </div>
            <div className="flex justify-end gap-2.5 pt-3">
              <button
                type="button"
                onClick={() => setIsQuickCreateOpen(false)}
                className="px-4 py-2 text-sm text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition-colors"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-5 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-sm font-medium rounded-xl shadow-lg shadow-indigo-950/40 transition-all"
              >
                Schedule Meeting
              </button>
            </div>
          </form>
        )}

        {/* Goal / Study Form */}
        {activeType === 'goal' && (
          <form onSubmit={handleAddStudyGoal} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                Subject or Topic *
              </label>
              <input
                type="text"
                required
                value={goalSubject}
                onChange={e => setGoalSubject(e.target.value)}
                placeholder="e.g. Operating Systems & Kernel Threads"
                className="w-full px-3.5 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-slate-100 text-sm focus:outline-none focus:border-indigo-500"
              />
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                  Target Exam Date
                </label>
                <input
                  type="text"
                  value={goalExamDate}
                  onChange={e => setGoalExamDate(e.target.value)}
                  placeholder="e.g. October 15, 2026"
                  className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-slate-100 text-sm focus:outline-none focus:border-indigo-500"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                  Daily Study Hours
                </label>
                <input
                  type="number"
                  min={1}
                  max={12}
                  value={goalHours}
                  onChange={e => setGoalHours(Number(e.target.value))}
                  className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-slate-100 text-sm focus:outline-none focus:border-indigo-500"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                  Difficulty Level
                </label>
                <select
                  value={goalDifficulty}
                  onChange={e => setGoalDifficulty(e.target.value as any)}
                  className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-slate-100 text-sm focus:outline-none focus:border-indigo-500"
                >
                  <option value="Easy">Easy</option>
                  <option value="Medium">Medium</option>
                  <option value="Hard">Hard</option>
                </select>
              </div>
            </div>
            <div className="flex justify-end gap-2.5 pt-3">
              <button
                type="button"
                onClick={() => setIsQuickCreateOpen(false)}
                className="px-4 py-2 text-sm text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition-colors"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-5 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-sm font-medium rounded-xl shadow-lg shadow-indigo-950/40 transition-all"
              >
                Generate Study Schedule
              </button>
            </div>
          </form>
        )}

        {/* File Upload Form */}
        {activeType === 'file' && (
          <form onSubmit={handleUploadFile} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                File Name *
              </label>
              <input
                type="text"
                required
                value={fileName}
                onChange={e => setFileName(e.target.value)}
                placeholder="e.g. Architecture_Specification.pdf"
                className="w-full px-3.5 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-slate-100 text-sm focus:outline-none focus:border-indigo-500"
              />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                  Associate Project
                </label>
                <select
                  value={fileProjectId}
                  onChange={e => setFileProjectId(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-slate-100 text-sm focus:outline-none focus:border-indigo-500"
                >
                  {projects.map(p => (
                    <option key={p.id} value={p.id}>
                      {p.name}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                  File Size (Est.)
                </label>
                <input
                  type="text"
                  value={fileSize}
                  onChange={e => setFileSize(e.target.value)}
                  placeholder="2.4 MB"
                  className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-slate-100 text-sm focus:outline-none focus:border-indigo-500"
                />
              </div>
            </div>
            <div className="p-4 border-2 border-dashed border-slate-700 rounded-xl text-center text-xs text-slate-400 bg-slate-900/40">
              Drag & drop files here, or link cloud storage (Firebase Storage / Google Drive / S3)
            </div>
            <div className="flex justify-end gap-2.5 pt-3">
              <button
                type="button"
                onClick={() => setIsQuickCreateOpen(false)}
                className="px-4 py-2 text-sm text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition-colors"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-5 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-sm font-medium rounded-xl shadow-lg shadow-indigo-950/40 transition-all"
              >
                Upload File
              </button>
            </div>
          </form>
        )}
      </div>
    </Modal>
  );
};
