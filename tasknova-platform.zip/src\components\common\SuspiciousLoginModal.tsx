import React from 'react';
import { Modal } from './Modal';
import { AlertTriangle, ShieldCheck, ShieldAlert, Monitor, Globe, Clock, MapPin } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { useToast } from '../../context/ToastContext';

export const SuspiciousLoginModal: React.FC = () => {
  const { isSuspiciousLoginOpen, setIsSuspiciousLoginOpen, resolveSuspiciousLogin } = useApp();
  const { showToast } = useToast();

  if (!isSuspiciousLoginOpen) return null;

  const handleConfirm = () => {
    resolveSuspiciousLogin('confirm');
    showToast('Device Authorized', 'This device has been added to your recognized devices list.', 'success');
  };

  const handleSecure = () => {
    resolveSuspiciousLogin('secure');
    showToast('Account Secured', 'Active tokens invalidated. Password reset link dispatched to your email.', 'error');
  };

  return (
    <Modal
      isOpen={isSuspiciousLoginOpen}
      onClose={() => setIsSuspiciousLoginOpen(false)}
      title="Security Verification Required"
      subtitle="We detected a new sign-in attempt to your account."
      size="md"
    >
      <div className="space-y-4">
        <div className="flex items-start gap-3 p-3.5 bg-amber-950/40 border border-amber-500/30 rounded-xl text-amber-200 text-sm">
          <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
          <div>
            <span className="font-semibold block text-amber-100">⚠️ New login detected</span>
            Please confirm whether this activity was initiated by you to safeguard your projects and study data.
          </div>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-4 space-y-2.5 text-sm">
          <div className="flex items-center justify-between py-1 border-b border-slate-800/60">
            <span className="text-slate-400 flex items-center gap-2">
              <Monitor className="w-4 h-4 text-slate-500" /> Device
            </span>
            <span className="font-medium text-slate-200">Windows PC</span>
          </div>

          <div className="flex items-center justify-between py-1 border-b border-slate-800/60">
            <span className="text-slate-400 flex items-center gap-2">
              <Globe className="w-4 h-4 text-slate-500" /> Browser
            </span>
            <span className="font-medium text-slate-200">Google Chrome 128.0 (Win64)</span>
          </div>

          <div className="flex items-center justify-between py-1 border-b border-slate-800/60">
            <span className="text-slate-400 flex items-center gap-2">
              <Clock className="w-4 h-4 text-slate-500" /> Time
            </span>
            <span className="font-medium text-slate-200">11:42 AM</span>
          </div>

          <div className="flex items-center justify-between py-1">
            <span className="text-slate-400 flex items-center gap-2">
              <MapPin className="w-4 h-4 text-slate-500" /> Location
            </span>
            <span className="font-medium text-slate-200">Patna, Bihar, India (Estimated IP)</span>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3 pt-2">
          <button
            onClick={handleConfirm}
            className="flex items-center justify-center gap-2 px-4 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white text-sm font-medium rounded-xl transition-all shadow-lg shadow-emerald-950/40"
          >
            <ShieldCheck className="w-4 h-4" />
            Yes, it was me
          </button>
          <button
            onClick={handleSecure}
            className="flex items-center justify-center gap-2 px-4 py-2.5 bg-rose-600/20 hover:bg-rose-600 text-rose-300 hover:text-white border border-rose-500/40 text-sm font-medium rounded-xl transition-all"
          >
            <ShieldAlert className="w-4 h-4" />
            Secure my account
          </button>
        </div>
      </div>
    </Modal>
  );
};
