import {
  Project,
  Task,
  ToDoItem,
  TeamMember,
  ProjectComment,
  ActivityItem,
  NotificationItem,
  CalendarEvent,
  StudyResource,
  StudyPlan,
  AuditLogItem,
  ProjectFile,
  TeamsMeeting,
  UserProfile
} from '../types';

export const initialUserProfile: UserProfile = {
  name: 'Shivam Singh',
  role: 'Student & Project COORDINATOR',
  email: 'shivam.singh@tasknova.app',
  workspace: 'Tasknova University Workspace',
  avatarInitials: 'SS',
  avatarColor: 'from-indigo-600 to-blue-500',
  status: 'online',
  roleType: 'Editor',
  privacy: {
    profileVisibility: 'Team',
    emailVisibility: 'Team',
    activityStatus: true,
    onlineStatus: true,
    studyProgress: 'Private',
    studyNotes: 'Only Me',
    savedResearch: 'Only Me',
    defaultProjectPrivacy: 'Team'
  },
  security: {
    twoFactorEnabled: true,
    twoFactorMethod: 'Authenticator App',
    sessionTimeoutMinutes: 30,
    loginAlertsEnabled: true
  },
  appearance: 'dark'
};

export const initialTeamMembers: TeamMember[] = [
  {
    id: 'm1',
    name: 'Aarav Sharma',
    role: 'Project Manager',
    department: 'Product & Operations',
    email: 'aarav.sharma@tasknova.app',
    activeProjects: 4,
    tasksCompleted: 48,
    productivity: 94,
    status: 'online',
    roleType: 'Project Manager',
    avatarColor: 'bg-indigo-600',
    initials: 'AS'
  },
  {
    id: 'm2',
    name: 'Ananya Singh',
    role: 'UI/UX Designer',
    department: 'Design Studio',
    email: 'ananya.singh@tasknova.app',
    activeProjects: 3,
    tasksCompleted: 36,
    productivity: 91,
    status: 'online',
    roleType: 'Editor',
    avatarColor: 'bg-cyan-600',
    initials: 'AS'
  },
  {
    id: 'm3',
    name: 'Rohan Kumar',
    role: 'Frontend Developer',
    department: 'Engineering',
    email: 'rohan.kumar@tasknova.app',
    activeProjects: 3,
    tasksCompleted: 42,
    productivity: 88,
    status: 'away',
    roleType: 'Contributor',
    avatarColor: 'bg-emerald-600',
    initials: 'RK'
  },
  {
    id: 'm4',
    name: 'Priya Verma',
    role: 'Backend Developer',
    department: 'Infrastructure',
    email: 'priya.verma@tasknova.app',
    activeProjects: 4,
    tasksCompleted: 51,
    productivity: 95,
    status: 'busy',
    roleType: 'Contributor',
    avatarColor: 'bg-amber-600',
    initials: 'PV'
  },
  {
    id: 'm5',
    name: 'Aditya Raj',
    role: 'ML Engineer',
    department: 'AI Research',
    email: 'aditya.raj@tasknova.app',
    activeProjects: 2,
    tasksCompleted: 29,
    productivity: 86,
    status: 'offline',
    roleType: 'Contributor',
    avatarColor: 'bg-purple-600',
    initials: 'AR'
  },
  {
    id: 'm6',
    name: 'Sneha Gupta',
    role: 'QA Engineer',
    department: 'Quality Assurance',
    email: 'sneha.gupta@tasknova.app',
    activeProjects: 3,
    tasksCompleted: 39,
    productivity: 89,
    status: 'online',
    roleType: 'Editor',
    avatarColor: 'bg-rose-600',
    initials: 'SG'
  }
];

export const initialProjects: Project[] = [
  {
    id: 'p1',
    name: 'Website Redesign',
    description: 'Modernizing corporate portal with responsive design, accessible components, and fast CWV performance.',
    progress: 78,
    status: 'In Progress',
    priority: 'High',
    deadline: 'September 28, 2026',
    owner: 'Aarav Sharma',
    team: ['Aarav Sharma', 'Ananya Singh', 'Rohan Kumar', 'Priya Verma', 'Sneha Gupta'],
    tags: ['UI/UX', 'Next.js', 'Design System'],
    taskCount: 28,
    completedTaskCount: 22,
    category: 'Design',
    milestones: [
      { id: 'ms1', title: 'Figma Design System Approval', dueDate: 'Sept 10', completed: true },
      { id: 'ms2', title: 'Interactive Component Library', dueDate: 'Sept 18', completed: true },
      { id: 'ms3', title: 'End-to-End User Testing', dueDate: 'Sept 24', completed: false },
      { id: 'ms4', title: 'Production Cloud Deployment', dueDate: 'Sept 28', completed: false }
    ],
    privateNotes: ['Discuss typography scaling tokens with Ananya before stakeholder demo.']
  },
  {
    id: 'p2',
    name: 'Mobile Banking App',
    description: 'Next-generation biometric authentication, micro-investing flows, and instant peer-to-peer transfers.',
    progress: 62,
    status: 'In Progress',
    priority: 'Urgent',
    deadline: 'October 15, 2026',
    owner: 'Priya Verma',
    team: ['Aarav Sharma', 'Priya Verma', 'Rohan Kumar', 'Sneha Gupta', 'Shivam Singh', 'Aditya Raj', 'Ananya Singh', 'Jordan Lee'],
    tags: ['Fintech', 'Security', 'React Native'],
    taskCount: 42,
    completedTaskCount: 26,
    category: 'Engineering',
    milestones: [
      { id: 'ms5', title: 'OAuth2 & Biometric Handshake', dueDate: 'Sept 15', completed: true },
      { id: 'ms6', title: 'Payment Gateway Sandbox Validation', dueDate: 'Sept 30', completed: false },
      { id: 'ms7', title: 'Regulatory Compliance Audit', dueDate: 'Oct 10', completed: false }
    ],
    privateNotes: ['Review security sandbox credentials before the weekly sync.']
  },
  {
    id: 'p3',
    name: 'AI Analytics Platform',
    description: 'Enterprise data intelligence suite integrating predictive forecasting and generative conversational insights.',
    progress: 45,
    status: 'At Risk',
    priority: 'High',
    deadline: 'November 2, 2026',
    owner: 'Aditya Raj',
    team: ['Aditya Raj', 'Priya Verma', 'Aarav Sharma', 'Rohan Kumar', 'Shivam Singh', 'Sneha Gupta'],
    tags: ['Machine Learning', 'BigQuery', 'GenAI'],
    taskCount: 36,
    completedTaskCount: 16,
    category: 'Engineering',
    milestones: [
      { id: 'ms8', title: 'Model Training & Quantization', dueDate: 'Oct 1', completed: true },
      { id: 'ms9', title: 'High-Throughput Streaming API', dueDate: 'Oct 18', completed: false },
      { id: 'ms10', title: 'Dashboard Widget Integration', dueDate: 'Oct 28', completed: false }
    ],
    privateNotes: ['Latency spikes during burst inference need optimization.']
  },
  {
    id: 'p4',
    name: 'Marketing Campaign 2026',
    description: 'Global multi-channel product launch targeting engineering universities and modern product teams.',
    progress: 91,
    status: 'Near Completion',
    priority: 'Medium',
    deadline: 'September 18, 2026',
    owner: 'Ananya Singh',
    team: ['Ananya Singh', 'Aarav Sharma', 'Shivam Singh', 'Rohan Kumar'],
    tags: ['Growth', 'Content', 'Social'],
    taskCount: 22,
    completedTaskCount: 20,
    category: 'Marketing',
    milestones: [
      { id: 'ms11', title: 'Influencer & Campus Ambassador Outreach', dueDate: 'Sept 5', completed: true },
      { id: 'ms12', title: 'Promotional Asset Delivery', dueDate: 'Sept 12', completed: true },
      { id: 'ms13', title: 'Launch Day Press Release', dueDate: 'Sept 18', completed: false }
    ],
    privateNotes: ['Verify UTM tracking parameters on educational community links.']
  }
];

export const initialTasks: Task[] = [
  {
    id: 't1',
    projectId: 'p1',
    projectName: 'Website Redesign',
    title: 'Finalize homepage UI',
    description: 'Ensure hero section animations and responsive typography match the design spec.',
    priority: 'High',
    status: 'IN PROGRESS',
    assignee: { name: 'Ananya Singh', avatarColor: 'bg-cyan-600' },
    dueDate: 'Tomorrow',
    commentsCount: 4,
    attachmentIndicator: true,
    tags: ['Design', 'Homepage', 'Figma'],
    subtasks: [
      { id: 'st1', title: 'Check mobile typography scale', completed: true },
      { id: 'st2', title: 'Export SVGs in 2x scale', completed: true },
      { id: 'st3', title: 'Add hover micro-interactions', completed: false }
    ]
  },
  {
    id: 't2',
    projectId: 'p2',
    projectName: 'Mobile Banking App',
    title: 'Fix authentication bug',
    description: 'Resolve token refresh race condition when app returns from background.',
    priority: 'High',
    status: 'TO DO',
    assignee: { name: 'Rohan Kumar', avatarColor: 'bg-emerald-600' },
    dueDate: 'September 13',
    commentsCount: 7,
    attachmentIndicator: false,
    tags: ['Auth', 'Security', 'Bug'],
    subtasks: [
      { id: 'st4', title: 'Reproduce with slow 3G simulation', completed: true },
      { id: 'st5', title: 'Implement mutex lock for refresh handler', completed: false }
    ]
  },
  {
    id: 't3',
    projectId: 'p3',
    projectName: 'AI Analytics Platform',
    title: 'Review API integration',
    description: 'Verify gRPC and REST latency against SLA benchmarks.',
    priority: 'Medium',
    status: 'IN REVIEW',
    assignee: { name: 'Priya Verma', avatarColor: 'bg-amber-600' },
    dueDate: 'September 15',
    commentsCount: 2,
    attachmentIndicator: true,
    tags: ['API', 'Backend', 'Review']
  },
  {
    id: 't4',
    projectId: 'p1',
    projectName: 'Website Redesign',
    title: 'Prepare project presentation',
    description: 'Compile slide deck highlighting performance improvements and user testing satisfaction.',
    priority: 'Medium',
    status: 'TO DO',
    assignee: { name: 'Aarav Sharma', avatarColor: 'bg-indigo-600' },
    dueDate: 'September 17',
    commentsCount: 3,
    attachmentIndicator: true,
    tags: ['Presentation', 'Stakeholders']
  },
  {
    id: 't5',
    projectId: 'p2',
    projectName: 'Mobile Banking App',
    title: 'Payment Gateway Testing',
    description: 'Execute sandbox payment simulations across UPI, credit card, and net banking.',
    priority: 'Urgent',
    status: 'TO DO',
    assignee: { name: 'Sneha Gupta', avatarColor: 'bg-rose-600' },
    dueDate: 'September 14',
    commentsCount: 5,
    attachmentIndicator: true,
    tags: ['QA', 'Testing', 'Payments']
  },
  {
    id: 't6',
    projectId: 'p3',
    projectName: 'AI Analytics Platform',
    title: 'Data pipeline ingestion optimization',
    description: 'Reduce pipeline memory footprint during concurrent batch uploads.',
    priority: 'High',
    status: 'IN PROGRESS',
    assignee: { name: 'Aditya Raj', avatarColor: 'bg-purple-600' },
    dueDate: 'September 20',
    commentsCount: 1,
    attachmentIndicator: false,
    tags: ['Data', 'Optimization']
  },
  {
    id: 't7',
    projectId: 'p4',
    projectName: 'Marketing Campaign 2026',
    title: 'Publish student ambassador guide',
    description: 'Release welcome kit and social banners to 40+ campus leads.',
    priority: 'Medium',
    status: 'COMPLETED',
    assignee: { name: 'Shivam Singh', avatarColor: 'bg-indigo-500' },
    dueDate: 'Yesterday',
    commentsCount: 6,
    attachmentIndicator: true,
    tags: ['Campus', 'Community']
  },
  {
    id: 't8',
    projectId: 'p1',
    projectName: 'Website Redesign',
    title: 'Audit Lighthouse Core Web Vitals',
    description: 'Ensure LCP is below 1.2s and CLS is zero across all primary landing routes.',
    priority: 'High',
    status: 'COMPLETED',
    assignee: { name: 'Rohan Kumar', avatarColor: 'bg-emerald-600' },
    dueDate: 'September 8',
    commentsCount: 2,
    attachmentIndicator: true,
    tags: ['Performance', 'Lighthouse']
  }
];

export const initialToDos: ToDoItem[] = [
  {
    id: 'td1',
    title: 'Review Chapter 4 of Algorithm Design (Graphs & BFS)',
    completed: true,
    priority: 'High',
    dueDate: 'Today',
    category: 'Study',
    tags: ['Algorithms', 'Exam Prep'],
    notes: 'Focus especially on cycle detection in directed graphs.'
  },
  {
    id: 'td2',
    title: 'Submit pull request for Mobile Banking token interceptor',
    completed: true,
    priority: 'Urgent',
    dueDate: 'Today',
    category: 'Project',
    tags: ['Code', 'PR']
  },
  {
    id: 'td3',
    title: 'Schedule professor sync on machine learning thesis draft',
    completed: false,
    priority: 'Medium',
    dueDate: 'Tomorrow',
    category: 'Study',
    tags: ['Thesis', 'Academic']
  },
  {
    id: 'td4',
    title: 'Order replacement mechanical keyboard switches',
    completed: false,
    priority: 'Low',
    dueDate: 'This Weekend',
    category: 'Personal',
    tags: ['Hardware']
  },
  {
    id: 'td5',
    title: 'Complete LeetCode daily challenge (Dynamic Programming)',
    completed: true,
    priority: 'Medium',
    dueDate: 'Today',
    category: 'Study',
    tags: ['DSA', 'Practice']
  },
  {
    id: 'td6',
    title: 'Prepare slides for Friday team showcase demo',
    completed: false,
    priority: 'High',
    dueDate: 'Friday',
    category: 'Project',
    tags: ['TASKNOVA', 'Demo']
  },
  {
    id: 'td7',
    title: 'Backup local project repositories to encrypted external drive',
    completed: false,
    priority: 'Low',
    dueDate: 'Upcoming',
    category: 'Personal',
    tags: ['Security', 'Backup']
  }
];

export const initialComments: ProjectComment[] = [
  {
    id: 'c1',
    projectId: 'p2',
    projectName: 'Mobile Banking App',
    authorName: 'Rohan Kumar',
    authorRole: 'Frontend Developer',
    content: "I've completed the API integration. Can someone review the authentication flow?",
    timestamp: '28 minutes ago',
    pinned: true,
    reactions: [
      { emoji: '👍', count: 4, users: ['Aarav Sharma', 'Priya Verma', 'Sneha Gupta', 'Shivam Singh'] },
      { emoji: '🚀', count: 2, users: ['Ananya Singh', 'Aditya Raj'] }
    ],
    replies: [
      {
        id: 'r1',
        authorName: 'Priya Verma',
        authorRole: 'Backend Developer',
        content: "On it! Validating token exchange with sandbox gateway now.",
        timestamp: '18 minutes ago'
      },
      {
        id: 'r2',
        authorName: 'Sneha Gupta',
        authorRole: 'QA Engineer',
        content: "Added 5 edge case test scenarios in the QA plan.",
        timestamp: '10 minutes ago'
      }
    ]
  },
  {
    id: 'c2',
    projectId: 'p1',
    projectName: 'Website Redesign',
    authorName: 'Ananya Singh',
    authorRole: 'UI/UX Designer',
    content: "Updated the homepage design based on yesterday's feedback. Check the new hero illustrations.",
    timestamp: '1 hour ago',
    pinned: false,
    reactions: [
      { emoji: '🎨', count: 5, users: ['Rohan Kumar', 'Aarav Sharma', 'Shivam Singh', 'Priya Verma', 'Sneha Gupta'] },
      { emoji: '❤️', count: 3, users: ['Shivam Singh', 'Rohan Kumar', 'Sneha Gupta'] }
    ],
    replies: [
      {
        id: 'r3',
        authorName: 'Aarav Sharma',
        authorRole: 'Project Manager',
        content: 'Looks crisp and clean! Spacing adheres perfectly to the 8px system.',
        timestamp: '45 minutes ago'
      }
    ]
  },
  {
    id: 'c3',
    projectId: 'p3',
    projectName: 'AI Analytics Platform',
    authorName: 'Priya Verma',
    authorRole: 'Backend Developer',
    content: "Backend endpoints are ready for frontend integration. Swagger specs updated at /api/docs.",
    timestamp: '2 hours ago',
    pinned: false,
    reactions: [
      { emoji: '🔥', count: 3, users: ['Aditya Raj', 'Rohan Kumar', 'Shivam Singh'] }
    ],
    replies: []
  }
];

export const initialActivities: ActivityItem[] = [
  {
    id: 'act1',
    authorName: 'Ananya Singh',
    action: 'completed',
    target: '"Homepage Design"',
    timestamp: '12 minutes ago',
    type: 'complete',
    projectId: 'p1'
  },
  {
    id: 'act2',
    authorName: 'Rohan Kumar',
    action: 'moved',
    target: '"API Integration" to In Progress',
    timestamp: '35 minutes ago',
    type: 'status_change',
    projectId: 'p2'
  },
  {
    id: 'act3',
    authorName: 'Priya Verma',
    action: 'uploaded',
    target: '"API Documentation.pdf"',
    timestamp: '1 hour ago',
    type: 'upload',
    projectId: 'p3'
  },
  {
    id: 'act4',
    authorName: 'Aarav Sharma',
    action: 'created',
    target: '"Payment Gateway Testing"',
    timestamp: '2 hours ago',
    type: 'create',
    projectId: 'p2'
  },
  {
    id: 'act5',
    authorName: 'Sneha Gupta',
    action: 'commented on',
    target: '"Authentication Module"',
    timestamp: '3 hours ago',
    type: 'comment',
    projectId: 'p2'
  }
];

export const initialNotifications: NotificationItem[] = [
  {
    id: 'n1',
    title: 'Deadline Approaching',
    message: 'Homepage UI is due tomorrow.',
    type: 'deadline',
    timestamp: '10 mins ago',
    read: false,
    linkTo: 'projects'
  },
  {
    id: 'n2',
    title: 'New Comment',
    message: 'Priya mentioned you in API Integration.',
    type: 'comment',
    timestamp: '35 mins ago',
    read: false,
    linkTo: 'comments'
  },
  {
    id: 'n3',
    title: 'File Uploaded',
    message: 'Rohan uploaded API Documentation.pdf.',
    type: 'file',
    timestamp: '1 hour ago',
    read: false,
    linkTo: 'files'
  },
  {
    id: 'n4',
    title: 'New Assignment',
    message: 'You were assigned to Mobile Banking App.',
    type: 'assignment',
    timestamp: '2 hours ago',
    read: true,
    linkTo: 'tasks'
  }
];

export const initialEvents: CalendarEvent[] = [
  {
    id: 'ev1',
    title: 'Project Review Meeting (Website Redesign)',
    date: '2026-09-11',
    time: '4:00 PM - 5:00 PM',
    type: 'meeting',
    projectId: 'p1',
    location: 'Microsoft Teams • Room 402',
    reminderMinutes: 15
  },
  {
    id: 'ev2',
    title: 'Weekly Team Sync (TASKNOVA Core)',
    date: '2026-09-12',
    time: '10:00 AM - 11:00 AM',
    type: 'meeting',
    projectId: 'p2',
    location: 'Microsoft Teams Channel #general',
    reminderMinutes: 30
  },
  {
    id: 'ev3',
    title: 'Data Structures Mid-Semester Exam',
    date: '2026-09-18',
    time: '09:00 AM - 12:00 PM',
    type: 'exam',
    location: 'Main Academic Hall B',
    reminderMinutes: 120
  },
  {
    id: 'ev4',
    title: 'Sprint 14 Deadline: Mobile Banking Token Fix',
    date: '2026-09-13',
    time: '11:59 PM',
    type: 'deadline',
    projectId: 'p2',
    reminderMinutes: 60
  },
  {
    id: 'ev5',
    title: 'Deep Focus Study Session: Graph Algorithms',
    date: '2026-09-11',
    time: '06:00 PM - 08:00 PM',
    type: 'study',
    reminderMinutes: 10
  }
];

export const initialTeamsMeetings: TeamsMeeting[] = [
  {
    id: 'tm1',
    title: 'Project Review Meeting',
    date: 'Today',
    time: '4:00 PM',
    teamName: 'Website Redesign',
    channel: 'Sprint Reviews',
    joinUrl: 'https://teams.microsoft.com/l/meetup-join/mock-tasknova-review-1',
    organizer: 'Aarav Sharma',
    attendeesCount: 5
  },
  {
    id: 'tm2',
    title: 'Weekly Team Sync',
    date: 'Tomorrow',
    time: '10:00 AM',
    teamName: 'TASKNOVA Development Team',
    channel: 'General Sync',
    joinUrl: 'https://teams.microsoft.com/l/meetup-join/mock-tasknova-sync-2',
    organizer: 'Aarav Sharma',
    attendeesCount: 8
  },
  {
    id: 'tm3',
    title: 'Architecture Deep-Dive: AI Microservices',
    date: 'Monday',
    time: '2:30 PM',
    teamName: 'AI Analytics Platform',
    channel: 'Architecture & Tech',
    joinUrl: 'https://teams.microsoft.com/l/meetup-join/mock-tasknova-arch-3',
    organizer: 'Aditya Raj',
    attendeesCount: 6
  }
];

export const initialStudyPlan: StudyPlan = {
  id: 'sp1',
  subject: 'Data Structures & Algorithms',
  examDate: 'September 18, 2026',
  availableHoursPerDay: 3.5,
  progress: 57,
  difficulty: 'Hard',
  weakTopics: ['Graph Cycle Detection', 'Dynamic Programming on Trees', 'Red-Black Trees'],
  days: [
    { dayNumber: 1, topic: 'Arrays & Two-Pointer Techniques', durationHours: 3.0, completed: true },
    { dayNumber: 2, topic: 'Linked Lists & Fast-Slow Pointers', durationHours: 3.0, completed: true },
    { dayNumber: 3, topic: 'Stacks, Monotonic Stacks & Applications', durationHours: 3.5, completed: true },
    { dayNumber: 4, topic: 'Queues & Circular Buffers', durationHours: 2.5, completed: true },
    { dayNumber: 5, topic: 'Trees, BST Traversals & LCA', durationHours: 4.0, completed: false, weakArea: true },
    { dayNumber: 6, topic: 'Graphs (BFS, DFS, Dijkstra & Topological Sort)', durationHours: 4.5, completed: false, weakArea: true },
    { dayNumber: 7, topic: 'Comprehensive Mock Exam & Revision', durationHours: 3.0, completed: false }
  ]
};

export const initialStudyResources: StudyResource[] = [
  {
    id: 'sr1',
    title: 'Introduction to Algorithms (CLRS)',
    type: 'book',
    authorsOrChannel: 'Thomas H. Cormen, Charles E. Leiserson',
    source: 'Open Library API',
    identifierOrUrl: 'ISBN 978-0262033848',
    saved: true,
    tags: ['Algorithms', 'Textbook', 'Reference'],
    year: '2022'
  },
  {
    id: 'sr2',
    title: 'Designing Data-Intensive Applications',
    type: 'book',
    authorsOrChannel: 'Martin Kleppmann',
    source: 'Open Library API',
    identifierOrUrl: 'ISBN 978-1449373320',
    saved: true,
    tags: ['Distributed Systems', 'Databases'],
    year: '2017'
  },
  {
    id: 'sr3',
    title: 'Attention Is All You Need: Scalable Transformers',
    type: 'paper',
    authorsOrChannel: 'Vaswani et al.',
    source: 'Crossref REST API',
    identifierOrUrl: '10.48550/arXiv.1706.03762',
    saved: true,
    tags: ['Machine Learning', 'Transformers', 'GenAI'],
    year: '2017'
  },
  {
    id: 'sr4',
    title: 'Efficient Distributed Graph Processing at Scale',
    type: 'paper',
    authorsOrChannel: 'Gonzalez et al.',
    source: 'Crossref REST API',
    identifierOrUrl: '10.1145/2387880.2387883',
    saved: false,
    tags: ['Graphs', 'Cloud'],
    year: '2021'
  },
  {
    id: 'sr5',
    title: 'Graph Algorithms Full Course in 4 Hours',
    type: 'video',
    authorsOrChannel: 'freeCodeCamp.org',
    source: 'YouTube Data API',
    identifierOrUrl: 'https://youtube.com/watch?v=tWVWeAqZ0WU',
    saved: true,
    tags: ['Algorithms', 'Video', 'Hands-on'],
    year: '2025'
  },
  {
    id: 'sr6',
    title: 'Modern System Design Primer for Tech Interviews',
    type: 'video',
    authorsOrChannel: 'NeetCode',
    source: 'YouTube Data API',
    identifierOrUrl: 'https://youtube.com/watch?v=i53Gi_K3o7I',
    saved: true,
    tags: ['Architecture', 'Interview'],
    year: '2026'
  }
];

export const initialFiles: ProjectFile[] = [
  {
    id: 'f1',
    projectId: 'p1',
    projectName: 'Website Redesign',
    name: 'Requirements.pdf',
    size: '2.4 MB',
    type: 'pdf',
    uploadedBy: 'Aarav Sharma',
    uploadedAt: 'Sept 5, 2026'
  },
  {
    id: 'f2',
    projectId: 'p4',
    projectName: 'Marketing Campaign 2026',
    name: 'Project_Report.pdf',
    size: '4.8 MB',
    type: 'pdf',
    uploadedBy: 'Ananya Singh',
    uploadedAt: 'Sept 8, 2026'
  },
  {
    id: 'f3',
    projectId: 'p3',
    projectName: 'AI Analytics Platform',
    name: 'API_Documentation.pdf',
    size: '1.9 MB',
    type: 'pdf',
    uploadedBy: 'Priya Verma',
    uploadedAt: '1 hour ago'
  },
  {
    id: 'f4',
    projectId: 'p1',
    projectName: 'Website Redesign',
    name: 'UI_Design.fig',
    size: '18.6 MB',
    type: 'fig',
    uploadedBy: 'Ananya Singh',
    uploadedAt: 'Yesterday'
  },
  {
    id: 'f5',
    projectId: 'p3',
    projectName: 'AI Analytics Platform',
    name: 'Research_Paper.pdf',
    size: '3.1 MB',
    type: 'pdf',
    uploadedBy: 'Aditya Raj',
    uploadedAt: 'Sept 2, 2026'
  }
];

export const initialAuditLogs: AuditLogItem[] = [
  {
    id: 'al1',
    timestamp: '11:42 AM',
    title: 'Suspicious login detected',
    description: 'Login attempt from new device running Windows PC with Chrome.',
    user: 'Shivam Singh',
    device: 'Windows PC',
    browser: 'Chrome 128.0',
    location: 'Patna, Bihar, India',
    severity: 'warning'
  },
  {
    id: 'al2',
    timestamp: '10:32 AM',
    title: 'Successful user authentication',
    description: 'Authenticated via Two-Factor Authenticator App token.',
    user: 'Shivam Singh',
    device: 'Desktop Workstation',
    browser: 'Chrome 128.0',
    severity: 'info'
  },
  {
    id: 'al3',
    timestamp: '10:15 AM',
    title: 'Project metadata updated',
    description: 'Project "AI Analytics Platform" milestone dates updated by Aditya Raj.',
    user: 'Aditya Raj',
    severity: 'info'
  },
  {
    id: 'al4',
    timestamp: '09:42 AM',
    title: 'New hardware device connected',
    description: 'FIDO2 Security Key hardware token registered for Shivam Singh.',
    user: 'Shivam Singh',
    severity: 'info'
  },
  {
    id: 'al5',
    timestamp: 'Yesterday',
    title: 'Password change confirmed',
    description: 'User password was rotated and active sessions invalidated.',
    user: 'Shivam Singh',
    severity: 'info'
  },
  {
    id: 'al6',
    timestamp: '2 days ago',
    title: 'Admin Action: Task deleted',
    description: 'Rohan deleted deprecated Task #142 (Old payment webhook mock).',
    user: 'Rohan Kumar (Admin)',
    severity: 'warning'
  },
  {
    id: 'al7',
    timestamp: '3 days ago',
    title: 'Project Permissions Changed',
    description: 'Priya changed project permissions for Mobile Banking App repository.',
    user: 'Priya Verma',
    severity: 'info'
  }
];
