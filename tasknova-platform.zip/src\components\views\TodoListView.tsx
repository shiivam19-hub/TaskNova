import React, { useState } from 'react';
import {
  ListTodo,
  Plus,
  Search,
  CheckCircle2,
  Trash2,
  Tag,
  Calendar,
  Sparkles,
  Edit2
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { ToDoItem, Priority } from '../../types';
import { useToast } from '../../context/ToastContext';

export const TodoListView: React.FC = () => {
  const {
    todos,
    addToDo,
    toggleToDo,
    deleteToDo,
    updateToDo
  } = useApp();

  const { showToast } = useToast();

  const [activeCategory, setActiveCategory] = useState<'All' | 'Today' | 'Upcoming' | 'Personal' | 'Study' | 'Project'>('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [newTitle, setNewTitle] = useState('');
  const [newPriority, setNewPriority] = useState<Priority>('Medium');
  const [newCategory, setNewCategory] = useState<'Today' | 'Upcoming' | 'Personal' | 'Study' | 'Project'>('Today');

  const completedCount = todos.filter(t => t.completed).length;
  const totalCount = todos.length;

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;
    addToDo({
      title: newTitle.trim(),
      priority: newPriority,
      dueDate: newCategory === 'Today' ? 'Today' : 'Upcoming',
      category: newCategory,
      tags: [newCategory]
    });
    setNewTitle('');
    showToast('To-Do Added', 'Personal item added to your checklist.', 'success');
  };

  const filteredTodos = todos.filter(td => {
    const matchesSearch = td.title.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = activeCategory === 'All' || td.category === activeCategory;
    return matchesSearch && matchesCategory;
  });

  const getPriorityColor = (priority: Priority) => {
    switch (priority) {
      case 'Urgent':
        return 'text-rose-400 bg-rose-500/10 border-rose-500/30';
      case 'High':
        return 'text-amber-400 bg-amber-500/10 border-amber-500/30';
      case 'Medium':
        return 'text-cyan-400 bg-cyan-500/10 border-cyan-500/30';
      default:
        return 'text-slate-400 bg-slate-800 border-slate-700';
    }
  };

  return (
    <div className="space-y-6 animate-fade-in pb-16 max-w-4xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-white flex items-center gap-2.5">
            <ListTodo className="w-6 h-6 text-emerald-400" />
            Personal To-Do List
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Capture quick daily thoughts, study checklists, and personal priorities.
          </p>
        </div>

        {/* Completion Counter Badge (Requirement 8) */}
        <div className="px-4 py-2 bg-[#111827] border border-slate-800 rounded-xl flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-emerald-500/15 text-emerald-400 flex items-center justify-center font-bold text-xs">
            <CheckCircle2 className="w-4 h-4" />
          </div>
          <div>
            <div className="text-xs font-semibold text-white">
              {completedCount} of {totalCount} tasks completed
            </div>
            <div className="w-28 h-1.5 bg-slate-800 rounded-full mt-1 overflow-hidden">
              <div
                className="h-full bg-emerald-500 rounded-full transition-all"
                style={{ width: `${totalCount > 0 ? (completedCount / totalCount) * 100 : 0}%` }}
              />
            </div>
          </div>
        </div>
      </div>

      {/* Inline Quick Add Card */}
      <form
        onSubmit={handleCreate}
        className="bg-[#111827] border border-slate-800 rounded-2xl p-4 shadow-sm space-y-3"
      >
        <div className="flex items-center gap-2">
          <input
            type="text"
            value={newTitle}
            onChange={e => setNewTitle(e.target.value)}
            placeholder="Add a new checklist item (e.g. Practice 3 Dynamic Programming problems)..."
            className="flex-1 px-3.5 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-xs text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-indigo-500"
          />
          <button
            type="submit"
            className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold rounded-xl flex items-center gap-1.5 shrink-0 transition-colors"
          >
            <Plus className="w-4 h-4" />
            Add To-Do
          </button>
        </div>

        <div className="flex flex-wrap items-center gap-3 text-xs text-slate-400">
          <div className="flex items-center gap-1.5">
            <span>Category:</span>
            <select
              value={newCategory}
              onChange={e => setNewCategory(e.target.value as any)}
              className="px-2 py-1 bg-slate-900 border border-slate-700 rounded-lg text-slate-200 text-xs focus:outline-none"
            >
              <option value="Today">Today</option>
              <option value="Upcoming">Upcoming</option>
              <option value="Study">Study</option>
              <option value="Project">Project</option>
              <option value="Personal">Personal</option>
            </select>
          </div>

          <div className="flex items-center gap-1.5">
            <span>Priority:</span>
            <select
              value={newPriority}
              onChange={e => setNewPriority(e.target.value as Priority)}
              className="px-2 py-1 bg-slate-900 border border-slate-700 rounded-lg text-slate-200 text-xs focus:outline-none"
            >
              <option value="Urgent">Urgent</option>
              <option value="High">High</option>
              <option value="Medium">Medium</option>
              <option value="Low">Low</option>
            </select>
          </div>
        </div>
      </form>

      {/* Category Pills & Search */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 bg-[#111827] border border-slate-800 p-3 rounded-2xl">
        <div className="flex items-center gap-1.5 overflow-x-auto w-full sm:w-auto">
          {(['All', 'Today', 'Upcoming', 'Personal', 'Study', 'Project'] as const).map(cat => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`px-3 py-1.5 rounded-xl text-xs font-medium transition-colors shrink-0 ${
                activeCategory === cat
                  ? 'bg-indigo-600 text-white shadow-md shadow-indigo-950/40'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        <div className="relative w-full sm:w-60">
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="text"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder="Filter list..."
            className="w-full pl-8 pr-3 py-1 bg-slate-900 border border-slate-700 rounded-xl text-xs text-slate-100 placeholder:text-slate-500 focus:outline-none"
          />
        </div>
      </div>

      {/* To-Do Items List */}
      <div className="space-y-2.5">
        {filteredTodos.length === 0 ? (
          <div className="p-8 text-center bg-[#111827] border border-slate-800 rounded-2xl text-slate-400 text-xs">
            No items in this category. Use the input above to add your first checklist item!
          </div>
        ) : (
          filteredTodos.map(todo => (
            <div
              key={todo.id}
              className={`p-4 rounded-xl border transition-all flex items-start justify-between gap-3 ${
                todo.completed
                  ? 'bg-slate-900/40 border-slate-800/60 opacity-60'
                  : 'bg-[#111827] border-slate-800 hover:border-slate-700 shadow-xs'
              }`}
            >
              <div className="flex items-start gap-3 min-w-0">
                <button
                  onClick={() => toggleToDo(todo.id)}
                  className={`w-5 h-5 rounded-md border mt-0.5 flex items-center justify-center transition-colors shrink-0 ${
                    todo.completed
                      ? 'bg-emerald-500 border-emerald-500 text-white'
                      : 'border-slate-700 hover:border-indigo-500'
                  }`}
                >
                  {todo.completed && <CheckCircle2 className="w-3.5 h-3.5" />}
                </button>

                <div className="space-y-1 min-w-0">
                  <span className={`text-xs font-semibold block leading-snug ${
                    todo.completed ? 'line-through text-slate-500' : 'text-slate-100'
                  }`}>
                    {todo.title}
                  </span>

                  {todo.notes && (
                    <p className="text-[11px] text-slate-400 leading-normal">{todo.notes}</p>
                  )}

                  <div className="flex flex-wrap items-center gap-2 pt-0.5">
                    <span className={`text-[9px] font-semibold px-2 py-0.5 rounded border ${getPriorityColor(todo.priority)}`}>
                      {todo.priority}
                    </span>
                    <span className="text-[10px] text-slate-400 flex items-center gap-1">
                      <Calendar className="w-3 h-3 text-slate-500" />
                      {todo.dueDate}
                    </span>
                    <span className="text-[10px] px-1.5 py-0.2 rounded bg-slate-800 text-indigo-300">
                      #{todo.category}
                    </span>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-1 shrink-0">
                <button
                  onClick={() => deleteToDo(todo.id)}
                  className="p-1.5 text-slate-500 hover:text-rose-400 rounded-lg hover:bg-slate-800 transition-colors"
                  title="Delete"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
